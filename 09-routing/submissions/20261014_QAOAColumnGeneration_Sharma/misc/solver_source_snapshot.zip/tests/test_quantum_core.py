import numpy as np

from qobench.quantum import QUBO, qaoa_optimize, qaoa_state


def random_qubo(n, seed=0):
    rng = np.random.default_rng(seed)
    return QUBO(np.triu(rng.integers(-5, 6, (n, n)).astype(float)), offset=1.5)


def test_ising_matches_qubo():
    q = random_qubo(6)
    h, J, c = q.to_ising()
    for k in range(2 ** 6):
        x = np.array([(k >> i) & 1 for i in range(6)])
        z = 1 - 2 * x
        assert np.isclose(q.energy(x), h @ z + z @ J @ z + c)


def test_diagonal_and_brute_force():
    q = random_qubo(7, 1)
    e = q.diagonal()
    for k in (0, 5, 77, 127):
        x = np.array([(k >> i) & 1 for i in range(7)])
        assert np.isclose(e[k], q.energy(x))
    val, x = q.brute_force()
    assert np.isclose(val, e.min()) and np.isclose(q.energy(x), val)


def test_qaoa_matches_qiskit():
    from qiskit import QuantumCircuit
    from qiskit.circuit.library import DiagonalGate
    from qiskit.quantum_info import Statevector

    q = random_qubo(4, 2)
    e = q.diagonal()
    g, b = [0.3, 0.7], [0.5, 0.2]
    psi = qaoa_state(e, g, b)
    qc = QuantumCircuit(4)
    qc.h(range(4))
    for gg, bb in zip(g, b):
        qc.append(DiagonalGate(list(np.exp(-1j * gg * e))), list(range(4)))
        qc.rx(2 * bb, range(4))
    ref = Statevector(qc).data
    assert np.isclose(abs(np.vdot(ref, psi)), 1.0, atol=1e-9)


def test_qaoa_improves_over_uniform():
    q = random_qubo(8, 3)
    e = q.diagonal()
    res = qaoa_optimize(e, p=2, restarts=2)
    assert res["value"] < e.mean()


def test_subspace_qaoa_matches_qiskit_circuit():
    from qiskit.quantum_info import Statevector

    from qobench.quantum.subspace import WeightSubspace, subspace_circuit

    q = random_qubo(5, 4)
    g, b = [0.21, 0.43], [0.37, 0.11]
    for mixer in ("ring", "clique"):
        sub = WeightSubspace(5, 2, mixer)
        e = sub.energies_from_qubo(q.Q, q.offset)
        psi = qaoa_state(e, g, b, **sub.kw())
        ref = Statevector(subspace_circuit(sub, (q.Q, q.offset), g, b)).data
        assert np.isclose(np.linalg.norm(ref[sub.states]), 1.0)  # never leaves weight 2
        assert np.isclose(abs(np.vdot(ref[sub.states], psi)), 1.0, atol=1e-9)


def test_subspace_energies_and_optimize():
    from qobench.quantum.subspace import WeightSubspace

    q = random_qubo(8, 5)
    sub = WeightSubspace(8, 3)
    e_full = q.diagonal()
    assert np.allclose(sub.energies_from_qubo(q.Q, q.offset), e_full[sub.states])
    e = e_full[sub.states]
    res = qaoa_optimize(e, p=2, restarts=2, **sub.kw())
    assert res["value"] < e.mean()
