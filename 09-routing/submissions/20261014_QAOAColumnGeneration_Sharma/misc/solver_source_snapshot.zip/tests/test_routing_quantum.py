from math import comb

import numpy as np
import pytest

qvrp = pytest.importorskip("qvrp")
from qvrp.instance import INSTANCES, Instance, all_columns, feasible_sizes, incidence, tsp_exact  # noqa: E402

if not INSTANCES.exists():
    pytest.skip("QOBLIB checkout missing (tools/setup_qoblib.sh)", allow_module_level=True)

from qvrp.master import master_energies  # noqa: E402

from qobench.quantum import WeightSubspace, qaoa_state  # noqa: E402


@pytest.fixture(scope="module")
def inst():
    return Instance.load("XSH-n20-k4-03")


@pytest.fixture(scope="module")
def cols(inst):
    return all_columns(inst)


def test_exact_load(inst):
    assert inst.exact_load


def test_tsp_exact_matches_enumeration(inst, cols):
    masks, costs = cols
    for r in np.random.default_rng(0).choice(len(masks), 25, replace=False):
        cost, order = tsp_exact(inst, int(masks[r]))
        assert cost == costs[r]
        assert sorted(order) == inst.members(int(masks[r]))


def test_feasible_sizes(inst, cols):
    assert feasible_sizes(inst) == sorted(set(incidence(cols[0], inst.n).sum(1).tolist()))


def test_master_feasible_iff_exact_cover(inst, cols):
    masks, _ = cols
    opt_masks = [inst.mask(r) for r in inst.optimal_routes()]
    others = [m for m in np.random.default_rng(1).choice(masks, 8, replace=False) if m not in opt_masks]
    pool = np.array(opt_masks + others, np.int64)
    pc = np.array([tsp_exact(inst, int(m))[0] for m in pool], float)
    sub = WeightSubspace(len(pool), inst.K)
    X = incidence(pool, inst.n)
    E, feas = master_energies(sub, X, pc, P=1e4)
    assert np.array_equal(feas, ((sub.bits() @ X) == 1).all(1))
    assert E[feas].min() == inst.optimum()


def test_pricer_on_customer_subset(inst):
    from qvrp.pricing import PricingConfig, QuantumPricer, Surrogate
    opt = [inst.mask(r) for r in inst.optimal_routes()]
    R = opt[0] | opt[1]
    pr = QuantumPricer(inst, PricingConfig(shots=200, sampler="uniform"), customers=inst.members(R))
    assert pr.stats["qubits"] == bin(R).count("1")
    found, _, _ = pr.price(np.zeros(inst.n), Surrogate(inst))
    assert found and all(m & ~R == 0 and inst.load_of(m) == inst.Q for m in found)


def test_dicke_and_hardware_circuit():
    from qiskit.quantum_info import Statevector

    from qvrp.hardware import dicke_circuit, qaoa_circuit
    for n, k in [(5, 2), (6, 3), (7, 1)]:
        p = np.abs(Statevector(dicke_circuit(n, k)).data) ** 2
        w = np.array([bin(i).count("1") for i in range(2 ** n)])
        assert np.allclose(p[w == k], 1 / comb(n, k)) and np.allclose(p[w != k], 0)
    rng = np.random.default_rng(0)
    Q = np.triu(rng.integers(-5, 6, (6, 6)).astype(float))
    sub = WeightSubspace(6, 2)
    g, b = [0.21, 0.4], [0.33, 0.12]
    psi = qaoa_state(sub.energies_from_qubo(Q), g, b, **sub.kw())
    ref = Statevector(qaoa_circuit(Q, 2, g, b, sub.pairs, measure=False)).data
    assert np.isclose(abs(np.vdot(ref[sub.states], psi)), 1.0, atol=1e-9)


def test_staged_pipeline_returns_valid_plan(inst):
    from qvrp.colgen import CGConfig, column_generation
    from qvrp.master import MasterConfig, StagedMaster
    from qvrp.pricing import V1, PricingConfig
    pcfg = PricingConfig(**V1, shots=300, sampler="uniform")       # uniform: fast and deterministic per seed
    cg = column_generation(inst, pcfg, CGConfig(max_iter=15), seed=0, log=lambda *a: None)
    r = StagedMaster(inst, cg, MasterConfig(sampler="uniform", shots=300, residual_shots=300), pcfg).run()
    assert r["cost"] is not None
    served = sorted(i for route in r["routes"] for i in route)
    assert served == list(range(1, inst.n + 1))
    assert all(inst.load_of(inst.mask(route)) == inst.Q for route in r["routes"])
    assert r["cost"] >= inst.optimum()


def test_product_start_and_sparsified_cost_are_exact_in_subspace():
    from qiskit.quantum_info import Statevector

    from qvrp.hardware import qaoa_circuit, sparsify_in_subspace
    rng = np.random.default_rng(3)
    m, k = 7, 2
    Q = np.triu(rng.integers(1, 4, (m, m)).astype(float))      # many equal couplings
    Qs, shift = sparsify_in_subspace(Q)
    assert (np.triu(Qs, 1) != 0).sum() < (np.triu(Q, 1) != 0).sum()
    sub = WeightSubspace(m, k)
    g, b = [0.31, 0.12], [0.27, 0.44]
    ref = np.abs(qaoa_state(sub.energies_from_qubo(Q), g, b, **sub.kw())) ** 2
    for init in ("dicke", "product"):
        for QQ in (Q, Qs):
            sv = np.abs(Statevector(qaoa_circuit(QQ, k, g, b, sub.pairs, measure=False, init=init)).data) ** 2
            w = sv[sub.states]
            assert np.allclose(w / w.sum(), ref, atol=1e-9)
    acc = (np.abs(Statevector(qaoa_circuit(Q, k, g, b, sub.pairs, measure=False, init="product")).data) ** 2)[sub.states].sum()
    assert np.isclose(acc, comb(m, k) * (k / m) ** k * (1 - k / m) ** (m - k))
