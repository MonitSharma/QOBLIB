"""Shared code for classical and quantum attacks on QOBLIB.

Problem-specific solvers live under ``problems/NN-name/{classical,quantum}``; this package
holds what they share: locating the upstream library (``paths``), writing QOBLIB-format
submissions (``submission``) and the QUBO / QAOA core used by every quantum track
(``quantum``).
"""
