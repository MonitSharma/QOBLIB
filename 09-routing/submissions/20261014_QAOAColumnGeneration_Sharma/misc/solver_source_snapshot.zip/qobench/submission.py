"""Write submissions in the layout QOBLIB's CI expects.

    submissions/<NN-problem>/<YYYYMMDD>_<Method>_<Surname>/<instance>/
        <instance>_summary.csv                 (30-column template, one row)
        <instance>_solution.<ext>              (problem-specific format)
        <instance>_objective_time_series.json  (optional)

Validate before opening a PR with
    uv run --project external/QOBLIB/misc qoblib-check-submission <dir>
"""
from __future__ import annotations

import csv
import json
import shutil
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .paths import SUBMISSIONS

COLUMNS = [
    "Problem", "Submitter", "Affiliation", "Date", "Reference", "Best Objective Value",
    "Optimality Bound", "Modeling Approach", "# Decision Variables", "# Binary Variables",
    "# Integer Variables", "# Continuous Variables", "# Non-Zero Coefficients",
    "Coefficients Type", "Coefficients Range", "Workflow", "Algorithm Type", "Paradigm",
    "# Runs", "# Feasible Runs", "# Successful Runs", "Success Threshold",
    "Hardware Specifications", "Total Runtime", "Time to Solution", "CPU Runtime",
    "GPU Runtime", "QPU Runtime", "Other HW Runtime", "Remarks",
]


@dataclass
class Summary:
    problem: str                       # instance name
    best: float | int | str
    workflow: str
    paradigm: str                      # Classical | Quantum Simulator | Quantum Hardware
    algorithm_type: str = "Stochastic"
    optimality_bound: str = "N/A"      # set == best only when optimality is PROVEN
    submitter: str = ""
    affiliation: str = ""
    date: str = ""                     # YYYY-MM-DD
    reference: str = ""
    modeling: str = ""
    runs: int = 1
    feasible_runs: int = 1
    successful_runs: int = 1
    threshold: str = "0"
    hardware: str = ""
    total_runtime: float | str = "N/A"
    time_to_solution: float | str = "N/A"
    cpu_runtime: float | str = "N/A"
    qpu_runtime: float | str = "N/A"
    remarks: str = ""
    extra: dict = field(default_factory=dict)  # any other template column by name

    def row(self) -> dict:
        r = {c: "N/A" for c in COLUMNS}
        r.update({
            "Problem": self.problem, "Submitter": self.submitter,
            "Affiliation": self.affiliation, "Date": self.date, "Reference": self.reference,
            "Best Objective Value": self.best, "Optimality Bound": self.optimality_bound,
            "Modeling Approach": self.modeling, "Workflow": self.workflow,
            "Algorithm Type": self.algorithm_type, "Paradigm": self.paradigm,
            "# Runs": self.runs, "# Feasible Runs": self.feasible_runs,
            "# Successful Runs": self.successful_runs, "Success Threshold": self.threshold,
            "Hardware Specifications": self.hardware, "Total Runtime": self.total_runtime,
            "Time to Solution": self.time_to_solution, "CPU Runtime": self.cpu_runtime,
            "QPU Runtime": self.qpu_runtime, "Remarks": self.remarks,
        })
        r.update(self.extra)
        return r


def write(problem_dir: str, submission: str, summary: Summary, solution: Path,
          ext: str = "sol", time_series: list | None = None) -> Path:
    """Create ``submissions/<problem_dir>/<submission>/<instance>/`` and return it."""
    d = SUBMISSIONS / problem_dir / submission / summary.problem
    d.mkdir(parents=True, exist_ok=True)
    with (d / f"{summary.problem}_summary.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=COLUMNS)
        w.writeheader()
        w.writerow(summary.row())
    shutil.copyfile(solution, d / f"{summary.problem}_solution.{ext}")
    if time_series is not None:
        (d / f"{summary.problem}_objective_time_series.json").write_text(json.dumps(time_series))
    return d


__all__ = ["COLUMNS", "Summary", "write", "asdict"]
