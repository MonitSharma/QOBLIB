"""Statevector QAOA for diagonal cost Hamiltonians (exact simulation, n <~ 26 qubits).

Every QOBLIB class reduces to a diagonal cost (QUBO / higher order for LABS), so the
cost layer is an elementwise phase exp(-i gamma E) on the precomputed energy vector and
only the mixer needs gate-level work.  This is far faster than generic circuit
simulation and is the workhorse for parameter studies; circuits for hardware or MPS
simulation are built with Qiskit from the same angles.

Mixers:
  * "x"     : standard transverse field  prod_i exp(-i beta X_i)
  * custom  : pass a callable psi -> psi (e.g. XY ring mixer, or a mixer restricted to
              the feasible subspace) for constraint-preserving variants.
Objectives: plain expectation, or CVaR_alpha (Barkoutsos et al., Quantum 4, 256 (2020)).
"""
from __future__ import annotations

from typing import Callable

import numpy as np
from scipy.optimize import minimize


def _apply_x_mixer(psi: np.ndarray, beta: float, n: int) -> np.ndarray:
    c, s = np.cos(beta), -1j * np.sin(beta)
    psi = psi.reshape([2] * n)
    for q in range(n):
        ax = n - 1 - q                       # qubit 0 = least-significant index bit
        a = np.take(psi, 0, axis=ax)
        b = np.take(psi, 1, axis=ax)
        psi = np.stack([c * a + s * b, s * a + c * b], axis=ax)
    return psi.reshape(-1)


def qaoa_state(energies: np.ndarray, gammas, betas, mixer: Callable | None = None,
               init: np.ndarray | None = None) -> np.ndarray:
    n = int(np.log2(energies.size))
    psi = (np.full(energies.size, 2 ** (-n / 2), dtype=complex) if init is None
           else np.array(init, dtype=complex))
    for g, b in zip(gammas, betas):
        psi = psi * np.exp(-1j * g * energies)
        psi = mixer(psi, b) if mixer else _apply_x_mixer(psi, b, n)
    return psi


def qaoa_expectation(energies, gammas, betas, alpha: float = 1.0, order=None, **kw) -> float:
    p = np.abs(qaoa_state(energies, gammas, betas, **kw)) ** 2
    if alpha >= 1.0:
        return float(p @ energies)
    if order is None:                                     # CVaR: mean of lowest alpha-tail
        order = np.argsort(energies)
    cp = np.cumsum(p[order])
    k = int(np.searchsorted(cp, alpha))
    w = p[order][: k + 1].copy()
    w[-1] -= cp[k] - alpha
    return float(w @ energies[order][: k + 1] / alpha)


def qaoa_optimize(energies: np.ndarray, p: int, alpha: float = 1.0, restarts: int = 5,
                  seed: int = 0, x0=None, maxfun: int | None = None, **kw):
    """Layer-wise interpolation (INTERP, Zhou et al. PRX 10, 021067) + random restarts.

    ``x0`` = [gammas, betas] warm start for restart 0, in units of the normalised cost
    (as returned in ``"x"``); ``**kw`` (mixer, init state) is passed to ``qaoa_state``."""
    rng = np.random.default_rng(seed)
    scale = 1.0 / max(1e-12, np.std(energies))            # normalise the cost scale
    E = energies * scale
    if alpha < 1.0:
        kw["order"] = np.argsort(E)
    best = None
    for r in range(restarts):
        if x0 is not None and r == 0:
            start = np.asarray(x0, float)
        else:
            t = (np.arange(p) + 0.5) / p
            start = np.concatenate([0.8 * t, 0.8 * (1 - t)]) + 0.1 * rng.standard_normal(2 * p)
        f = lambda x: qaoa_expectation(E, x[:p], x[p:], alpha=alpha, **kw)
        res = minimize(f, start, method="L-BFGS-B",
                       options={"maxfun": maxfun} if maxfun else None)
        if best is None or res.fun < best.fun:
            best = res
    g, b = best.x[:p] * scale, best.x[p:]
    return {"gammas": g, "betas": b, "value": best.fun / scale, "x": best.x,
            "nfev": int(best.nfev)}


def sample(energies, gammas, betas, shots: int, seed: int = 0, **kw):
    """Draw bitstring indices from the QAOA state; returns (indices, energies)."""
    pr = np.abs(qaoa_state(energies, gammas, betas, **kw)) ** 2
    idx = np.random.default_rng(seed).choice(energies.size, size=shots, p=pr / pr.sum())
    return idx, energies[idx]
