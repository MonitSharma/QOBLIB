"""Exact QAOA inside a fixed-Hamming-weight subspace (XY mixers, Dicke initial state).

A Hamming-weight-preserving mixer started in the Dicke state |D^m_k> never leaves the
span of the C(m, k) bitstrings with exactly k ones, so the simulation only needs that
many amplitudes instead of 2^m.  This is what makes cardinality-constrained problems
(choose exactly K routes, a fixed number of portfolio assets, ...) cheap to simulate far
beyond the 2^26 statevector limit, while staying gate-for-gate faithful to a circuit:

  * every XY gate exp(-i beta (X_i X_j + Y_i Y_j)/2) acts on the pair {|..1_i..0_j..>,
    |..0_i..1_j..>} as cos(beta) I - i sin(beta) sigma_x, i.e. a two-level rotation on
    precomputed index pairs (Qiskit: ``XXPlusYYGate(2 * beta)`` on qubits (i, j));
  * a mixer layer is an ordered product of such gates: ``"ring"`` = parity-ordered ring
    (even pairs, odd pairs, closing pair; Hadfield et al., Algorithms 12, 34 (2019)),
    ``"clique"`` = all pairs in lexicographic order (one first-order Trotter step of the
    complete-graph XY mixer).

Index convention matches ``qaoa.py``: qubit q is bit q of the basis integer.
"""
from __future__ import annotations

from itertools import combinations
from math import comb

import numpy as np
from numba import njit


@njit(cache=True)
def _xy_layer(psi, src, dst, bounds, c, s):
    """Apply the XY gates of one mixer layer in order (gate g owns src/dst[bounds[g]:bounds[g+1]])."""
    for g in range(bounds.size - 1):
        for t in range(bounds[g], bounds[g + 1]):
            a, b = psi[src[t]], psi[dst[t]]
            psi[src[t]] = c * a - 1j * s * b
            psi[dst[t]] = -1j * s * a + c * b


class WeightSubspace:
    """Basis of the m-qubit states with exactly k ones, plus XY-mixer index tables."""

    def __init__(self, m: int, k: int, mixer: str = "ring"):
        if not 0 < k < m:
            raise ValueError("need 0 < k < m")
        if comb(m, k) > 50_000_000:
            raise ValueError(f"C({m},{k}) = {comb(m, k):,} amplitudes is too large")
        self.m, self.k = m, k
        self.states = np.array(sorted(sum(1 << q for q in c) for c in combinations(range(m), k)),
                               dtype=np.int64)
        self.dim = self.states.size
        self.pairs = self._pair_order(mixer)
        self._tables = [self._pair_table(i, j) for i, j in self.pairs]

    def _pair_order(self, mixer: str):
        m = self.m
        if mixer == "ring":
            even = [(i, i + 1) for i in range(0, m - 1, 2)]
            odd = [(i, i + 1) for i in range(1, m - 1, 2)]
            return even + odd + ([(m - 1, 0)] if m > 2 else [])
        if mixer == "clique":
            return list(combinations(range(m), 2))
        raise ValueError(f"unknown mixer {mixer!r}")

    def _pair_table(self, i: int, j: int):
        s = self.states
        bi, bj = (s >> i) & 1, (s >> j) & 1
        src = np.nonzero((bi == 1) & (bj == 0))[0]            # |1_i 0_j>
        dst = np.searchsorted(s, s[src] ^ ((1 << i) | (1 << j)))  # partner |0_i 1_j>
        return src, dst

    # -- states and operators -------------------------------------------------------
    def dicke(self) -> np.ndarray:
        return np.full(self.dim, self.dim ** -0.5, dtype=complex)

    def bits(self, idx=None) -> np.ndarray:
        """(len, m) 0/1 matrix of the basis states (all, or the given indices)."""
        s = self.states if idx is None else self.states[np.asarray(idx)]
        return ((s[:, None] >> np.arange(self.m)) & 1).astype(np.int8)

    def index(self, bitstrings) -> np.ndarray:
        """Subspace indices of integer-encoded bitstrings (must have weight k)."""
        return np.searchsorted(self.states, np.asarray(bitstrings, dtype=np.int64))

    def mixer(self, psi: np.ndarray, beta: float) -> np.ndarray:
        if not hasattr(self, "_flat"):
            self._flat = (np.concatenate([t[0] for t in self._tables]),
                          np.concatenate([t[1] for t in self._tables]),
                          np.cumsum([0] + [t[0].size for t in self._tables]))
        out = np.array(psi, dtype=complex)
        _xy_layer(out, *self._flat, np.cos(beta), np.sin(beta))
        return out

    def energies_from_qubo(self, Q: np.ndarray, offset: float = 0.0) -> np.ndarray:
        """x^T Q x + offset for every basis state (Q upper triangular, n = m)."""
        X = self.bits().astype(float)
        return np.einsum("ki,ij,kj->k", X, Q, X, optimize=True) + offset

    def kw(self) -> dict:
        """Keyword arguments that route ``qaoa.*`` functions through this subspace."""
        return {"mixer": self.mixer, "init": self.dicke()}


def subspace_circuit(sub: WeightSubspace, energies_full_qubo, gammas, betas):
    """Qiskit circuit of the same QAOA (for transpilation / hardware / tests).

    ``energies_full_qubo`` = (Q, offset) of a QUBO on m qubits; the Dicke state is
    prepared with an exact ``StatePreparation`` (swap in a Bartschi-Eidenbenz circuit for
    hardware).  Returns the circuit; qubit q = bit q.
    """
    from qiskit import QuantumCircuit
    from qiskit.circuit.library import StatePreparation, XXPlusYYGate

    Q, offset = energies_full_qubo
    m = sub.m
    full = np.zeros(2 ** m, dtype=complex)
    full[sub.states] = sub.dicke()
    qc = QuantumCircuit(m)
    qc.append(StatePreparation(full), range(m))
    for g, b in zip(gammas, betas):
        for i in range(m):                                  # cost layer: exp(-i g x^T Q x)
            if Q[i, i]:
                qc.p(-g * Q[i, i], i)
            for j in range(i + 1, m):
                if Q[i, j]:
                    qc.cp(-g * Q[i, j], i, j)
        for i, j in sub.pairs:
            qc.append(XXPlusYYGate(2 * b), [i, j])
    return qc
