"""QUBO container shared by every problem's quantum track.

    E(x) = x^T Q x + offset,   x in {0,1}^n,   Q upper triangular (diagonal = linear terms)

QOBLIB ships QUBOs for most classes (``models/binary_unconstrained``); ``from_qoblib``
reads that format (``i j value`` triples, header comments) so our quantum runs use exactly
the published penalty weights unless a study explicitly varies them.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass
class QUBO:
    Q: np.ndarray            # (n, n) upper triangular
    offset: float = 0.0

    @property
    def n(self) -> int:
        return self.Q.shape[0]

    @classmethod
    def from_terms(cls, n: int, terms: dict[tuple[int, int], float], offset: float = 0.0):
        Q = np.zeros((n, n))
        for (i, j), v in terms.items():
            a, b = min(i, j), max(i, j)
            Q[a, b] += v
        return cls(Q, offset)

    @classmethod
    def from_qoblib(cls, path: Path):
        rows = []
        for line in Path(path).read_text().splitlines():
            s = line.strip()
            if not s or s[0] in "#cp%":
                continue
            i, j, v = s.split()[:3]
            rows.append((int(i), int(j), float(v)))
        base = min(min(i, j) for i, j, _ in rows)          # 0- or 1-based files
        n = max(max(i, j) for i, j, _ in rows) - base + 1
        return cls.from_terms(n, {(i - base, j - base): v for i, j, v in rows})

    def energy(self, x: np.ndarray) -> np.ndarray:
        """Energy of one bitstring (n,) or a batch (k, n)."""
        x = np.atleast_2d(x).astype(float)
        e = np.einsum("ki,ij,kj->k", x, self.Q, x) + self.offset
        return e if e.size > 1 else e[0]

    def to_ising(self):
        """Return (h, J, c) with x = (1 - z)/2, E = sum h_i z_i + sum_{i<j} J_ij z_i z_j + c."""
        Q = self.Q
        n = self.n
        h = np.zeros(n)
        J = np.zeros((n, n))
        c = self.offset
        for i in range(n):
            c += Q[i, i] / 2
            h[i] -= Q[i, i] / 2
            for j in range(i + 1, n):
                q = Q[i, j]
                if q:
                    c += q / 4
                    h[i] -= q / 4
                    h[j] -= q / 4
                    J[i, j] += q / 4
        return h, J, c

    def diagonal(self) -> np.ndarray:
        """All 2^n energies, index = bitstring with qubit 0 as least-significant bit."""
        n = self.n
        if n > 30:
            raise ValueError("diagonal() is for n <= 30")
        idx = np.arange(2 ** n, dtype=np.uint64)
        e = np.full(2 ** n, self.offset)
        bits = [((idx >> np.uint64(i)) & np.uint64(1)).astype(np.float64) for i in range(n)]
        for i in range(n):
            if self.Q[i, i]:
                e += self.Q[i, i] * bits[i]
            for j in range(i + 1, n):
                if self.Q[i, j]:
                    e += self.Q[i, j] * bits[i] * bits[j]
        return e

    def brute_force(self):
        e = self.diagonal()
        k = int(np.argmin(e))
        return e[k], np.array([(k >> i) & 1 for i in range(self.n)])
