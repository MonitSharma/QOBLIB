"""Filesystem locations. The upstream library is cloned by tools/setup_qoblib.sh."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
QOBLIB = ROOT / "external" / "QOBLIB"
PROBLEMS = ROOT / "problems"
SUBMISSIONS = ROOT / "submissions"

CLASSES = {
    "01": "01-marketsplit", "02": "02-labs", "03": "03-birkhoff", "04": "04-steiner",
    "05": "05-sports", "06": "06-portfolio", "07": "07-independentset",
    "08": "08-network", "09": "09-routing", "10": "10-topology",
}


def instances(cls: str) -> Path:
    """Upstream instance folder of a class, e.g. ``instances("07")``."""
    return QOBLIB / CLASSES[cls] / "instances"


def results(cls: str) -> Path:
    """Our curated results folder for a class."""
    return PROBLEMS / CLASSES[cls] / "results"
