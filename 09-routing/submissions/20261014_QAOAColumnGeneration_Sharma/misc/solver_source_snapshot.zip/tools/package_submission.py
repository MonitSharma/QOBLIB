"""Package results into a QOBLIB submission folder.

    python tools/package_submission.py MANIFEST.json

MANIFEST.json:
{
  "problem_dir": "09-routing",
  "submission": "20261009_RouteEnumSP_Sharma",
  "readme": "Markdown describing the method (goes to the submission root README.md)",
  "common": {  any template column by name, e.g. "Modeling Approach", "Workflow",
               "Algorithm Type", "Paradigm", "Hardware Specifications", "Remarks" },
  "instances": [
     {"instance": "XSH-n20-k4-21", "solution": "path/to/file", "ext": "sol",
      "columns": { "Best Objective Value": 842, "Optimality Bound": 842,
                   "Total Runtime": 1.2, ... },
      "time_series": [[{"Time": 0.5, "Incumbent": 842}]]   (optional)
     }, ...
  ]
}
Paths in the manifest are relative to the repo root. Output goes to
submissions/<problem_dir>/<submission>/<instance>/ in the layout check_submission.py
expects. Submitter / Affiliation / Date / Reference default from tools/submitter.json.
"""
from __future__ import annotations

import csv
import gzip
import json
import shutil
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from qobench.submission import COLUMNS  # noqa: E402

DEFAULTS = {c: "N/A" for c in COLUMNS}


def main(manifest_path: Path) -> Path:
    man = json.loads(manifest_path.read_text(encoding="utf-8"))
    who = json.loads((ROOT / "tools" / "submitter.json").read_text())
    base = dict(DEFAULTS)
    base.update({
        "Submitter": who["submitter"], "Affiliation": who["affiliation"],
        "Date": man.get("date", time.strftime("%Y-%m-%d")),
        "Reference": who["reference_repo"],
        "Algorithm Type": "Deterministic", "Paradigm": "Classical",
        "# Runs": 1, "# Feasible Runs": 1, "# Successful Runs": 1, "Success Threshold": 0,
        "GPU Runtime": 0, "QPU Runtime": 0, "Other HW Runtime": 0,
    })
    base.update(man.get("common", {}))
    out = ROOT / "submissions" / man["problem_dir"] / man["submission"]
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    if man.get("readme"):
        (out / "README.md").write_text(man["readme"], encoding="utf-8")
    for inst in man["instances"]:
        name = inst["instance"]
        d = out / name
        d.mkdir()
        row = dict(base)
        row["Problem"] = name
        row.update(inst.get("columns", {}))
        missing = set(row) - set(COLUMNS)
        if missing:
            sys.exit(f"{name}: unknown columns {missing}")
        with (d / f"{name}_summary.csv").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=COLUMNS)
            w.writeheader()
            w.writerow(row)
        shutil.copyfile(ROOT / inst["solution"], d / f"{name}_solution.{inst.get('ext', 'sol')}")
        if inst.get("time_series") is not None:
            with gzip.open(d / f"{name}_objective_time_series.json.gz", "wt") as fh:
                json.dump(inst["time_series"], fh)
    print(f"wrote {len(man['instances'])} instance(s) to {out.relative_to(ROOT)}")
    return out


if __name__ == "__main__":
    main(Path(sys.argv[1]))
