Route #1: 12 10 11 6
Route #2: 17 3 9 18 2 1
Route #3: 16 7 19 8 4
Route #4: 15 20 13 5 14
Cost 973
