Route #1: 10 13 2 4
Route #2: 14 1 5 15 12
Route #3: 19 17 18 6 11 8
Route #4: 7 9 20 16 3
Cost 718
