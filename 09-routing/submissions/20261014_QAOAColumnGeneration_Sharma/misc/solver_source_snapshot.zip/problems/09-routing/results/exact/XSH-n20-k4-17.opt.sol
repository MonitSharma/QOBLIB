Route #1: 14 5 2 15 4
Route #2: 17 6 10 1
Route #3: 19 8 9 16 11 3
Route #4: 20 12 7 18 13
Cost 605
