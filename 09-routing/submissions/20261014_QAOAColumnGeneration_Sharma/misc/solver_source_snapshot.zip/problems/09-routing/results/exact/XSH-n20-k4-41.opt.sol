Route #1: 16 9 4 17 11 15
Route #2: 14 18 12
Route #3: 8 10 1 6 19 2
Route #4: 7 3 13 20 5
Cost 736
