Route #1: 10 14 9
Route #2: 11 4 16 12 5
Route #3: 8 3 6 18 2
Route #4: 17 19 15 7 1 20 13
Cost 717
