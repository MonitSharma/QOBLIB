Route #1: 5 3 11 1
Route #2: 14 16 8 17 13 2
Route #3: 12 6 18 7
Route #4: 20 9 4 15 10 19
Cost 842
