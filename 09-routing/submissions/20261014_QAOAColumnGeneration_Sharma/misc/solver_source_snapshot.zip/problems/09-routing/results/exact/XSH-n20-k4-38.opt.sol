Route #1: 13 2 5 14 4
Route #2: 10 3 8 16 15 1
Route #3: 19 12 18 6
Route #4: 20 11 9 17 7
Cost 991
