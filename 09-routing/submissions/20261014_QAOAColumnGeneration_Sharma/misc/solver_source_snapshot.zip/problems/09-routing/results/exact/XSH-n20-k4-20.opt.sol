Route #1: 12 15 9 13 2 3
Route #2: 17 18 5 4 6
Route #3: 19 16 14 7
Route #4: 20 8 10 1 11
Cost 648
