"""Exact CVRP for small n by complete route enumeration + set partitioning.

1. Held-Karp DP over *every* capacity-feasible customer subset S (bitmask over n <= ~24
   customers): dp[S][j] = cheapest depot -> S -> j path visiting all of S, ending at j.
   route_cost[S] = min_j dp[S][j] + c[j][0]  is the optimal tour cost serving exactly S.
2. Set partitioning (Gurobi): choose subsets covering each customer exactly once, using
   at most K routes, minimising total route cost.

Because step 1 enumerates every feasible route with its optimal sequencing, the optimum
of step 2 equals the CVRP optimum; Gurobi's proven-optimal status is a proof of
optimality (same objective as QOBLIB's model: rounded Euclidean distances, <= K vehicles).

Usage: python cvrp_sp.py <instance.vrp> [--threads 8] [--out DIR]
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from numba import njit

import gurobipy as gp
from gurobipy import GRB

from cvrp_exact import read_vrp


@njit(cache=True)
def held_karp(c, d, Q):
    n = c.shape[0] - 1                       # customers 1..n -> bits 0..n-1
    full = 1 << n
    load = np.zeros(full, np.int64)
    for S in range(1, full):
        low = S & -S
        b = 0
        while (1 << b) != low:
            b += 1
        load[S] = load[S ^ low] + d[b + 1]
    INF = 1 << 60
    dp = np.full((full, n), INF, np.int64)
    for j in range(n):
        if d[j + 1] <= Q:
            dp[1 << j, j] = c[0, j + 1]
    route = np.full(full, INF, np.int64)
    for S in range(1, full):
        if load[S] > Q:
            continue
        best = INF
        for j in range(n):
            if not (S >> j) & 1:
                continue
            P = S ^ (1 << j)
            if P:
                v = INF
                for i in range(n):
                    if (P >> i) & 1 and dp[P, i] < INF:
                        w = dp[P, i] + c[i + 1, j + 1]
                        if w < v:
                            v = w
                dp[S, j] = v
            tot = dp[S, j] + c[j + 1, 0]
            if tot < best:
                best = tot
        route[S] = best
    return route, dp


def tour(S, dp, c, n):
    """Reconstruct the optimal visiting order of subset S from the DP table."""
    end = min((j for j in range(n) if S >> j & 1), key=lambda j: dp[S, j] + c[j + 1, 0])
    order, cur, P = [end], end, S ^ (1 << end)
    while P:
        prev = min((i for i in range(n) if P >> i & 1), key=lambda i: dp[P, i] + c[i + 1, cur + 1])
        order.append(prev)
        cur, P = prev, P ^ (1 << prev)
    return [j + 1 for j in reversed(order)]


def solve(path: Path, threads: int):
    name, N, K, Q, d, dist = read_vrp(path)
    c = np.array(dist, np.int64)
    dem = np.array(d, np.int64)
    n = N - 1
    t0 = time.time()
    route, dp = held_karp(c, dem, Q)
    cols = np.nonzero(route < (1 << 60))[0]
    cols = cols[cols > 0]
    t_enum = time.time() - t0

    m = gp.Model(name)
    m.Params.OutputFlag = 0
    m.Params.Threads = threads
    m.Params.MIPGap = 0
    y = m.addMVar(len(cols), vtype=GRB.BINARY, obj=route[cols].astype(float))
    for i in range(n):
        mask = ((cols >> i) & 1).astype(bool)
        m.addConstr(y[np.nonzero(mask)[0]].sum() == 1)
    m.addConstr(y.sum() <= K)
    m.optimize()
    chosen = [int(cols[k]) for k in np.nonzero(y.X > 0.5)[0]]
    routes = [tour(S, dp, c, n) for S in chosen]
    cost = sum(int(route[S]) for S in chosen)
    return {
        "name": name, "routes": routes, "cost": cost, "bound": m.ObjBound,
        "proven_optimal": m.Status == GRB.OPTIMAL, "n_routes_enumerated": int(len(cols)),
        "enum_seconds": round(t_enum, 2), "total_seconds": round(time.time() - t0, 2),
    }


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("vrp", type=Path)
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--out", type=Path, default=Path(__file__).resolve().parents[1] / "results")
    a = ap.parse_args()
    res = solve(a.vrp, a.threads)
    a.out.mkdir(parents=True, exist_ok=True)
    tag = "opt" if res["proven_optimal"] else "bst"
    sol = a.out / f"{res['name']}.{tag}.sol"
    sol.write_text("".join(f"Route #{k + 1}: {' '.join(map(str, r))}\n"
                           for k, r in enumerate(res["routes"])) + f"Cost {res['cost']}\n")
    (a.out / f"{res['name']}.json").write_text(json.dumps(res, indent=1))
    print(json.dumps(res))
