"""Exact CVRP via a single-commodity-flow MIP (Gurobi).

    min  sum_{i!=j} c_ij x_ij
    s.t. sum_j x_ij = 1,  sum_j x_ji = 1          for every customer i
         sum_j x_0j = sum_j x_j0 <= K               (fleet limit, as in the QOBLIB model)
         sum_j f_ji - sum_j f_ij = d_i               for every customer i (load delivered)
         d_j x_ij <= f_ij <= (Q - d_i) x_ij          (load carried on arc i->j)
         x binary, f >= 0

c_ij is the TSPLIB EUC_2D distance (Euclidean rounded to the nearest integer), which is
what QOBLIB's 09-routing checker uses.  Rounded capacity inequalities
x(delta(S)) >= 2 ceil(d(S)/Q) are added as lazy cuts on integer solutions to tighten the
model (the flow model alone is already exact).

Usage: python cvrp_exact.py <instance.vrp> [--time 3600] [--out DIR]
"""
from __future__ import annotations

import argparse
import math
import time
from pathlib import Path

import gurobipy as gp
from gurobipy import GRB


def read_vrp(path: Path):
    coords, demand, cap, k = {}, {}, None, None
    section = None
    for raw in path.read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("CAPACITY"):
            cap = int(line.split(":")[1])
        elif line.startswith("NAME"):
            name = line.split(":")[1].strip()
            k = int(name.split("-k")[1].split("-")[0])
        elif line in ("NODE_COORD_SECTION", "DEMAND_SECTION", "DEPOT_SECTION"):
            section = line
        elif line == "EOF":
            break
        elif section == "NODE_COORD_SECTION":
            i, x, y = line.split()
            coords[int(i) - 1] = (float(x), float(y))
        elif section == "DEMAND_SECTION":
            i, d = line.split()
            demand[int(i) - 1] = int(d)
    n = len(coords)
    dist = [[0 if i == j else int(math.floor(math.dist(coords[i], coords[j]) + 0.5))
             for j in range(n)] for i in range(n)]
    return name, n, k, cap, [demand[i] for i in range(n)], dist


def solve(path: Path, time_limit: float, threads: int = 0):
    name, n, K, Q, d, c = read_vrp(path)
    V, C = range(n), range(1, n)
    m = gp.Model(name)
    m.Params.OutputFlag = 1
    m.Params.TimeLimit = time_limit
    m.Params.LazyConstraints = 1
    if threads:
        m.Params.Threads = threads
    A = [(i, j) for i in V for j in V if i != j and d[i] + d[j] <= Q]
    x = m.addVars(A, vtype=GRB.BINARY, obj={a: c[a[0]][a[1]] for a in A}, name="x")
    f = m.addVars(A, lb=0.0, name="f")
    for i in C:
        m.addConstr(x.sum(i, "*") == 1)
        m.addConstr(x.sum("*", i) == 1)
        m.addConstr(f.sum("*", i) - f.sum(i, "*") == d[i])
    m.addConstr(x.sum(0, "*") <= K)
    m.addConstr(x.sum("*", 0) == x.sum(0, "*"))
    for (i, j) in A:
        m.addConstr(f[i, j] <= (Q - d[i]) * x[i, j])
        m.addConstr(f[i, j] >= d[j] * x[i, j])
    # Valid inequality: no 2-cycles between customers.
    for i in C:
        for j in C:
            if i < j and (i, j) in x and (j, i) in x:
                m.addConstr(x[i, j] + x[j, i] <= 1)

    def routes_from(vals):
        succ = {}
        for (i, j), v in vals.items():
            if v > 0.5:
                succ.setdefault(i, []).append(j)
        routes = []
        for start in succ.get(0, []):
            r, cur = [], start
            while cur != 0:
                r.append(cur)
                cur = succ[cur][0]
            routes.append(r)
        return routes

    def cb(model, where):
        if where != GRB.Callback.MIPSOL:
            return
        vals = model.cbGetSolution(x)
        # Rounded capacity cut for every route's customer set (cheap, always valid).
        for r in routes_from(vals):
            S = set(r)
            need = 2 * math.ceil(sum(d[i] for i in S) / Q)
            cut = gp.quicksum(x[i, j] for (i, j) in A if (i in S) != (j in S))
            model.cbLazy(cut >= need)

    t0 = time.time()
    m.optimize(cb)
    routes = routes_from({a: x[a].X for a in A}) if m.SolCount else []
    cost = sum(c[0][r[0]] + sum(c[r[i]][r[i + 1]] for i in range(len(r) - 1)) + c[r[-1]][0]
               for r in routes)
    return {
        "name": name, "routes": routes, "cost": cost, "bound": m.ObjBound,
        "status": m.Status, "runtime": time.time() - t0, "gap": m.MIPGap if m.SolCount else None,
    }


def write_sol(res, out: Path):
    tag = "opt" if res["status"] == GRB.OPTIMAL else "bst"
    p = out / f"{res['name']}.{tag}.sol"
    lines = [f"Route #{k + 1}: " + " ".join(map(str, r)) for k, r in enumerate(res["routes"])]
    p.write_text("\n".join(lines + [f"Cost {res['cost']}"]) + "\n")
    return p


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("vrp", type=Path)
    ap.add_argument("--time", type=float, default=3600)
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--out", type=Path, default=Path(__file__).resolve().parents[1] / "results")
    a = ap.parse_args()
    res = solve(a.vrp, a.time, a.threads)
    a.out.mkdir(parents=True, exist_ok=True)
    print(res)
    print("written", write_sol(res, a.out))
