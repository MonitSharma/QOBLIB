"""Python mirror of QOBLIB's official checker 09-routing/check/src/bin/check_cvrp.rs (v1.0).

Same rules: solution lines ``Route #k: c1 c2 ...`` (customers numbered 1..n), every
customer exactly once, route load <= capacity, cost = sum of Euclidean distances rounded
half away from zero (Rust f64::round), depot from DEPOT_SECTION.  One deliberate
difference: a ``Cost`` line that disagrees with the computed cost is an error here (the
official checker only warns).  Used when cargo (needed
to build the official binary) is not available; the official checker remains the
authority and must be run before a PR (tools/hpc/validate_submission.sh).

    python -m qvrp.check <submission dir>
"""
from __future__ import annotations

import math
import re
import sys
from pathlib import Path

from .instance import INSTANCES


def _round(x: float) -> int:
    return int(math.floor(x + 0.5)) if x >= 0 else -int(math.floor(-x + 0.5))


def parse_instance(text: str):
    coords, demands, cap, depot, section = [], [], 0, 1, ""
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "NODE_COORD_SECTION" in line:
            section = "coords"; continue
        if "DEMAND_SECTION" in line:
            section = "demands"; continue
        if "DEPOT_SECTION" in line:
            section = "depot"; continue
        if line in ("EOF", "-1"):
            section = "" if section == "depot" else section
            continue
        if line.startswith("CAPACITY"):
            cap = int(line.split(":")[1]); continue
        if line.startswith(("NAME", "DIMENSION", "COMMENT", "TYPE", "EDGE_WEIGHT_TYPE")):
            continue
        parts = line.split()
        if section == "coords" and len(parts) >= 3:
            coords.append((float(parts[1]), float(parts[2])))
        elif section == "demands" and len(parts) >= 2:
            demands.append(int(parts[1]))
        elif section == "depot" and parts[0].isdigit() and int(parts[0]) > 0:
            depot = int(parts[0])
    return coords, demands, cap, depot


def check(instance_file: Path, solution_file: Path) -> tuple[bool, int, str]:
    coords, demands, cap, depot = parse_instance(Path(instance_file).read_text())
    routes, claimed = [], None
    for line in Path(solution_file).read_text().splitlines():
        line = line.strip()
        m = re.search(r"Route\s*#\d+\s*:\s*(.+)", line)
        if m:
            routes.append([int(t) for t in m.group(1).split() if t.isdigit()])
        m = re.search(r"Cost\s+(\d+)", line)
        if m:
            claimed = int(m.group(1))
    n = len(coords) - 1
    d0 = depot - 1
    seen, total, msgs = [False] * (n + 1), 0, []
    for k, r in enumerate(routes, 1):
        load, cost, prev = 0, 0, d0
        for c in r:
            if not 1 <= c <= n:
                return False, total, f"route {k}: customer {c} out of range"
            if seen[c]:
                return False, total, f"route {k}: customer {c} visited twice"
            seen[c] = True
            load += demands[c]
            cost += _round(math.dist(coords[prev], coords[c]))
            prev = c
        cost += _round(math.dist(coords[prev], coords[d0]))
        total += cost
        if load > cap:
            msgs.append(f"route {k}: load {load} > {cap}")
    missing = [c for c in range(1, n + 1) if not seen[c]]
    if missing:
        msgs.append(f"customers not visited: {missing}")
    if claimed is not None and claimed != total:
        msgs.append(f"claimed cost {claimed} != computed {total}")
    return not msgs, total, "; ".join(msgs) or "VALID"


def check_submission(sub: Path) -> list[tuple[str, bool, int, str]]:
    out = []
    for d in sorted(p for p in Path(sub).iterdir() if p.is_dir()):
        sol = d / f"{d.name}_solution.sol"
        ok, cost, msg = check(INSTANCES / f"{d.name}.vrp", sol)
        out.append((d.name, ok, cost, msg))
    return out


if __name__ == "__main__":
    res = check_submission(Path(sys.argv[1]))
    for name, ok, cost, msg in res:
        print(f"{name}: {'OK ' if ok else 'BAD'} cost {cost}  {msg}")
    print(f"{sum(r[1] for r in res)}/{len(res)} valid")
    sys.exit(0 if all(r[1] for r in res) else 1)
