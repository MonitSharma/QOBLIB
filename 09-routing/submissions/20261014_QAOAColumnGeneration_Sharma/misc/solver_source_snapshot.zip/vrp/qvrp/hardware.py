"""Circuits for real devices: Dicke-state QAOA with XY mixers, least-noisy backend choice,
error mitigation, and a local noisy simulator of the chosen device.

Phase 1 (now): circuits are built and transpiled for the chosen IBM backend and run on
``AerSimulator.from_backend`` (that device's calibrated noise) on this machine.
Phase 2 (later): the same circuits go to the device through ``SamplerV2``.

Least noisy, not least busy: for a given circuit every operational backend is scored by
the estimated success probability (ESP) of the transpiled circuit, i.e. the product of
(1 - error) over every gate and readout it actually uses on that device's current
calibration.  The highest ESP wins.

Error mitigation (all compatible with sampling, which is what QAOA needs here):
  * dynamical decoupling on idle qubits (XpXm)             -- hardware option
  * Pauli twirling of 2-qubit gates and of measurements     -- hardware option
  * readout-error mitigation with M3 (mthree)               -- post-processing
  * symmetry verification: XY mixers and the Dicke state conserve Hamming weight, so a
    shot with the wrong number of ones is a detected error and is discarded.  This
    error detection is free, and it exists only because the circuits are
    constraint-preserving.

Credentials come from the repository's .env (IBM_QUANTUM_TOKEN, IBM_QUANTUM_INSTANCE =
CRN); they are never printed or written anywhere else.
"""
from __future__ import annotations

import os
from math import acos, sqrt
from pathlib import Path

import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.circuit.library import XXPlusYYGate

ROOT = Path(__file__).resolve().parents[2]


# -- circuits ---------------------------------------------------------------------------
def _scs(qc: QuantumCircuit, q: list[int], n: int, k: int):
    """Split & cyclic shift SCS_{n,k} of Baertschi & Eidenbenz (FCT 2019) on positions
    q[n-k-1 .. n-1] (0-based list of the circuit's qubits for positions 1..n)."""
    a, b = q[n - 2], q[n - 1]
    qc.cx(a, b)
    qc.cry(2 * acos(sqrt(1 / n)), b, a)
    qc.cx(a, b)
    for l in range(2, k + 1):
        a, mid = q[n - l - 1], q[n - l]
        qc.cx(a, b)
        qc.append(_ccry(2 * acos(sqrt(l / n))), [b, mid, a])
        qc.cx(a, b)


def _ccry(theta: float):
    from qiskit.circuit.library import RYGate
    return RYGate(theta).control(2)


def dicke_circuit(n: int, k: int) -> QuantumCircuit:
    """|D^n_k>: equal superposition of all n-bit strings with k ones (depth O(n))."""
    qc = QuantumCircuit(n, name=f"Dicke({n},{k})")
    q = list(range(n))
    for i in range(n - k, n):
        qc.x(q[i])
    for m in range(n, k, -1):
        _scs(qc, q, m, k)
    for m in range(k, 1, -1):
        _scs(qc, q, m, m - 1)
    return qc


def sparsify_in_subspace(Q: np.ndarray) -> tuple[np.ndarray, float]:
    """Exact coupling sparsification on the weight-k subspace.

    On states with exactly k ones, sum_{i<j} x_i x_j = k(k-1)/2 is a constant, so shifting
    *every* off-diagonal coefficient by the same c changes the energy by c k(k-1)/2 only:
    a global phase of the circuit inside the subspace.  Choosing c = the most frequent
    off-diagonal value zeroes all couplings that share it (here: route pairs that overlap
    in exactly one customer), which removes most two-qubit gates of the cost layer.
    Returns (Q', c)."""
    m = Q.shape[0]
    off = np.round(Q[np.triu_indices(m, 1)], 9)
    vals, cnt = np.unique(off, return_counts=True)
    c = float(vals[np.argmax(cnt)])
    Qs = Q.copy()
    iu = np.triu_indices(m, 1)
    Qs[iu] = Q[iu] - c
    Qs[np.abs(Qs) < 1e-9] = 0.0
    return Qs, c


def qaoa_circuit(Q: np.ndarray, k: int, gammas, betas, pairs, measure: bool = True,
                 init: str = "dicke") -> QuantumCircuit:
    """Initial state + p layers of [cost exp(-i g x^T Q x), XY mixer on ``pairs``]; qubit q = bit q.

    ``init="dicke"``: exact Dicke(k) state (Baertschi-Eidenbenz; matches
    ``qobench.quantum.subspace`` gate for gate, tested in tests/).
    ``init="product"``: every qubit RY-rotated to P(1) = k/m, no two-qubit gates.  All
    later gates conserve Hamming weight and the weight-k component of the product state is
    exactly the Dicke state, so post-selecting weight-k shots reproduces the Dicke circuit's
    output distribution exactly (with acceptance C(m,k) (k/m)^k (1-k/m)^(m-k) noiselessly)."""
    m = Q.shape[0]
    qc = QuantumCircuit(m)
    if init == "dicke":
        qc.compose(dicke_circuit(m, k), inplace=True)
    elif init == "product":
        qc.ry(2 * np.arcsin(np.sqrt(k / m)), range(m))
    else:
        raise ValueError(init)
    for g, b in zip(gammas, betas):
        for i in range(m):
            if Q[i, i]:
                qc.p(-g * Q[i, i], i)
            for j in range(i + 1, m):
                if Q[i, j]:
                    qc.cp(-g * Q[i, j], i, j)
        for i, j in pairs:
            qc.append(XXPlusYYGate(2 * b), [i, j])
    if measure:
        qc.measure_all()
    return qc


# -- IBM access and backend choice ------------------------------------------------------
def service():
    """QiskitRuntimeService from .env (token + CRN); nothing is printed."""
    from dotenv import load_dotenv
    from qiskit_ibm_runtime import QiskitRuntimeService
    load_dotenv(ROOT / ".env")
    token, crn = os.environ.get("IBM_QUANTUM_TOKEN"), os.environ.get("IBM_QUANTUM_INSTANCE")
    if not token:
        raise RuntimeError("IBM_QUANTUM_TOKEN missing from .env")
    return QiskitRuntimeService(channel="ibm_quantum_platform", token=token, instance=crn)


def esp(tqc: QuantumCircuit, backend) -> float:
    """Estimated success probability of a transpiled circuit on the backend's calibration."""
    target, log_p = backend.target, 0.0
    for inst in tqc.data:
        name = inst.operation.name
        if name in ("barrier", "delay"):
            continue
        qargs = tuple(tqc.find_bit(q).index for q in inst.qubits)
        try:
            props = target[name][qargs]
        except KeyError:
            continue
        err = getattr(props, "error", None) if props is not None else None
        if err:
            log_p += np.log1p(-min(err, 0.999))
    return float(np.exp(log_p))


def calibration_summary(backend) -> dict:
    t = backend.target
    two_q = [g for g in ("cz", "ecr", "cx") if g in t.operation_names]
    e2 = [p.error for g in two_q for p in t[g].values() if p is not None and p.error is not None]
    ro = [p.error for p in t["measure"].values() if p is not None and p.error is not None] \
        if "measure" in t.operation_names else []
    return {"backend": backend.name, "qubits": backend.num_qubits, "two_qubit_gate": two_q,
            "median_2q_error": float(np.median(e2)) if e2 else None,
            "median_readout_error": float(np.median(ro)) if ro else None}


def least_noisy(circuit: QuantumCircuit, backends, seed: int = 7, optimization_level: int = 3):
    """Transpile ``circuit`` for every backend; return (best backend, transpiled, table).

    Ranked by ESP of the transpiled circuit on today's calibration (not by queue length)."""
    rows = []
    for be in backends:
        if be.num_qubits < circuit.num_qubits:
            continue
        tqc = transpile(circuit, be, optimization_level=optimization_level, seed_transpiler=seed)
        ops = tqc.count_ops()
        n2q = sum(v for g, v in ops.items() if g in ("cz", "ecr", "cx"))
        rows.append({**calibration_summary(be), "esp": esp(tqc, be), "depth": tqc.depth(),
                     "two_qubit_gates": n2q, "_be": be, "_tqc": tqc})
    rows.sort(key=lambda r: -r["esp"])
    best = rows[0]
    return best["_be"], best["_tqc"], [{k: v for k, v in r.items() if not k.startswith("_")} for r in rows]


# -- execution --------------------------------------------------------------------------
def mitigated_sampler_options() -> dict:
    """SamplerV2 options used in hardware round 1 (kept for reproducibility of that run).
    New runs use ``best_practice_options()``."""
    return {"dynamical_decoupling": {"enable": True, "sequence_type": "XpXm"},
            "twirling": {"enable_gates": True, "enable_measure": True, "num_randomizations": "auto"}}


# Settings established on ibm_kingston in hardware rounds 1-3 (vrp/HARDWARE.md has the evidence).
BEST_PRACTICE = {
    "backend_rule": "highest ESP of the transpiled circuit on today's calibration (not queue length)",
    "qaoa_depth": 1,                      # p = 2 doubled CZ and lowered the gain on 3 of 4 circuits
    "init": "product",                    # beat the Dicke circuit 2.65x vs 2.11x (p = 0.03)
    "sparsify": True,                     # beat full couplings 2.65x vs 2.07x (p = 0.04)
    "layout_seeds": 20,                   # transpile 20 seeds, keep the highest ESP
    "max_cz": 200,                        # <= ~200 CZ: acceptance at its ideal, most of the gain kept
    "shots_small": 1000,                  # 8-11 qubit circuits (95% detection needs 110-630)
    "shots_large": 2500,                  # 16-qubit circuits (95% detection needs 1,700-2,400)
    "cal_shots": 2000,                    # in-job readout calibration (all-0 / all-1), applied with M3
    "replicates": 2,                      # job-to-job spread of the same circuit was about +-30%
    "postselect_weight": True,            # Hamming-weight post-selection (always)
    "m3": True,                           # +7-10% on every setting
    "cost_per_job_s": 1.75, "cost_per_shot_s": 0.3125e-3,   # QPU charge model (48.2 s predicted, 47 s billed)
    # staged master in hardware shape (results/first_stage/): first call picks a PAIR from 10 routes
    # (146-164 CZ instead of 443-496), later selections <= 10 routes, fixes leave <= 11 customers
    # for residual pricing (<= 212 CZ); 26.7% optimal / 1.81% gap vs 29.7% / 1.57% unconstrained
    "staged_master": {"p": 1, "B": 10, "k_first": 2, "min_fix": 2, "B_residual": 10, "max_residual": 11},
    "pricing_p": 1,
}


def best_practice_options() -> dict:
    """SamplerV2 options for new hardware runs: dynamical decoupling (XY4), no twirling.

    Twirling did not help these sampling circuits on 3 of 4 instances; the DD effect was
    inconclusive (best on one circuit, worse than nothing on two), so DD stays on as the
    physically motivated default for idle qubits.  Readout mitigation (M3) and Hamming-weight
    post-selection are applied afterwards from the counts."""
    return {"dynamical_decoupling": {"enable": True, "sequence_type": "XY4"},
            "twirling": {"enable_gates": False, "enable_measure": False}}


def estimate_qpu_seconds(shots_per_job: list[int]) -> float:
    """QPU seconds billed for jobs with the given total shots (calibrated on rounds 1-3)."""
    return sum(BEST_PRACTICE["cost_per_job_s"] + BEST_PRACTICE["cost_per_shot_s"] * s for s in shots_per_job)


def run_noisy_sim(tqc: QuantumCircuit, backend, shots: int, seed: int = 0) -> dict[str, int]:
    """Phase 1: the transpiled circuit on this machine with ``backend``'s noise model."""
    from qiskit_aer import AerSimulator
    sim = AerSimulator.from_backend(backend, seed_simulator=seed)
    return sim.run(tqc, shots=shots).result().get_counts()


def run_hardware(tqc: QuantumCircuit, backend, shots: int) -> dict[str, int]:
    """Phase 2 only: submit to the device with DD + twirling.  Not called in phase 1."""
    from qiskit_ibm_runtime import SamplerV2
    sampler = SamplerV2(mode=backend, options=mitigated_sampler_options())
    res = sampler.run([tqc], shots=shots).result()[0]
    return res.data.meas.get_counts()


def m3_correct(counts: dict[str, int], backend, tqc: QuantumCircuit, simulator=None) -> dict[str, float]:
    """Readout mitigation with M3 on the measured physical qubits.  ``simulator`` (an
    AerSimulator.from_backend) calibrates in phase 1; the device itself in phase 2."""
    import mthree
    from qiskit.transpiler import CouplingMap  # noqa: F401  (mthree imports lazily)
    layout = mthree.utils.final_measurement_mapping(tqc)
    mit = mthree.M3Mitigation(simulator or backend)
    mit.cals_from_system(layout)
    quasi = mit.apply_correction(counts, layout)
    return {k: float(v) for k, v in quasi.nearest_probability_distribution().items()}


def postselect_weight(dist: dict[str, float], k: int) -> tuple[dict[str, float], float]:
    """Symmetry verification: keep outcomes with exactly k ones; returns (renormalised
    distribution, kept fraction).  Bitstrings are Qiskit-ordered (qubit 0 rightmost)."""
    keep = {b: v for b, v in dist.items() if b.replace(" ", "").count("1") == k}
    tot, all_ = sum(keep.values()), sum(dist.values())
    return ({b: v / tot for b, v in keep.items()} if tot else {}), (tot / all_ if all_ else 0.0)
