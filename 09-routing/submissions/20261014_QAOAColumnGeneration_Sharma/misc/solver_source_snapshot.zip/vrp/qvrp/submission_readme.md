# Quantum column generation with XY-mixer QAOA for CVRP (quantum simulator)

**Submitter:** {submitter} ({affiliation}) · **Paradigm:** Quantum Simulator · **Algorithm:** stochastic, {budget} shots per quantum call, 10 independent runs per instance · **AI disclosure:** `assisted` (see below)

## Results

* All {n} instances solved by the quantum workflow; {q_feasible}/{q_runs} runs returned a feasible plan.
* The best of 10 runs equals the proven optimum on **{best_opt}/{n}** instances. The mean gap of the best plan is {mean_gap:.2f}% and the largest is {max_gap:.2f}%.
* {q_opt_runs} of {q_runs} individual runs reached the proven optimum.

The proven optima come from our classical submission (route enumeration + set partitioning). They are quoted for gap reporting only. The solver never reads them.

## Is the quantum part doing the work? A control run

Every seed was also run with **each QAOA circuit replaced by uniform sampling of the same subspace, with the same number of shots**. Everything classical stayed identical: LP, exact tour lengths, staging rules.

| | QAOA (submitted) | uniform-sampling control |
|---|---|---|
| instances whose best of 10 runs is optimal | {best_opt}/{n} | {u_best_opt}/{n} |
| runs at the proven optimum | {q_opt_runs}/{q_runs} | {u_opt_runs}/{u_runs} |
| mean gap of a single run | {q_mean_gap:.2f}% | {u_mean_gap:.2f}% |
| instances with the lower mean cost | {q_better} | {u_better} |

Run by run (same instance, same seed): QAOA gives the cheaper plan in **{pair_q}** runs, uniform sampling in {pair_u}, and {pair_t} tie (Wilcoxon signed-rank p = {pair_p:.1e}).

The budget of {budget} shots was fixed before this campaign, from a separate multi-seed study (55 instances × 3 seeds × budgets 100/300/1000). There, QAOA beat the control on paired runs at 100 shots (125 vs 26, Wilcoxon p = 4·10⁻¹⁸) and at 300 shots (93 vs 56, p = 2·10⁻⁵). At 1,000 shots the gain was not significant (p = 0.09). We submit at the largest budget where the circuits demonstrably carry the result.

## Method

All XSH instances are exact-load (total demand = K·Q), so every route carries exactly Q, and a plan is 4 disjoint routes covering all 20 customers.

| step | runs on | qubits | decides |
|---|---|---|---|
| customer prices λ | classical LP (HiGHS) over the current route pool | none | no route is chosen |
| pricing: propose routes | **QAOA** per route size s: Dicke(20, s) initial state, ring XY mixer, p = 3; cost = quadratic route-length surrogate − λ + exact load-equality penalty | 20 | which customer sets are sampled |
| route length | classical Held–Karp on each sampled set with load exactly Q | none | the length of a sampled route |
| route selection | **QAOA** over exactly-4-route states of a 16-route pool (Dicke(16, 4), XY mixer, p = 4); cost = total length + penalty per shared customer | 16 | which routes are sampled together |
| staging | non-overlapping routes found in the samples, ranked by length + LP bound of the uncovered customers; the best 3 are kept, then **QAOA** pricing and selection rerun on the uncovered customers only | fewer than the first call | which sampled routes are kept |
| last route | forced: the remaining customers carry exactly Q | none | no choice left |

Every route in a submitted plan was either sampled by a QAOA circuit or forced by the routes sampled before it. Angles are CVaR-optimised (L-BFGS-B) on the exact simulator and then sampled with a fixed number of shots. The circuits are simulated exactly in the fixed-Hamming-weight subspace. The simulator is checked gate for gate against the equivalent Qiskit circuits (`tests/test_quantum_core.py`, `tests/test_routing_quantum.py`).

This reworks the qubit-scalable decomposition of [arXiv:2604.22194](https://arxiv.org/abs/2604.22194). The quantum circuits now generate and select whole routes, and constraint-preserving mixers replace slack and tilted penalties.

## Scope

At n = 20 these instances are classically easy: our exact solver proves all 55 optima in under 45 s in total. This entry benchmarks quantum components against known optima and against a matched classical sampling control. It makes no claim of quantum advantage. Runtimes are those of the classical simulation of the circuits, so QPU Runtime is N/A.

## Reproduce

```bash
git clone {repo} && cd quantum_optimization_benchmarking
uv venv --python 3.12 .venv && uv pip install --python .venv -e ".[dev]" -e vrp && bash tools/setup_qoblib.sh
python -m qvrp.submit run --runs 10 --workers 14      # QAOA runs + uniform control
python -m qvrp.submit package                         # this folder
```

Code: `vrp/qvrp/` (`pricing.py`, `colgen.py`, `master.py`, `submit.py`); step-by-step notebooks in `vrp/notebooks/`.

**Hardware:** {hw}.
**Software:** {sw}.

## AI disclosure

**`assisted`** under the QOBLIB [AI policy](https://github.com/ZIB-AOPT/QOBLIB/blob/main/AI_POLICY.md). The solver code (`vrp/qvrp/`, `qobench/quantum/subspace.py`), the tests, the notebooks, the packaging scripts and this README were drafted with Claude Code (model: Claude Opus 5.5, Anthropic). They were then reviewed, run and edited by the submitter, {submitter}, who is responsible for this submission and opened the pull request. The method builds on the submitter's own work (arXiv:2604.22194). No AI system is part of the optimization method.
