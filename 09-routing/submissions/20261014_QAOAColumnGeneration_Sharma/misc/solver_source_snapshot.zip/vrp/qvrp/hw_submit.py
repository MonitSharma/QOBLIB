"""Package the full-instance IBM hardware runs as a QOBLIB submission (paradigm: Quantum Hardware).

    python -m qvrp.hw_submit          # -> submissions/09-routing/<SUBMISSION>/

Layout (as the merged QOBLIB hardware submissions, plus traceability files):
    <SUBMISSION>/README.md                      method, what ran on the QPU, mitigation, results, AI disclosure
    <SUBMISSION>/jobs.csv                       every IBM job: run, round, job id, circuits, QPU seconds
    <SUBMISSION>/<instance>/<instance>_summary.csv              30-column QOBLIB template
    <SUBMISSION>/<instance>/<instance>_solution.sol             the plan (checked with qvrp.check)
    <SUBMISSION>/<instance>/<instance>_objective_time_series.json.gz

Inputs: vrp/results/hardware/fullrun_ibm_run*.json (+ solutions/) written by qvrp.hw_run.
"""
from __future__ import annotations

import json
import platform
import sys
from pathlib import Path

import numpy as np

from .instance import ROOT, Instance

HW = Path(__file__).resolve().parents[1] / "results" / "hardware"
OUT = Path(__file__).resolve().parents[1] / "results" / "quantum_hw"
SUBMISSION = "20261015_QAOAColGenHardware_Sharma"


def _runs():
    return [(f.stem.replace("fullrun_", ""), json.loads(f.read_text())) for f in sorted(HW.glob("fullrun_ibm_run*.json"))]


def _instance_shots(r: dict, replicates: int) -> int:
    return replicates * sum(c.get("shots", 0) for c in r["calls"])


def main():
    import qiskit
    import qiskit_ibm_runtime
    who = json.loads((ROOT / "tools" / "submitter.json").read_text())
    runs = _runs()
    OUT.mkdir(parents=True, exist_ok=True)
    jobs_rows, instances, table = [], [], []
    for tag, run in runs:
        rep = run["replicates"]
        ok = [r for r in run["results"] if r.get("cost") is not None]
        tot_shots = sum(_instance_shots(r, rep) for r in ok)
        billed = run["billed_qpu_s"] or 0
        for k, rd in enumerate(run["rounds"], 1):
            for j in rd.get("jobs") or [{"job_id": rd.get("job_id"), "qpu_seconds": rd.get("qpu_seconds"),
                                          "circuits": rd.get("circuits")}]:
                jobs_rows.append(f"{tag},{k},{j['job_id']},{j.get('circuits')},{j.get('qpu_seconds')},"
                                 f"{run['instances'][0]}..{run['instances'][-1]},{bool(rd.get('replayed'))}")
        cal = run["backend"]
        nrep = run.get("replayed_rounds", 0)
        replay_note = (
            f" The process of this run stopped after round {nrep} of {len(run['rounds'])} (IBM closed the batch); "
            f"rounds 1-{nrep} were not re-executed: their measured counts and in-job calibrations were fetched "
            f"from IBM by job ID and replayed (qvrp.executor.ReplayBackend, every request matched to its stored "
            f"circuit, worst total-variation distance "
            f"{max(rd.get('match_tvd_max', 0) for rd in run['rounds']):.3f}), and the remaining rounds ran live. "
            f"Total Runtime = wall clock of the resumed process.") if nrep else ""
        for r in ok:
            name, inst = r["instance"], Instance.load(r["instance"])
            opt = inst.optimum()
            qpu = round(billed * _instance_shots(r, rep) / tot_shots, 2) if tot_shots else "N/A"
            sol = OUT / "solutions" / f"{name}.sol"
            sol.parent.mkdir(parents=True, exist_ok=True)
            sol.write_text((HW / f"fullrun_{tag}" / "solutions" / f"{name}.sol").read_text())
            trace = [{"Time": 0.0, "Incumbent": None}] + r["trace"]
            if trace[-1]["Time"] < run["wall_s"]:
                trace.append({"Time": run["wall_s"], "Incumbent": r["cost"]})
            hw_q = max([c["qubits"] for c in r["calls"]], default=0)
            gap = 100 * (r["cost"] - opt) / opt
            table.append({"instance": name, "cost": r["cost"], "optimum": opt, "gap": gap, "run": tag, "qpu": qpu})
            remarks = (
                f"One run (seed 0) with every stage-2 quantum call on {cal['backend']}: the first route selection "
                f"(pick a pair from 10 pool routes), residual pricing over at most 11 uncovered customers, and every later "
                f"selection; largest hardware circuit {hw_q} qubits. Stage 1 (column generation with 20-customer pricing "
                f"circuits) used the exact simulator, because 20-qubit circuits do not survive current hardware noise; it "
                f"only builds the candidate-route pool. QPU Runtime = this instance's share (by shots) of the {billed} s "
                f"billed for its run ({tag}), whose jobs were shared by {len(ok)} instances; Total Runtime = wall clock of "
                f"that whole run, queue included. Proven optimum (our classical submission) = {opt}; gap {gap:.2f}%. "
                f"Job IDs: jobs.csv.{replay_note} AI disclosure: assisted (see README).")
            instances.append({
                "instance": name, "ext": "sol",
                "solution": str(sol.relative_to(ROOT)).replace("\\", "/"),
                "columns": {
                    "Best Objective Value": r["cost"], "# Runs": 1, "# Feasible Runs": 1, "# Successful Runs": 1,
                    "# Decision Variables": hw_q, "# Binary Variables": hw_q,
                    "Total Runtime": round(run["wall_s"], 1),
                    "Time to Solution": round(r["trace"][-1]["Time"], 1) if r["trace"] else "N/A",
                    "QPU Runtime": qpu, "Remarks": remarks,
                },
                "time_series": [trace],
            })
    instances.sort(key=lambda x: x["instance"])
    table.sort(key=lambda x: x["instance"])
    (OUT / "jobs.csv").write_text("run,round,job_id,circuits,qpu_seconds,instances,replayed\n" + "\n".join(jobs_rows) + "\n")
    cal = runs[-1][1]["backend"]
    g = np.array([t["gap"] for t in table])
    total_qpu = sum(r["billed_qpu_s"] or 0 for _, r in runs)
    hw_spec = (f"Quantum: {cal['backend']} (IBM Heron r2, {cal['qubits']} qubits; median CZ error "
               f"{100 * cal['median_2q_error']:.2f}%, median readout error {100 * cal['median_readout_error']:.2f}% at run time), "
               f"Qiskit Runtime SamplerV2 in batch mode. Classical: {who['hardware_workstation']}")
    resumed = "".join(
        f"\n**Resumed run ({tag}).** After round {r['replayed_rounds']}, IBM closed the batch and the next job was "
        f"refused, which stopped the process. Rounds 1–{r['replayed_rounds']} were not run again. A new process fetched "
        f"their measured counts, transpiled circuits and in-job readout calibrations from IBM by job ID. Each request "
        f"was matched to its stored circuit by noiseless output distribution (largest total-variation distance "
        f"{max(rd.get('match_tvd_max', 0) for rd in r['rounds']):.3f}), and the draws were made in the original "
        f"circuit order (`qvrp.executor.ReplayBackend`). The remaining rounds ran live. Every QPU second is "
        f"counted once in `jobs.csv`.\n"
        for tag, r in runs if r.get("replayed_rounds"))
    comparison = ""
    cmp_csv = HW / "fullrun_comparison.csv"
    if cmp_csv.exists():
        import pandas as pd
        from scipy.stats import wilcoxon
        d = pd.read_csv(cmp_csv)
        gp = {c: 100 * (d[c] - d.optimum) / d.optimum for c in ("hardware", "sim_seed0", "uniform_seed0")}
        dx = (d.hardware - d.uniform_seed0)
        p = wilcoxon(dx[dx != 0]).pvalue
        comparison = (
            "| same pipeline, same seed | valid plans | at the proven optimum | mean gap |\n|---|---:|---:|---:|\n"
            + "".join(f"| {lab} | {len(d)}/{len(d)} | {int((gp[c] == 0).sum())} | {gp[c].mean():.2f}% |\n" for c, lab in
                      (("hardware", f"**{cal['backend']} (this submission)**"), ("sim_seed0", "noiseless simulation"),
                       ("uniform_seed0", "uniform sampling in place of every circuit")))
            + f"\n* The hardware plan is identical to the noiseless simulation on **{int((d.hardware == d.sim_seed0).sum())}"
            f" of {len(d)}** instances: device noise, after mitigation and post-selection, rarely changed the outcome.\n"
            f"* Against uniform sampling at equal shots, hardware is cheaper on {int((dx < 0).sum())} instances, tied on "
            f"{int((dx == 0).sum())} and worse on {int((dx > 0).sum())} (Wilcoxon p = {p:.2f}, **no significant difference**). "
            "The hardware-shaped subproblems are small (at most 462 feasible states), and 2,000 shots per circuit cover them "
            "even when sampled uniformly. The gain of QAOA over random sampling shows at lower shot budgets and on larger "
            "subproblems (our simulator submission, `20261014_QAOAColumnGeneration_Sharma`).\n")
    readme = f"""# Quantum column generation with XY-mixer QAOA for CVRP, on IBM quantum hardware

**Submitter:** {who['submitter']} ({who['affiliation']}) · **Paradigm:** Quantum Hardware ({cal['backend']}) · **Algorithm:** stochastic, one run per instance · **AI disclosure:** `assisted` (see below)

## Results

* {len(table)} instances, every one with a feasible plan (checked with `qvrp.check`, a Python mirror of QOBLIB's `check_cvrp`).
* **{int((g == 0).sum())}/{len(table)}** plans equal the proven optimum; mean gap **{g.mean():.2f}%**, largest {g.max():.2f}%.
* {total_qpu} s of QPU time in total across {len(jobs_rows)} jobs (Open plan).

The proven optima come from our classical submission (`20261009_RouteEnumSP_Sharma`) and are quoted for gap reporting only.

## What ran on the quantum computer

All XSH instances are exact-load (total demand = K·Q), so every truck leaves full. A plan is 4 disjoint routes that each carry exactly Q.

| step | where | qubits |
|---|---|---|
| stage 1: column generation. LP prices; QAOA proposes routes per route size (20-customer circuits); exact tour lengths | **exact simulator** (20-qubit circuits do not survive current noise); builds the candidate-route pool only | 20 (simulated) |
| stage 2a: first route selection, a pair from the 10 best pool routes (weight-2 QAOA) | **{cal['backend']}** | 10 |
| stage 2b: residual pricing, routes for the at most 11 uncovered customers (QAOA per route size) | **{cal['backend']}** | ≤ 11 |
| stage 2c: residual route selection (weight-k QAOA over ≤ 10 routes) | **{cal['backend']}** | ≤ 10 |
| last route | forced (the remaining customers carry exactly Q) | none |

Every route in a submitted plan was sampled from a QPU circuit, or forced by the routes sampled before it.

**Circuits:**
* QAOA depth p = 1; product-state start (each qubit at P(1) = k/m) plus Hamming-weight post-selection, which reproduces the Dicke-state QAOA exactly;
* XY ring mixer; couplings sparsified inside the weight-k subspace (exact);
* angles optimised on an exact simulator;
* layout: the highest estimated success probability of 6 transpiler seeds; at most about 250 CZ per circuit.

**Execution:** all instances and search branches advance in lock-step, so each round of circuits is one set of jobs (at most 298 circuits each) in one IBM Batch; 4 rounds per run. Every circuit runs as 2 replicates on different layouts, 1,000 shots each.
{resumed}

**Error mitigation:**
* dynamical decoupling (XY4);
* readout calibration (all-0 / all-1) measured in every job and applied with M3;
* Hamming-weight post-selection: a shot with the wrong number of routes or customers is a detected error and is discarded;
* the two replicates are pooled.

How these settings were chosen (calibration rounds on the same device): `vrp/HARDWARE.md` in {who['reference_repo']}.

## Comparison (same pipeline, same seed)

{comparison}
Per-instance numbers: `vrp/results/hardware/fullrun_comparison.csv` and `vrp/results/RESULTS.md` in the reference repository.

## Reproduce

```bash
python -m qvrp.hw_run --mode exact --instances XSH-n20-k4-15   # cost estimate
python -m qvrp.hw_run --mode ibm   --instances XSH-n20-k4-15 --budget 30
python -m qvrp.hw_submit
```

**Hardware:** {hw_spec}.
**Software:** Python {platform.python_version()}, Qiskit {qiskit.__version__}, qiskit-ibm-runtime {qiskit_ibm_runtime.__version__}, mthree, numpy, scipy (HiGHS).

## AI disclosure

**`assisted`** (QOBLIB [AI policy](https://github.com/ZIB-AOPT/QOBLIB/blob/main/AI_POLICY.md)). The solver and hardware-execution code (`vrp/qvrp/`), the packaging and this README were drafted with Claude Code (model: Claude Opus 5.5, Anthropic). They were reviewed, run and edited by the submitter, {who['submitter']}, who is responsible for this submission and opens the pull request. The method builds on the submitter's own work (arXiv:2604.22194). No AI system is part of the optimization method.
"""
    manifest = {
        "problem_dir": "09-routing", "submission": SUBMISSION, "date": "2026-10-15", "readme": readme,
        "common": {
            "Modeling Approach": ("Set partitioning over exact-load routes by column generation; route selection QUBO "
                                  "(<= 10 binary variables, overlap penalty) and residual pricing QUBO (<= 11 binary "
                                  "variables, exact load-equality penalty), both sampled on the QPU with XY-mixer QAOA"),
            "# Integer Variables": 0, "# Continuous Variables": 0, "# Non-Zero Coefficients": "N/A",
            "Coefficients Type": "real", "Coefficients Range": "N/A",
            "Workflow": ("Pre-processing: EUC_2D distances; route sizes able to carry exactly Q. Stage 1 (exact simulator): "
                         "column generation with QAOA pricing over all 20 customers builds the candidate-route pool. Stage 2 "
                         "(QPU, ibm_kingston): QAOA selects a pair of routes from the 10 best pool routes; non-overlapping "
                         "sampled pairs are ranked by length + LP bound of the uncovered customers and the best 3 are kept; "
                         "QAOA pricing over the at most 11 uncovered customers and QAOA selection of the remaining routes "
                         "run on the QPU; the last route is forced. Circuits: p = 1, product-state start + Hamming-weight "
                         "post-selection (exact Dicke-state QAOA), XY ring mixer, subspace-sparsified couplings, best-ESP "
                         "layout, 2 replicates x 1,000 shots; DD (XY4), in-job readout calibration + M3. All instances run "
                         "in lock-step, one set of jobs per round in an IBM Batch. Post-processing: best complete plan."),
            "Algorithm Type": "Stochastic", "Paradigm": "Quantum Hardware", "Success Threshold": 0,
            "Optimality Bound": "N/A", "Hardware Specifications": hw_spec,
            "CPU Runtime": "N/A", "GPU Runtime": "N/A", "Other HW Runtime": "N/A",
        },
        "instances": instances,
    }
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    (OUT / "summary.json").write_text(json.dumps(table, indent=1))
    sys.path.insert(0, str(ROOT / "tools"))
    from package_submission import main as package
    out = package(OUT / "manifest.json")
    (out / "jobs.csv").write_text((OUT / "jobs.csv").read_text())
    print(f"{len(table)} instances; optimal {int((g == 0).sum())}; mean gap {g.mean():.2f}%; QPU {total_qpu} s")


if __name__ == "__main__":
    main()
