"""Stage 2: restricted-master LP and the staged quantum route selection.

Set partitioning over the route pool P (exact-load routes):

    min sum_S c_S y_S   s.t.  sum_{S ni i} y_S = 1  for every customer i,  y binary.

Exact load makes sum_S y_S = K implied, so the covering duals are the Lagrange multipliers.

Quantum selection of k routes from a B-route pool = QAOA in the weight-k subspace (Dicke
state + XY mixer: every sample has exactly k routes) on

    E(y) = sum_S c_S y_S + P * sum_{S<T} |S n T| y_S y_T.

With exactly k exact-load routes over customers R (d(R) = kQ), "no overlap" <=> "R covered
exactly once", so feasible states are exactly the solutions inside the pool.

**Staged (qubit-scalable) selection.**  One call on the whole problem rarely samples a
feasible 4-route state (first full run: 19/55 never did).  But samples routinely contain
2 or 3 routes that do not overlap.  So each stage keeps those:

    stage(R, k):  sample k-subsets of a small pool of routes inside R
                  complete feasible samples -> candidate solutions
                  disjoint sub-collections of the sampled states, ranked by reduced cost
                  for the best few: fix them, re-price the uncovered customers with a
                  *smaller* pricing circuit (|R'| qubits), recurse on stage(R', k - j)
    stage(R, 1):  forced: the last route must be exactly R (its load is Q)

Every route in a returned solution was either sampled by a quantum call or is forced by
the routes sampled before it (the last uncovered customers form the only remaining route),
and later calls use fewer qubits than the first.  ``sampler="uniform"`` swaps every circuit for uniform sampling of
the same subspaces with the same shots (the classical stand-in).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from itertools import combinations

import numpy as np
from scipy.optimize import linprog

from qobench.quantum import WeightSubspace, qaoa_optimize, qaoa_state

from .instance import Instance, incidence, tsp_exact


def solve_lp(masks, costs, n: int, big_m: float, customers=None):
    """LP relaxation of the restricted master over ``customers`` (default all), with
    artificial cover columns of cost big_m.  Returns (objective, duals (n,), y, artificial)."""
    cust = np.arange(n) if customers is None else np.asarray(customers) - 1
    X = incidence(masks, n).astype(float)[:, cust] if len(masks) else np.zeros((0, len(cust)))
    c = np.r_[np.asarray(costs, float), np.full(len(cust), big_m)]
    A = np.c_[X.T, np.eye(len(cust))]
    r = linprog(c, A_eq=A, b_eq=np.ones(len(cust)), bounds=(0, None), method="highs")
    if r.status != 0:
        raise RuntimeError(r.message)
    lam = np.zeros(n)
    lam[cust] = r.eqlin.marginals
    return float(r.fun), lam, r.x[: len(masks)], float(r.x[len(masks):].sum())


def select_pool(masks, costs, lam, B: int, rule: str = "lp+rc", y_lp=None):
    """Indices of the B pool routes handed to a quantum call.

    rc     : lowest reduced cost c_S - lambda(S)
    lp+rc  : LP-support routes first (y > 0), then lowest reduced cost
    """
    masks, costs = np.asarray(masks), np.asarray(costs, float)
    rc = costs - incidence(masks, lam.size) @ lam
    order = list(np.argsort(rc, kind="stable"))
    if rule == "lp+rc" and y_lp is not None:
        sup = [int(k) for k in np.argsort(-y_lp) if y_lp[k] > 1e-7]
        s = set(sup)
        order = sup + [k for k in order if k not in s]
    return np.array(order[:B], dtype=int)


def master_energies(sub: WeightSubspace, X: np.ndarray, cost: np.ndarray, P: float):
    Y = sub.bits().astype(float)
    O = X.astype(float) @ X.T.astype(float)
    np.fill_diagonal(O, 0.0)
    overlap = 0.5 * np.einsum("ki,ij,kj->k", Y, O, Y, optimize=True)
    return Y @ cost + P * overlap, overlap == 0


@dataclass
class MasterConfig:
    B: int = 16                 # qubits of the first selection call
    B_residual: int = 12        # qubits of later (residual) selection calls
    p: int = 4
    alpha: float = 0.1          # CVaR level
    restarts: int = 3
    maxfun: int = 3000
    penalty: float = 1.0        # P = penalty * (largest pool route cost)
    mixer: str = "ring"
    rule: str = "lp+rc"
    shots: int = 1000           # shots per selection call
    beam: int = 3               # partial solutions continued per stage
    scan_states: int = 64       # most frequent sampled states mined for disjoint routes
    residual_pricing: bool = True
    residual_rounds: int = 2    # pricing rounds on the uncovered customers
    residual_shots: int = 500
    max_calls: int = 40
    sampler: str = "qaoa"       # "qaoa" | "uniform"
    staged: bool = True         # False = a single K-route call (first version)
    k_first: int | None = None  # routes per sample in the first call (None = K); e.g. 2 = pick a pair first
    min_fix: int = 1            # fix at least this many sampled routes per stage (2 keeps residuals <= ~11 customers)
    max_residual: int | None = None   # prefer fixes leaving <= this many customers (hardware pricing limit)


def select_call(costs_pool, X_pool, k: int, cfg: MasterConfig, rng, seed: int = 0, executor=None):
    """One quantum selection call: k of len(costs_pool) routes.  Returns the samples and
    the exact output distribution (for scoring).  With an ``executor`` (hardware mode) the
    samples come from the device; the exact distribution is still returned for scoring."""
    m = len(costs_pool)
    cost = np.asarray(costs_pool, float)
    sub = WeightSubspace(m, k, cfg.mixer)
    P = cfg.penalty * cost.max()
    E, feas = master_energies(sub, X_pool, cost, P)
    if cfg.sampler == "uniform":
        prob, angles = np.full(sub.dim, 1.0 / sub.dim), None
    else:
        res = qaoa_optimize(E, cfg.p, alpha=cfg.alpha, restarts=cfg.restarts, seed=seed,
                            maxfun=cfg.maxfun, **sub.kw())
        prob = np.abs(qaoa_state(E, res["gammas"], res["betas"], **sub.kw())) ** 2
        angles = {"gammas": res["gammas"].tolist(), "betas": res["betas"].tolist()}
    if executor is not None and angles is not None:
        from .executor import Request
        Xf = np.asarray(X_pool, float)
        Q = np.diag(cost) + np.triu(Xf @ Xf.T, 1) * P              # same energy as master_energies
        draws = executor.sample_many([Request(Q, k, angles["gammas"], angles["betas"], sub.pairs, cfg.shots,
                                              tag=f"select {m}q k={k}")])[0]
    else:
        draws = rng.choice(sub.dim, size=cfg.shots, p=prob / prob.sum())
    return sub, E, feas, prob, draws, angles


class StagedMaster:
    def __init__(self, inst: Instance, cg: dict, cfg: MasterConfig, pcfg=None, seed: int = 0,
                 t0: float | None = None, executor=None):
        import threading
        import time
        self.executor = executor                              # hardware mode: RoundScheduler
        self._lock = threading.RLock()                       # branches run as threads in hardware mode
        self.t0 = time.perf_counter() if t0 is None else t0
        self.trace: list[dict] = []                          # QOBLIB objective time series
        self.incumbent: int | None = None
        from .pricing import PricingConfig
        self.inst, self.cfg, self.seed = inst, cfg, seed
        self.pcfg = replace(pcfg or PricingConfig(), shots=cfg.residual_shots,
                            sampler=cfg.sampler)
        self.pool = {int(m): int(c) for m, c in zip(cg["masks"], cg["costs"])}
        self.rng = np.random.default_rng(seed)
        self.calls: list[dict] = []
        self.solutions: dict[tuple, int] = {}
        self.big_m = float(2 * inst.c[0, 1:].sum())

    # -- helpers ---------------------------------------------------------------------
    def _seed(self) -> int:
        with self._lock:
            return int(self.rng.integers(1 << 31))

    def _pool(self) -> dict:
        with self._lock:
            return dict(self.pool)

    def _residual_pricing(self, R: int):
        """Quantum pricing restricted to the customers of R (fewer qubits)."""
        from .pricing import QuantumPricer, Surrogate
        cust = self.inst.members(R)
        pr = QuantumPricer(self.inst, self.pcfg, self._seed(), customers=cust, executor=self.executor)
        if not pr.sizes:
            return
        pool = self._pool()
        sur = Surrogate(self.inst).fit(list(pool), list(pool.values()))
        for _ in range(self.cfg.residual_rounds):
            pool = self._pool()
            cols = [m for m in pool if m & ~R == 0]
            _, lam, _, _ = solve_lp(cols, [pool[m] for m in cols], self.inst.n, self.big_m, cust)
            found, _, _ = pr.price(lam, sur)
            with self._lock:
                for m, c in found.items():
                    self.pool.setdefault(m, c)
        self.calls.append({"kind": "pricing", "qubits": len(cust), "shots": pr.stats["shots"],
                           "circuits": pr.stats["calls"], "customers": [int(c) for c in cust]})

    def _completion(self, F: tuple, R: int) -> float:
        """cost(F) + LP bound of covering R \\ F with pool routes (classical ranking of a
        sampled partial solution; it never adds a route)."""
        rest = R & ~sum(F)
        pool = self._pool()
        cols = [m for m in pool if m & ~rest == 0]
        lp = solve_lp(cols, [pool[m] for m in cols], self.inst.n, self.big_m,
                      self.inst.members(rest))[0] if rest else 0.0
        return sum(pool[m] for m in F) + lp

    def _offer(self, sol: tuple, R: int):
        """Record a complete plan in the incumbent trace (time since run start)."""
        import time
        if R != self.inst.full:
            return
        cost = sum(tsp_exact(self.inst, m)[0] for m in sol)
        with self._lock:
            if self.incumbent is None or cost < self.incumbent:
                self.incumbent = cost
                self.trace.append({"Time": round(time.perf_counter() - self.t0, 4), "Incumbent": cost})

    # -- the recursion ---------------------------------------------------------------
    def stage(self, R: int, k: int, depth: int = 0) -> list[tuple]:
        inst = self.inst
        if k == 1:
            if inst.load_of(R) == inst.Q:                    # forced: the last route is R
                with self._lock:
                    self.pool.setdefault(R, tsp_exact(inst, R)[0])
                return [(R,)]
            return []
        if len(self.calls) >= self.cfg.max_calls:
            return []
        if depth > 0 and self.cfg.residual_pricing:
            self._residual_pricing(R)
        pool = self._pool()
        cols = [m for m in pool if m & ~R == 0]
        if len(cols) < k:
            return []
        cust = inst.members(R)
        _, lam, y, _ = solve_lp(cols, [pool[m] for m in cols], inst.n, self.big_m, cust)
        B = self.cfg.B if depth == 0 else self.cfg.B_residual
        kc = min(self.cfg.k_first, k) if (depth == 0 and self.cfg.k_first) else k   # routes per sample
        pick = select_pool(cols, [pool[m] for m in cols], lam, max(B, kc + 1), self.cfg.rule, y)
        pm = [cols[j] for j in pick]
        if len(pm) <= kc:                                    # nothing to choose
            return [tuple(sorted(pm))] if sum(pm) == R and len(pm) == k else []
        X = incidence(pm, inst.n)
        sub, E, feas, prob, draws, angles = select_call(
            [pool[m] for m in pm], X, kc, self.cfg, np.random.default_rng(self._seed()), seed=self._seed(),
            executor=self.executor)
        call = {"kind": "select", "depth": depth, "qubits": len(pm), "k": kc, "dim": int(sub.dim),
                "shots": self.cfg.shots, "feasible_shots": int(feas[draws].sum()),
                "p_feasible": float(prob[feas].sum()),
                "pool": [int(m) for m in pm], "pool_costs": [int(pool[m]) for m in pm],
                "angles": angles, "P": float(self.cfg.penalty * max(pool[m] for m in pm)),
                "kept_shots": int(len(draws))}
        if feas.any():                                       # scoring only: exact output distribution
            best = E[feas].min()
            call.update(p_pool_best=float(prob[feas & (E == best)].sum()),
                        uniform_pool_best=float((feas & (E == best)).sum() / sub.dim))
        self.calls.append(call)

        out = []
        states, counts = np.unique(draws, return_counts=True)
        for st in states[feas[states]] if kc == k else []:   # with kc < k a disjoint sample is partial
            out.append(tuple(sorted(pm[j] for j in np.nonzero(sub.bits([st])[0])[0])))
            self._offer(out[-1], R)
        # mine the most frequent sampled states for non-overlapping routes to keep
        fixes: dict[tuple, float] = {}
        for st in states[np.argsort(-counts)][: self.cfg.scan_states]:
            chosen = sorted(pm[j] for j in np.nonzero(sub.bits([st])[0])[0])
            for j in range(min(kc, k - 1), max(1, self.cfg.min_fix) - 1, -1):
                for F in combinations(chosen, j):
                    if F not in fixes and all(a & b == 0 for a, b in combinations(F, 2)):
                        fixes[F] = self._completion(F, R)
        if self.cfg.max_residual and fixes:                  # keep residual pricing hardware-sized
            left = {F: bin(R & ~sum(F)).count("1") for F in fixes}
            ok = {F: v for F, v in fixes.items() if left[F] <= self.cfg.max_residual}
            fixes = ok or {F: v for F, v in fixes.items() if left[F] == min(left.values())}
        ranked = sorted(fixes, key=lambda F: (fixes[F], -len(F)))[: self.cfg.beam]
        if self.executor is not None and len(ranked) > 1:    # hardware mode: branches in lock-step
            threads = [self.executor.spawn(self.stage, R & ~sum(F), k - len(F), depth + 1) for F in ranked]
            self.executor.join_all(threads)
            tails = []
            for _, box in threads:
                if "err" in box:
                    raise box["err"]
                tails.append(box["out"])
        else:
            tails = [self.stage(R & ~sum(F), k - len(F), depth + 1) for F in ranked]
        for F, ts in zip(ranked, tails):
            for tail in ts:
                out.append(tuple(sorted(F + tail)))
                self._offer(out[-1], R)
        return list(dict.fromkeys(out))

    def run(self) -> dict:
        inst = self.inst
        if self.cfg.staged:
            sols = self.stage(inst.full, inst.K)
        else:                                                # single K-route call, no recursion
            cfg, self.cfg = self.cfg, replace(self.cfg, beam=0)
            sols = self.stage(inst.full, inst.K)
            self.cfg = cfg
        scored = sorted((sum(tsp_exact(inst, m)[0] for m in s), s) for s in sols)
        best = scored[0] if scored else (None, None)
        sel = [c for c in self.calls if c["kind"] == "select"]
        pri = [c for c in self.calls if c["kind"] == "pricing"]
        return {
            "cost": best[0], "routes": None if best[1] is None else [tsp_exact(inst, m)[1] for m in best[1]],
            "n_solutions": len(scored), "calls": self.calls,
            "select_calls": len(sel), "pricing_calls": len(pri),
            "max_qubits": max([c["qubits"] for c in self.calls], default=0),
            "first_call_qubits": sel[0]["qubits"] if sel else 0,
            "shots": sum(c["shots"] for c in self.calls),
            "config": asdict(self.cfg), "trace": self.trace,
        }
