"""Transpile one round of requests in a fresh process (hardware mode).

    python -m qvrp.transpile_worker requests.pkl circuits.qpy <backend> <layout_seeds> <replicates>

The long-lived hardware-run process (hundreds of worker threads, replayed jobs in memory) twice
deadlocked inside qiskit's compiled transpiler passes, while the same circuits transpiled in 6 s
in a clean process.  So CircuitBackend hands every live round's transpile to this worker: it
builds the circuits, transpiles each with every layout seed, keeps the ``replicates`` best by
estimated success probability, and writes them (request-major order) as QPY.
"""
from __future__ import annotations

import pickle
import sys

from qiskit import qpy, transpile

from .hardware import esp, qaoa_circuit, service, sparsify_in_subspace


def main():
    src, dst, backend, seeds, reps = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]), int(sys.argv[5])
    reqs = pickle.loads(open(src, "rb").read())
    dev = service().backend(backend)
    qcs = [qaoa_circuit(sparsify_in_subspace(r.Q)[0], r.k, r.gammas, r.betas, r.pairs, init="product") for r in reqs]
    per_seed = [transpile(qcs, dev, optimization_level=3, seed_transpiler=s) for s in range(seeds)]
    out = []
    for i in range(len(reqs)):
        cands = sorted((t[i] for t in per_seed), key=lambda t: -esp(t, dev))
        out += cands[:reps] if len(cands) >= reps else cands * reps
    with open(dst, "wb") as f:
        qpy.dump(out, f)


if __name__ == "__main__":
    main()
