"""Hardware round 2: route-selection circuits from several instances in one batched job.

    python -m qvrp.hw_batch prepare  [--n 8]     # no QPU time: pick calls, build, transpile, noisy sim
    python -m qvrp.hw_batch submit               # ONE SamplerV2 job on ibm_kingston
    python -m qvrp.hw_batch analyze              # mitigation + statistics -> results/hardware/batch_*.json

Changes against round 1 (vrp/results/hardware/XSH-n20-k4-17_hardware.json):

* **product-state start** instead of the Dicke circuit: RY to P(1) = k/m on every qubit,
  no two-qubit gates.  All later gates conserve Hamming weight and the weight-k part of the
  product state is exactly the Dicke state, so post-selection on weight k reproduces the
  Dicke circuit exactly (acceptance C(m,k)(k/m)^k(1-k/m)^(m-k) noiselessly).
* **coupling sparsification inside the subspace** (``hardware.sparsify_in_subspace``):
  shifting every coupling by a constant is a global phase on the weight-k states.
* **layout search**: best estimated success probability over 20 transpiler seeds.
* **mitigation**: XY4 dynamical decoupling, gate and measurement twirling, readout
  calibration measured *in the same job* (all-0 / all-1 on every used qubit) and applied
  with M3, then Hamming-weight post-selection.

Each circuit is a real selection call recorded by the staged master in a simulator run of
its instance (campaign settings, seed 0); angles re-optimised at p = 1 on the exact
simulator for the same pool and penalty.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse  # noqa: E402
import json  # noqa: E402
import time  # noqa: E402
from concurrent.futures import ProcessPoolExecutor  # noqa: E402
from math import comb  # noqa: E402
from pathlib import Path  # noqa: E402

import numpy as np  # noqa: E402
from qiskit import QuantumCircuit, qpy, transpile  # noqa: E402
from qiskit.quantum_info import Statevector  # noqa: E402

from qobench.quantum import WeightSubspace, qaoa_optimize, qaoa_state  # noqa: E402

from .hardware import (calibration_summary, esp, postselect_weight, qaoa_circuit,  # noqa: E402
                       run_noisy_sim, service, sparsify_in_subspace)
from .instance import NAMES, Instance, incidence  # noqa: E402
from .master import master_energies  # noqa: E402
from .pipeline import run  # noqa: E402
from .submit import BUDGET, config  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "results" / "hardware"
BACKEND = "ibm_kingston"
SHOTS = 4000
CAL_SHOTS = 2000
OPTIONS = {"dynamical_decoupling": {"enable": True, "sequence_type": "XY4"},
           "twirling": {"enable_gates": True, "enable_measure": True, "num_randomizations": "auto"}}


def candidate(name: str) -> dict | None:
    """Largest 8-10 qubit selection call (k = 2 or 3, >= 2 feasible plans) of a seed-0 run."""
    pcfg, cgcfg, mcfg = config("qaoa")
    r = run(name, pcfg, cgcfg, mcfg, 0, f"hw_{BUDGET}", log=lambda *a: None)
    best = None
    for c in r["calls"]:
        if c["kind"] != "select" or not c["angles"] or not 8 <= c["qubits"] <= 10 or c["k"] not in (2, 3):
            continue
        inst = Instance.load(name)
        X = incidence(c["pool"], inst.n)
        sub = WeightSubspace(c["qubits"], c["k"])
        _, feas = master_energies(sub, X, np.array(c["pool_costs"], float), c["P"])
        if feas.sum() < 2:
            continue
        if best is None or c["dim"] > best["dim"]:
            best = {**{k: c[k] for k in ("depth", "qubits", "k", "dim", "pool", "pool_costs", "P")},
                    "feasible": int(feas.sum()), "instance": name}
    return best


def build(c: dict, p: int = 1):
    inst = Instance.load(c["instance"])
    pm, pc, k = np.array(c["pool"], np.int64), np.array(c["pool_costs"], float), c["k"]
    X = incidence(pm, inst.n).astype(float)
    Q = np.diag(pc) + np.triu(X @ X.T, 1) * c["P"]
    sub = WeightSubspace(len(pm), k, "ring")
    E, feas = master_energies(sub, X, pc, c["P"])
    if "angles" not in c:
        res = qaoa_optimize(E, p, alpha=0.1, restarts=6, **sub.kw())
        c["angles"] = {"gammas": [float(x) for x in res["gammas"]], "betas": [float(x) for x in res["betas"]]}
    g, b = c["angles"]["gammas"], c["angles"]["betas"]
    prob = np.abs(qaoa_state(E, g, b, **sub.kw())) ** 2
    Qs, shift = sparsify_in_subspace(Q)
    qc = qaoa_circuit(Qs, k, g, b, sub.pairs, init="product")
    sv = np.abs(Statevector(qaoa_circuit(Qs, k, g, b, sub.pairs, measure=False, init="product")).data[sub.states]) ** 2
    assert np.allclose(sv / sv.sum(), prob, atol=1e-8), "post-selected circuit != simulator"
    best = int(np.argmin(np.where(feas, E, np.inf)))
    key = lambda i: format(int(sub.states[i]), f"0{len(pm)}b")
    return {"qc": qc, "prob": prob, "feas": feas, "sub": sub, "best": best, "best_key": key(best),
            "feas_keys": [key(i) for i in np.nonzero(feas)[0]], "couplings": int((np.triu(Q, 1) != 0).sum()),
            "couplings_sparse": int((np.triu(Qs, 1) != 0).sum())}


def score(counts: dict, k: int, best_key: str, feas_keys) -> dict:
    tot = sum(counts.values())
    dist = {b: v / tot for b, v in counts.items()}
    ps, kept = postselect_weight(dist, k)
    return {"kept": kept, "p_best": ps.get(best_key, 0.0),
            "p_feasible": sum(ps.get(f, 0.0) for f in feas_keys)}


def prepare(n: int, workers: int):
    with ProcessPoolExecutor(workers) as ex:
        cands = [c for c in ex.map(candidate, NAMES) if c]
    print(f"{len(cands)} instances have an 8-10 qubit selection call", flush=True)
    be = service().backend(BACKEND)
    rows = []
    for c in cands:
        B = build(c)
        tq = max((transpile(B["qc"], be, optimization_level=3, seed_transpiler=s) for s in range(20)),
                 key=lambda t: esp(t, be))
        counts = run_noisy_sim(tq, be, 4000, seed=3)
        sim = score(counts, c["k"], B["best_key"], B["feas_keys"])
        rows.append({**c, "ideal_p_best": float(B["prob"][B["best"]]),
                     "ideal_p_feasible": float(B["prob"][B["feas"]].sum()),
                     "uniform_p_best": 1 / B["sub"].dim, "uniform_p_feasible": float(B["feas"].mean()),
                     "acceptance_ideal": comb(c["qubits"], c["k"]) * (c["k"] / c["qubits"]) ** c["k"]
                     * (1 - c["k"] / c["qubits"]) ** (c["qubits"] - c["k"]),
                     "cz": int(tq.count_ops().get("cz", 0)), "esp": esp(tq, be), "depth": tq.depth(),
                     "couplings": B["couplings"], "couplings_sparse": B["couplings_sparse"],
                     "noisy_sim": sim, "best_key": B["best_key"], "feas_keys": B["feas_keys"],
                     "layout": [int(q) for q in tq.layout.final_index_layout()], "_tq": tq})
        r = rows[-1]
        print(f"{c['instance']}: {c['qubits']}q k={c['k']} dim {c['dim']} feas {c['feasible']} | CZ {r['cz']} "
              f"ESP {r['esp']:.2f} | ideal {r['ideal_p_best'] / r['uniform_p_best']:.1f}x, noisy+ps "
              f"{sim['p_best'] / r['uniform_p_best']:.1f}x uniform", flush=True)
    # keep the n circuits with the largest predicted gain over uniform (simulator data only)
    rows.sort(key=lambda r: -r["noisy_sim"]["p_best"] / r["uniform_p_best"])
    chosen = rows[:n]
    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / "batch_circuits.qpy", "wb") as f:
        qpy.dump([r["_tq"] for r in chosen], f)
    meta = {"backend": calibration_summary(be), "options": OPTIONS, "shots": SHOTS,
            "circuits": [{k: v for k, v in r.items() if k != "_tq"} for r in chosen],
            "candidates_considered": len(rows)}
    (OUT / "batch_prepare.json").write_text(json.dumps(meta, indent=1, default=float))
    return meta


def calibration_circuits(layouts, num_qubits: int):
    qubits = sorted({q for lay in layouts for q in lay})
    c0 = QuantumCircuit(num_qubits, len(qubits))
    c1 = QuantumCircuit(num_qubits, len(qubits))
    for j, q in enumerate(qubits):
        c1.x(q)
        c0.measure(q, j)
        c1.measure(q, j)
    return qubits, [c0, c1]


def submit():
    from qiskit_ibm_runtime import SamplerV2
    meta = json.loads((OUT / "batch_prepare.json").read_text())
    with open(OUT / "batch_circuits.qpy", "rb") as f:
        circuits = qpy.load(f)
    be = service().backend(BACKEND)
    cal_qubits, cals = calibration_circuits([c["layout"] for c in meta["circuits"]], be.num_qubits)
    cals = [transpile(c, be, optimization_level=0) for c in cals]
    sampler = SamplerV2(mode=be, options=OPTIONS)
    t = time.time()
    job = sampler.run([(c, None, SHOTS) for c in circuits] + [(c, None, CAL_SHOTS) for c in cals])
    print("job", job.job_id(), "->", be.name, f"({len(circuits)} circuits + 2 calibration)", flush=True)
    res = job.result()
    meta["shots"], meta["cal_shots"] = SHOTS, CAL_SHOTS
    (OUT / "batch_prepare.json").write_text(json.dumps(meta, indent=1, default=float))
    out = {"job_id": job.job_id(), "wall_seconds": round(time.time() - t, 1), "metrics": job.metrics(),
           "cal_qubits": cal_qubits, "counts": [], "cal_counts": []}
    for i in range(len(circuits)):
        out["counts"].append(res[i].data.meas.get_counts())
    for i in range(2):
        d = res[len(circuits) + i].data
        out["cal_counts"].append(getattr(d, list(d.keys())[0]).get_counts())
    (OUT / "batch_hardware.json").write_text(json.dumps(out, default=str))
    print("QPU seconds:", out["metrics"].get("usage", {}).get("qpu_charge_time_seconds"), flush=True)
    return out


def readout_matrices(hw: dict, num_qubits: int):
    """Per-qubit 2x2 assignment matrices A[meas, prep] from the all-0 / all-1 circuits."""
    qs = hw["cal_qubits"]
    mats = [None] * num_qubits
    for prep, counts in enumerate(hw["cal_counts"]):
        tot = sum(counts.values())
        for j, q in enumerate(qs):
            ones = sum(v for b, v in counts.items() if b[::-1][j] == "1") / tot
            if mats[q] is None:
                mats[q] = np.zeros((2, 2))
            mats[q][1, prep] = ones
            mats[q][0, prep] = 1 - ones
    return mats


def analyze():
    import mthree
    from scipy.stats import binomtest, combine_pvalues
    meta = json.loads((OUT / "batch_prepare.json").read_text())
    hw = json.loads((OUT / "batch_hardware.json").read_text())
    num_qubits = 156
    mit = mthree.M3Mitigation()
    mit.cals_from_matrices(readout_matrices(hw, num_qubits))
    rows, pvals = [], []
    for c, counts in zip(meta["circuits"], hw["counts"]):
        shots = sum(counts.values())
        raw = score(counts, c["k"], c["best_key"], c["feas_keys"])
        quasi = mit.apply_correction(counts, c["layout"]).nearest_probability_distribution()
        m3 = score({b: v for b, v in quasi.items()}, c["k"], c["best_key"], c["feas_keys"])
        kept = round(raw["kept"] * shots)
        hits = round(raw["p_best"] * kept)
        p = binomtest(hits, kept, c["uniform_p_best"], alternative="greater").pvalue if kept else 1.0
        pvals.append(p)
        rows.append({"instance": c["instance"], "qubits": c["qubits"], "k": c["k"], "dim": c["dim"],
                     "feasible": c["feasible"], "cz": c["cz"], "esp": c["esp"],
                     "uniform": {"p_best": c["uniform_p_best"], "p_feasible": c["uniform_p_feasible"]},
                     "ideal": {"p_best": c["ideal_p_best"], "p_feasible": c["ideal_p_feasible"],
                               "acceptance": c["acceptance_ideal"]},
                     "noisy_sim": c["noisy_sim"], "hardware_postselected": raw, "hardware_m3_postselected": m3,
                     "kept_shots": kept, "best_hits": hits, "binomial_p_best": p})
    combined = combine_pvalues(pvals, method="fisher").pvalue
    pooled_obs = sum(r["best_hits"] for r in rows)
    pooled_exp = sum(r["kept_shots"] * r["uniform"]["p_best"] for r in rows)
    out = {"job_id": hw["job_id"], "backend": meta["backend"], "options": meta["options"], "shots": meta["shots"],
           "quantum_seconds": hw["metrics"].get("usage", {}).get("qpu_charge_time_seconds"),
           "rows": rows, "fisher_combined_p": combined,
           "pooled_best_hits": pooled_obs, "pooled_expected_uniform": pooled_exp}
    (OUT / "batch_results.json").write_text(json.dumps(out, indent=1, default=float))
    for r in rows:
        h, m = r["hardware_postselected"], r["hardware_m3_postselected"]
        print(f"{r['instance']}: {r['qubits']}q k={r['k']} CZ {r['cz']} | kept {h['kept']:.1%} | P(best) ideal "
              f"{r['ideal']['p_best']:.3f} hw+ps {h['p_best']:.3f} hw+M3+ps {m['p_best']:.3f} uniform "
              f"{r['uniform']['p_best']:.3f} ({h['p_best'] / r['uniform']['p_best']:.2f}x, p={r['binomial_p_best']:.2g})")
    print(f"pooled: {pooled_obs} best-plan hits vs {pooled_exp:.1f} expected under uniform; Fisher combined p = {combined:.2g}")
    print("QPU seconds:", out["quantum_seconds"])
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("step", choices=["prepare", "submit", "analyze"])
    ap.add_argument("--n", type=int, default=8)
    ap.add_argument("--workers", type=int, default=14)
    a = ap.parse_args()
    {"prepare": lambda: prepare(a.n, a.workers), "submit": submit, "analyze": analyze}[a.step]()
