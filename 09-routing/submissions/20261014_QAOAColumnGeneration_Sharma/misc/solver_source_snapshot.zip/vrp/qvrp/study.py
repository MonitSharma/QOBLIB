"""Multi-seed study: pricing variant x sampler (QAOA vs the uniform stand-in) x shot budget.

    python -m qvrp.study --variants v1 v2 --samplers qaoa uniform --budgets 100 300 1000 \
                         --seeds 0 1 2 --workers 14 --out study1

``budget`` b sets both the pricing shots per route size per round and the shots per
route-selection call, so QAOA and uniform sampling always get the same number of samples.
One JSON line per run goes to results/raw/<out>.jsonl (git-ignored); finished runs are
skipped on restart.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import argparse  # noqa: E402
import json  # noqa: E402
import time  # noqa: E402
from concurrent.futures import ProcessPoolExecutor, as_completed  # noqa: E402

from .colgen import CGConfig  # noqa: E402
from .instance import NAMES  # noqa: E402
from .master import MasterConfig  # noqa: E402
from .pipeline import RAW, VARIANTS, run  # noqa: E402
from .pricing import PricingConfig  # noqa: E402


def job(name, variant, sampler, budget, seed, smoothing, adaptive):
    pcfg = PricingConfig(**VARIANTS[variant], shots=budget, sampler=sampler)
    cgcfg = CGConfig(smoothing=smoothing, adaptive_shots=adaptive)
    mcfg = MasterConfig(sampler=sampler, shots=budget, residual_shots=budget)
    tag = f"{variant}_{sampler}_b{budget}{'' if smoothing else '_nosm'}{'' if adaptive else '_noad'}"
    t = time.time()
    r = run(name, pcfg, cgcfg, mcfg, seed, tag, log=lambda *a: None)
    r.pop("calls", None)
    r.pop("routes", None)
    r.update(variant=variant, sampler=sampler, budget=budget, smoothing=smoothing,
             adaptive=adaptive, wall=round(time.time() - t, 1))
    return r


def key(r):
    return (r["instance"], r["variant"], r["sampler"], r["budget"], r["seed"],
            r["smoothing"], r["adaptive"])


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--variants", nargs="+", default=["v1", "v2"])
    ap.add_argument("--samplers", nargs="+", default=["qaoa", "uniform"])
    ap.add_argument("--budgets", nargs="+", type=int, default=[100, 300, 1000])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--instances", nargs="+", default=NAMES)
    ap.add_argument("--smoothing", type=float, default=0.5)
    ap.add_argument("--no-adaptive", action="store_true")
    ap.add_argument("--workers", type=int, default=14)
    ap.add_argument("--out", default="study1")
    a = ap.parse_args()
    out = RAW / f"{a.out}.jsonl"
    out.parent.mkdir(parents=True, exist_ok=True)
    done = {key(json.loads(l)) for l in out.open()} if out.exists() else set()
    jobs = [(n, v, s, b, sd, a.smoothing, not a.no_adaptive)
            for v in a.variants for b in a.budgets for sd in a.seeds for s in a.samplers
            for n in a.instances]
    jobs = [j for j in jobs if (j[0], j[1], j[2], j[3], j[4], j[5], j[6]) not in done]
    print(f"{len(jobs)} runs to do ({len(done)} already in {out.name})", flush=True)
    t0 = time.time()
    with ProcessPoolExecutor(a.workers) as ex, out.open("a") as f:
        futs = {ex.submit(job, *j): j for j in jobs}
        for i, fu in enumerate(as_completed(futs), 1):
            try:
                r = fu.result()
            except Exception as e:                           # keep the sweep alive, log the failure
                print(f"FAILED {futs[fu]}: {e!r}", flush=True)
                continue
            f.write(json.dumps(r, default=float) + "\n")
            f.flush()
            print(f"[{i}/{len(jobs)} {time.time() - t0:7.0f}s] {r['instance']} {r['variant']} "
                  f"{r['sampler']:7s} b={r['budget']:4d} s={r['seed']} cost={r['cost']} "
                  f"gap={r['gap_pct']} opt_in_pool={r['cg']['opt_routes_in_pool']}", flush=True)
