"""Stage 1: Lagrangian column generation with quantum pricing.

    restricted-master LP (HiGHS) -> duals lambda_LP
    pricing duals  lambda_p = a * lambda_center + (1 - a) * lambda_LP     (dual smoothing)
    quantum pricing per route size, shots allocated to productive sizes
    exact Held-Karp cost of every sampled route; keep routes with c_S - lambda_LP(S) < 0

Dual smoothing (Wentges 1997; Pessoa et al. 2018) damps the dual oscillation that makes
late pricing rounds chase moving targets.  If the smoothed duals find nothing negative
w.r.t. lambda_LP (a "misprice"), the round is repeated with lambda_LP itself before it
counts as a stall.  The total shot budget per round is fixed (shots * #slices): adaptive
allocation only moves shots between route sizes, so budgets stay comparable.
"""
from __future__ import annotations

import time
from dataclasses import asdict, dataclass

import numpy as np

from .instance import Instance, incidence
from .master import solve_lp
from .pricing import PricingConfig, QuantumPricer, Surrogate


@dataclass
class CGConfig:
    max_iter: int = 40
    max_add: int = 40               # routes added per round (most negative first)
    patience: int = 2               # rounds without a negative route before stopping
    smoothing: float = 0.5          # Wentges factor a (0 = off)
    adaptive_shots: bool = True
    shot_floor: float = 0.3         # share of the budget always spread evenly (exploration)
    decay: float = 0.5              # memory of the per-size yield


def allocate(sizes, yields: dict, total: int, floor: float) -> dict:
    """Split ``total`` shots over route sizes: ``floor`` evenly, the rest by recent yield."""
    k = len(sizes)
    y = np.array([yields.get(s, 0.0) for s in sizes])
    w = np.full(k, 1.0 / k) if y.sum() <= 0 else floor / k + (1 - floor) * y / y.sum()
    return {s: int(round(total * wi)) for s, wi in zip(sizes, w)}


def column_generation(inst: Instance, pcfg: PricingConfig, cgcfg: CGConfig | None = None,
                      seed: int = 0, log=print) -> dict:
    cgcfg = cgcfg or CGConfig()
    pricer = QuantumPricer(inst, pcfg, seed)
    sur = Surrogate(inst)
    pool: dict[int, int] = {}
    seen: set[int] = set()
    big_m = float(2 * inst.c[0, 1:].sum())                  # serving everyone alone: an upper bound
    yields: dict[int, float] = {}
    center = None
    hist, stall, t0 = [], 0, time.time()
    total_shots = pcfg.shots * len(pricer.sizes)
    for it in range(cgcfg.max_iter):
        masks = np.fromiter(pool, np.int64, len(pool))
        obj, lam_lp, _, art = solve_lp(masks, [pool[m] for m in masks], inst.n, big_m)
        a = cgcfg.smoothing if (center is not None and art < 1e-9) else 0.0
        shots = (allocate(pricer.sizes, yields, total_shots, cgcfg.shot_floor)
                 if cgcfg.adaptive_shots else None)
        t, misprice = time.time(), False
        for attempt in range(2):
            lam_p = a * center + (1 - a) * lam_lp if a > 0 else lam_lp
            found, slice_of, diag = pricer.price(lam_p, sur, shots)
            seen.update(found)
            X = incidence(list(found), inst.n) if found else np.zeros((0, inst.n))
            rc = np.array(list(found.values()), float) - X @ lam_lp
            neg = sorted((r, m) for r, m in zip(rc, found) if m not in pool and r < -1e-6)
            if neg or a == 0:
                break
            a, misprice = 0.0, True                          # misprice: retry with lambda_LP
        center = lam_p
        added = neg[: cgcfg.max_add]
        for r, m in added:
            pool[m] = found[m]
        per_size: dict[int, int] = {}
        for r, m in added:
            per_size[slice_of[m]] = per_size.get(slice_of[m], 0) + 1
        for s in pricer.sizes:
            yields[s] = cgcfg.decay * yields.get(s, 0.0) + per_size.get(s, 0)
        if pool:
            sur.fit(list(pool), list(pool.values()))
        hist.append({"iter": it, "lp": obj, "artificial": art, "pool": len(pool),
                     "sampled_distinct": len(found), "added": len(added), "misprice": misprice,
                     "smoothing": a, "min_rc": float(neg[0][0]) if neg else None,
                     "shots": shots, "pricing_s": round(time.time() - t, 2), "slices": diag})
        log(f"  it {it:2d}  LP {obj:10.2f}  art {art:4.1f}  pool {len(pool):4d}  +{len(added):3d}"
            f"  min_rc {hist[-1]['min_rc']}{'  (misprice)' if misprice else ''}")
        stall = stall + 1 if not neg else 0
        if stall >= cgcfg.patience:
            break
    masks = np.fromiter(pool, np.int64, len(pool))
    costs = np.array([pool[m] for m in masks], np.int64)
    obj, lam, y, art = solve_lp(masks, costs, inst.n, big_m)
    return {"instance": inst.name, "masks": masks, "costs": costs, "lp": obj, "lam": lam, "y": y,
            "artificial": art, "hist": hist, "seen": np.array(sorted(seen), np.int64),
            "pricer_stats": pricer.stats, "pricing": asdict(pcfg), "cg": asdict(cgcfg),
            "seed": seed, "seconds": round(time.time() - t0, 2)}
