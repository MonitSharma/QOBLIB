"""QOBLIB submission campaign (paradigm: Quantum Simulator) and packaging.

    python -m qvrp.submit run      [--runs 10] [--workers 14]   # every instance, QAOA + uniform control
    python -m qvrp.submit package                              # -> submissions/09-routing/<name>/

Configuration (fixed for the whole campaign, chosen *before* it from the v1 multi-seed
study, notebook 06): pricing variant v1, 300 shots per pricing slice per round and per
selection call.  300 is the largest budget at which QAOA beats uniform sampling of the
same subspaces significantly (paired Wilcoxon p = 2e-5); at 1,000 shots the gain is not
significant, so a run there would not show that the quantum step is doing the work.

Every seed is also run with the uniform stand-in (same shots, same subspaces, same
classical steps).  Those control runs are not part of the submitted solutions; they are
reported in the README and in each instance's Remarks.

Curated outputs (committed): vrp/results/quantum_sim/{runs.jsonl, solutions/, manifest.json}
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import argparse  # noqa: E402
import json  # noqa: E402
import platform  # noqa: E402
import sys  # noqa: E402
import time  # noqa: E402
from concurrent.futures import ProcessPoolExecutor, as_completed  # noqa: E402
from pathlib import Path  # noqa: E402

import numpy as np  # noqa: E402

from .colgen import CGConfig  # noqa: E402
from .instance import NAMES, ROOT, Instance, tsp_exact  # noqa: E402
from .master import MasterConfig  # noqa: E402
from .pipeline import RAW, run  # noqa: E402
from .pricing import V1, PricingConfig  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "results" / "quantum_sim"
BUDGET = 300
SUBMISSION = "20261014_QAOAColumnGeneration_Sharma"


def config(sampler: str):
    return (PricingConfig(**V1, shots=BUDGET, sampler=sampler), CGConfig(),
            MasterConfig(sampler=sampler, shots=BUDGET, residual_shots=BUDGET))


def job(name: str, seed: int, sampler: str) -> dict:
    pcfg, cgcfg, mcfg = config(sampler)
    tag = f"submit_{sampler}_b{BUDGET}"                       # fresh stage-1 cache per campaign
    r = run(name, pcfg, cgcfg, mcfg, seed, tag, log=lambda *a: None)
    inst = Instance.load(name)
    if r["routes"] is not None:                              # independent re-check of the plan
        served = sorted(i for rt in r["routes"] for i in rt)
        assert served == list(range(1, inst.n + 1)), "every customer exactly once"
        assert all(inst.load_of(inst.mask(rt)) <= inst.Q for rt in r["routes"]), "capacity"
        assert len(r["routes"]) <= inst.K
        assert r["cost"] == sum(tsp_exact(inst, inst.mask(rt))[0] for rt in r["routes"])
    sel = [c for c in r["calls"] if c["kind"] == "select"]
    pri = [c for c in r["calls"] if c["kind"] == "pricing"]
    return {
        "instance": name, "seed": seed, "sampler": sampler, "cost": r["cost"], "routes": r["routes"],
        "optimum": r["optimum"], "optimal": r["optimal"], "gap_pct": r["gap_pct"],
        "trace": r["trace"], "wall_seconds": r["wall_seconds"], "cpu_seconds": r["cpu_seconds"],
        "qubits_max": max([r["cg"]["pricing_qubits"]] + [c["qubits"] for c in r["calls"]]),
        "selection_qubits": [c["qubits"] for c in sel],
        "pricing_shots": r["cg"]["pricing_shots"] + sum(c["shots"] for c in pri),
        "selection_shots": sum(c["shots"] for c in sel),
        "circuits": r["cg"]["pricing_calls"] + sum(c.get("circuits", 0) for c in pri) + len(sel),
        "cg": r["cg"],
    }


def cmd_run(runs: int, workers: int, instances):
    OUT.mkdir(parents=True, exist_ok=True)
    out = OUT / "runs.jsonl"
    done = set()
    if out.exists():
        done = {(d["instance"], d["seed"], d["sampler"]) for d in map(json.loads, out.open())}
    else:                                                    # first run of the campaign: clear stale caches
        for s in ("qaoa", "uniform"):
            for f in (RAW / "cg" / f"submit_{s}_b{BUDGET}").glob("*.json"):
                f.unlink()
    jobs = [(n, s, smp) for smp in ("qaoa", "uniform") for s in range(runs) for n in instances
            if (n, s, smp) not in done]
    print(f"{len(jobs)} runs to do", flush=True)
    t0 = time.time()
    with ProcessPoolExecutor(workers) as ex, out.open("a") as f:
        futs = {ex.submit(job, *j): j for j in jobs}
        for i, fu in enumerate(as_completed(futs), 1):
            try:
                r = fu.result()
            except Exception as e:
                print(f"FAILED {futs[fu]}: {e!r}", flush=True)
                continue
            f.write(json.dumps(r, default=float) + "\n")
            f.flush()
            print(f"[{i}/{len(jobs)} {time.time() - t0:6.0f}s] {r['instance']} s={r['seed']} "
                  f"{r['sampler']:7s} cost={r['cost']} gap={r['gap_pct']}", flush=True)


# ---------------------------------------------------------------------------------------
def _sol_text(routes, cost):
    return "".join(f"Route #{k + 1}: {' '.join(map(str, r))}\n" for k, r in enumerate(routes)) + f"Cost {cost}\n"


def cmd_package():
    who = json.loads((ROOT / "tools" / "submitter.json").read_text())
    rows = [json.loads(l) for l in (OUT / "runs.jsonl").open()]
    q = [r for r in rows if r["sampler"] == "qaoa"]
    u = [r for r in rows if r["sampler"] == "uniform"]
    import qiskit
    import scipy
    sw = (f"Python {platform.python_version()}, numpy {np.__version__}, scipy {scipy.__version__} (HiGHS LP), "
          f"numba, Qiskit {qiskit.__version__} (circuit cross-check); exact fixed-Hamming-weight statevector "
          f"simulator qobench.quantum.subspace")
    hw = who["hardware_workstation"] + "; one process per run (single-threaded), 14 runs in parallel"
    (OUT / "solutions").mkdir(parents=True, exist_ok=True)

    instances, table = [], []
    for name in NAMES:
        rq = sorted([r for r in q if r["instance"] == name], key=lambda r: r["seed"])
        ru = [r for r in u if r["instance"] == name]
        feas = [r for r in rq if r["cost"] is not None]
        if not feas:
            continue
        best = min(r["cost"] for r in feas)
        bestrun = min(feas, key=lambda r: (r["cost"], r["seed"]))
        sol = OUT / "solutions" / f"{name}.sol"
        sol.write_text(_sol_text(bestrun["routes"], best))
        succ = sum(r["cost"] == best for r in feas)
        tts = [r["trace"][-1]["Time"] for r in feas if r["trace"]]
        ufeas = [r["cost"] for r in ru if r["cost"] is not None]
        opt = rq[0]["optimum"]
        series = []
        for r in rq:
            s = [{"Time": 0.0, "Incumbent": None}] + r["trace"]
            if r["cost"] is not None and s[-1]["Time"] < r["wall_seconds"]:
                s.append({"Time": r["wall_seconds"], "Incumbent": r["cost"]})
            series.append(s)
        table.append({"instance": name, "best": best, "optimum": opt, "runs": len(rq), "feasible": len(feas),
                      "successful": succ, "opt_runs": sum(r["cost"] == opt for r in feas),
                      "u_best": min(ufeas) if ufeas else None, "u_opt_runs": sum(c == opt for c in ufeas),
                      "u_runs": len(ru), "q_mean": float(np.mean([r["cost"] for r in feas])),
                      "u_mean": float(np.mean(ufeas)) if ufeas else None})
        remarks = (
            f"Best of {len(rq)} independent runs (seeds 0-{len(rq) - 1}), {BUDGET} shots per quantum call. "
            f"Proven optimum (our classical submission) = {opt}; gap of best = {100 * (best - opt) / opt:.2f}%; "
            f"{table[-1]['opt_runs']}/{len(feas)} runs reached it. "
            f"Control: the same pipeline with every QAOA circuit replaced by uniform sampling of the same "
            f"subspaces with the same shots reached best {table[-1]['u_best']} "
            f"(mean {table[-1]['u_mean']:.1f} vs QAOA mean {table[-1]['q_mean']:.1f}; optimum in "
            f"{table[-1]['u_opt_runs']}/{len(ru)} runs). "
            f"Largest circuit: {max(r['qubits_max'] for r in rq)} qubits; mean {np.mean([r['circuits'] for r in rq]):.0f} "
            f"circuits and {np.mean([r['pricing_shots'] + r['selection_shots'] for r in rq]):,.0f} shots per run. "
            f"Runtimes are wall-clock of the classical simulation of the circuits (QPU Runtime N/A). "
            f"AI disclosure: assisted (see README)."
        )
        instances.append({
            "instance": name, "ext": "sol",
            "solution": str(sol.relative_to(ROOT)).replace("\\", "/"),
            "columns": {
                "Best Objective Value": best,
                "# Runs": len(rq), "# Feasible Runs": len(feas), "# Successful Runs": succ,
                "Total Runtime": round(float(np.mean([r["wall_seconds"] for r in rq])), 3),
                "Time to Solution": round(float(np.mean(tts)), 3) if tts else "N/A",
                "CPU Runtime": round(float(np.mean([r["cpu_seconds"] for r in rq])), 3),
                "Remarks": remarks,
            },
            "time_series": series,
        })

    readme = (Path(__file__).resolve().parent / "submission_readme.md").read_text(encoding="utf-8")
    t = np.array([[r["best"] == r["optimum"], r["opt_runs"], r["runs"], (r["u_best"] or 1e9) == r["optimum"],
                   r["u_opt_runs"], r["u_runs"]] for r in table], float)
    gaps = np.array([100 * (r["best"] - r["optimum"]) / r["optimum"] for r in table])
    qm = np.array([r["q_mean"] for r in table]); um = np.array([r["u_mean"] for r in table])
    from scipy.stats import wilcoxon
    ucost = {(r["instance"], r["seed"]): r["cost"] for r in u}
    diff = np.array([ucost[(r["instance"], r["seed"])] - r["cost"] for r in q
                     if r["cost"] is not None and ucost.get((r["instance"], r["seed"])) is not None])
    readme = readme.format(
        pair_q=int((diff > 0).sum()), pair_u=int((diff < 0).sum()), pair_t=int((diff == 0).sum()),
        pair_p=float(wilcoxon(diff[diff != 0]).pvalue),
        n=len(table), best_opt=int(t[:, 0].sum()), mean_gap=gaps.mean(), max_gap=gaps.max(),
        q_opt_runs=int(t[:, 1].sum()), q_runs=int(t[:, 2].sum()), u_best_opt=int(t[:, 3].sum()),
        q_feasible=int(sum(r["feasible"] for r in table)),
        u_opt_runs=int(t[:, 4].sum()), u_runs=int(t[:, 5].sum()),
        q_mean_gap=float(np.mean([100 * (r["q_mean"] - r["optimum"]) / r["optimum"] for r in table])),
        u_mean_gap=float(np.mean([100 * (r["u_mean"] - r["optimum"]) / r["optimum"] for r in table])),
        q_better=int((qm < um).sum()), u_better=int((um < qm).sum()),
        budget=BUDGET, hw=hw, sw=sw, submitter=who["submitter"], affiliation=who["affiliation"],
        repo=who["reference_repo"])
    manifest = {
        "problem_dir": "09-routing", "submission": SUBMISSION, "date": "2026-10-14", "readme": readme,
        "common": {
            "Modeling Approach": ("Set partitioning over exact-load routes, solved by column generation. "
                                  "Pricing: one QUBO per route size (20 binary variables, exact load-equality "
                                  "penalty); route selection: QUBO over pool routes (<= 16 binary variables, "
                                  "overlap penalty). Both sampled with XY-mixer QAOA from Dicke states"),
            "# Decision Variables": 20, "# Binary Variables": 20, "# Integer Variables": 0,
            "# Continuous Variables": 0, "# Non-Zero Coefficients": 210,
            "Coefficients Type": "real", "Coefficients Range": "N/A",
            "Workflow": ("Pre-processing: EUC_2D rounded distances; route sizes able to carry exactly Q "
                         "(subset-sum table). Main: (1) column generation: restricted-master LP (HiGHS) gives "
                         "customer prices; per route size s a QAOA circuit (Dicke(20,s) initial state, ring XY "
                         "mixer, p=3, CVaR-optimised angles) samples customer sets; each sampled set with load "
                         "exactly Q gets its exact tour length (Held-Karp) and joins the pool if its reduced cost "
                         "is negative; dual smoothing and shot reallocation between route sizes; stop after 2 "
                         "rounds without a new route. (2) staged route selection: QAOA over exactly-4-route states "
                         "of a 16-route pool (Dicke(16,4), XY mixer, p=4) samples plans; non-overlapping routes in "
                         "the samples are ranked by length + LP bound of the uncovered customers, the best 3 are "
                         "fixed, and pricing and selection rerun on the uncovered customers with fewer qubits; the "
                         "last route is forced. Post-processing: best complete plan among the samples. All "
                         "circuits are simulated exactly (statevector in the fixed-Hamming-weight subspace) and "
                         "sampled with a fixed number of shots."),
            "Algorithm Type": "Stochastic", "Paradigm": "Quantum Simulator",
            "Success Threshold": 0, "Hardware Specifications": hw,
            "GPU Runtime": "N/A", "QPU Runtime": "N/A", "Other HW Runtime": "N/A",
        },
        "instances": instances,
    }
    mpath = OUT / "manifest.json"
    mpath.write_text(json.dumps(manifest, indent=1), encoding="utf-8")
    (OUT / "summary.json").write_text(json.dumps(table, indent=1))
    sys.path.insert(0, str(ROOT / "tools"))
    from package_submission import main as package
    package(mpath)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["run", "package"])
    ap.add_argument("--runs", type=int, default=10)
    ap.add_argument("--workers", type=int, default=14)
    ap.add_argument("--instances", nargs="+", default=NAMES)
    a = ap.parse_args()
    cmd_run(a.runs, a.workers, a.instances) if a.cmd == "run" else cmd_package()
