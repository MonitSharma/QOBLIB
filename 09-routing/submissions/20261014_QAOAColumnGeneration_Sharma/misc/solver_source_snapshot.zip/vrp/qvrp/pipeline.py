"""End-to-end run for one instance: stage 1 (column generation with quantum pricing),
stage 2 (staged quantum route selection), then scoring against ground truth.

Stage 1 is cached on disk (results/raw/cg/) so stage-2 settings can be swept without
re-running pricing.  Scoring (all exact-load routes, the true LP bound, the proven optimum)
happens after the run and never feeds back into it.

    python -m qvrp.pipeline XSH-n20-k4-03 [--variant v2] [--seed 0] [--sampler qaoa]
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np

from .colgen import CGConfig, column_generation
from .instance import Instance, all_columns
from .master import MasterConfig, StagedMaster, solve_lp
from .pricing import V1, V2, PricingConfig

RAW = Path(__file__).resolve().parents[1] / "results" / "raw"
VARIANTS = {"v1": V1, "v2": V2}


def cg_path(name: str, seed: int, tag: str) -> Path:
    return RAW / "cg" / tag / f"{name}_s{seed}.json"


def save_cg(cg: dict, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    out = {k: (v.tolist() if isinstance(v, np.ndarray) else v) for k, v in cg.items()}
    path.write_text(json.dumps(out, default=float))


def load_cg(path: Path) -> dict:
    cg = json.loads(path.read_text())
    for k, dt in (("masks", np.int64), ("costs", np.int64), ("lam", float), ("y", float),
                  ("seen", np.int64)):
        cg[k] = np.array(cg[k], dtype=dt)
    return cg


def score_cg(inst: Instance, cg: dict) -> dict:
    """Ground-truth view of stage 1: LP bound reached, optimal routes found, coverage."""
    all_m, all_c = all_columns(inst)
    lp_true = solve_lp(all_m, all_c, inst.n, 1e7)[0]
    opt = {inst.mask(r) for r in (inst.optimal_routes() or [])}
    pool = set(cg["masks"].tolist())
    return {"instance": inst.name, "lp_cg": cg["lp"], "lp_true": lp_true,
            "lp_gap_pct": 100 * (cg["lp"] - lp_true) / lp_true, "artificial": cg["artificial"],
            "pool_size": len(pool), "opt_routes_in_pool": len(opt & pool),
            "columns_total": int(len(all_m)), "columns_sampled": int(len(cg["seen"])),
            "cg_iters": len(cg["hist"]), "mispriced": sum(h.get("misprice", False) for h in cg["hist"]),
            "cg_seconds": cg["seconds"], **{f"pricing_{k}": v for k, v in cg["pricer_stats"].items()}}


def get_cg(inst: Instance, pcfg: PricingConfig, cgcfg: CGConfig, seed: int, tag: str, log=print):
    path = cg_path(inst.name, seed, tag)
    if path.exists():
        return load_cg(path)
    cg = column_generation(inst, pcfg, cgcfg, seed=seed, log=log)
    save_cg(cg, path)
    return load_cg(path)


def run(name: str, pcfg: PricingConfig, cgcfg: CGConfig, mcfg: MasterConfig, seed: int = 0,
        tag: str = "default", log=print) -> dict:
    inst = Instance.load(name)
    assert inst.exact_load, "the pipeline assumes exact-load instances (all XSH are)"
    t0, c0 = time.perf_counter(), time.process_time()
    cg = get_cg(inst, pcfg, cgcfg, seed, tag, log)
    t1 = time.time()
    res = StagedMaster(inst, cg, mcfg, pcfg, seed=seed, t0=t0).run()
    res["wall_seconds"] = round(time.perf_counter() - t0, 3)       # stage 1 + stage 2
    res["cpu_seconds"] = round(time.process_time() - c0, 3)
    opt = inst.optimum()
    res.update({
        "instance": name, "seed": seed, "tag": tag, "optimum": opt,
        "gap_pct": None if res["cost"] is None or opt is None else round(100 * (res["cost"] - opt) / opt, 3),
        "optimal": res["cost"] is not None and res["cost"] == opt,
        "master_seconds": round(time.time() - t1, 2), "cg": score_cg(inst, cg),
    })
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("instance")
    ap.add_argument("--variant", choices=list(VARIANTS), default="v2")
    ap.add_argument("--sampler", choices=["qaoa", "uniform"], default="qaoa")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--no-smoothing", action="store_true")
    ap.add_argument("--no-adaptive", action="store_true")
    ap.add_argument("--single", action="store_true", help="single K-route call (no staging)")
    ap.add_argument("--tag", default=None)
    a = ap.parse_args()
    pcfg = PricingConfig(**VARIANTS[a.variant], sampler=a.sampler)
    cgcfg = CGConfig(smoothing=0.0 if a.no_smoothing else 0.5, adaptive_shots=not a.no_adaptive)
    mcfg = MasterConfig(sampler=a.sampler, staged=not a.single)
    tag = a.tag or f"{a.variant}_{a.sampler}{'_nosm' if a.no_smoothing else ''}{'_noad' if a.no_adaptive else ''}"
    res = run(a.instance, pcfg, cgcfg, mcfg, a.seed, tag)
    keys = ["instance", "cost", "optimum", "gap_pct", "select_calls", "pricing_calls",
            "first_call_qubits", "max_qubits", "shots", "master_seconds", "cg"]
    print(json.dumps({k: res[k] for k in keys}, indent=1, default=float))


if __name__ == "__main__":
    main()
