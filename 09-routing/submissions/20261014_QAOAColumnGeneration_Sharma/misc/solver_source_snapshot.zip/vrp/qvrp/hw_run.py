"""Full-instance runs with every stage-2 quantum call on a device (hardware mode).

    python -m qvrp.hw_run --mode aer   # dress rehearsal: same code, live ibm_kingston noise model, no QPU
    python -m qvrp.hw_run --mode ibm   # the real run, one IBM Batch, budget guard

Stage 1 (column generation with 20-customer pricing) is the cached exact-simulator result of the
submission campaign (seed 0); 20-qubit pricing does not survive hardware (vrp/HARDWARE.md, Q6).
Stage 2 runs in hardware shape (BEST_PRACTICE["staged_master"]): the first selection picks a pair
from 10 routes, fixes leave <= 11 customers, residual pricing and every later selection run on the
device.  All instances and all search branches advance in lock-step, so each round of circuits
is ONE job (RoundScheduler).  Every plan is re-checked with qvrp.check (mirror of check_cvrp).
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "2")

import argparse  # noqa: E402
import json  # noqa: E402
import time  # noqa: E402
from dataclasses import asdict, replace  # noqa: E402
from pathlib import Path  # noqa: E402

from .check import check  # noqa: E402
from .executor import CircuitBackend, ReplayBackend, RoundScheduler  # noqa: E402
from .hardware import BEST_PRACTICE, calibration_summary, service  # noqa: E402
from .instance import INSTANCES, Instance, tsp_exact  # noqa: E402
from .master import MasterConfig, StagedMaster  # noqa: E402
from .pipeline import cg_path, load_cg  # noqa: E402
from .pricing import V1, PricingConfig  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "results" / "hardware"
DEFAULT_INSTANCES = [f"XSH-n20-k4-{k:02d}" for k in range(1, 11)]


def configs(shots: int):
    mcfg = MasterConfig(**BEST_PRACTICE["staged_master"], shots=shots, residual_shots=shots, sampler="qaoa")
    pcfg = replace(PricingConfig(**V1, shots=shots, sampler="qaoa"), p=BEST_PRACTICE["pricing_p"])
    return mcfg, pcfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["exact", "aer", "ibm"], required=True)
    ap.add_argument("--instances", nargs="+", default=DEFAULT_INSTANCES)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--shots", type=int, default=1000, help="per circuit per replicate")
    ap.add_argument("--replicates", type=int, default=2)
    ap.add_argument("--budget", type=float, default=190.0, help="QPU seconds (ibm mode)")
    ap.add_argument("--backend", default="ibm_kingston")
    ap.add_argument("--tag", default=None)
    ap.add_argument("--replay", default=None,
                    help="JSON list of job-ID lists: rounds already run on the QPU (resume a run that died)")
    ap.add_argument("--cache", default=None, help="directory caching the replayed jobs' data")
    ap.add_argument("--dump", default=None, help="pickle each live round's requests here (debugging)")
    a = ap.parse_args()
    tag = a.tag or a.mode
    svc = service()
    device = svc.backend(a.backend)
    log = lambda *x: print(*x, flush=True)
    kw = dict(replicates=a.replicates, layout_seeds=6, budget_s=a.budget if a.mode == "ibm" else None,
              seed=a.seed, log=log)
    replay = json.loads(Path(a.replay).read_text()) if a.replay else None
    backend = (ReplayBackend(device, a.mode, replay=replay, service=svc, cache=a.cache, **kw) if replay
               else CircuitBackend(device, a.mode, **kw))
    backend.dump = a.dump
    sched = RoundScheduler(backend, log=log)
    mcfg, pcfg = configs(a.shots)
    t0 = time.perf_counter()
    masters, threads = {}, []
    for name in a.instances:
        inst = Instance.load(name)
        cg = load_cg(cg_path(name, a.seed, "submit_qaoa_b300"))
        masters[name] = StagedMaster(inst, cg, mcfg, pcfg, seed=a.seed, t0=t0, executor=sched)
        threads.append((name, *sched.spawn(masters[name].run)))
    log(f"{len(threads)} instances started on {device.name} ({a.mode}); calibration {calibration_summary(device)}")
    try:
        sched.loop()                    # ibm: one IBM Batch, opened when the first job is ready
    finally:
        backend.close()
    rows = []
    sol_dir = OUT / f"fullrun_{tag}" / "solutions"
    sol_dir.mkdir(parents=True, exist_ok=True)
    for name, t, box in threads:
        t.join()
        inst = masters[name].inst
        if "err" in box:
            rows.append({"instance": name, "error": repr(box["err"])})
            continue
        r = box["out"]
        row = {"instance": name, "cost": r["cost"], "optimum": inst.optimum(), "routes": r["routes"],
               "gap_pct": None if r["cost"] is None else round(100 * (r["cost"] - inst.optimum()) / inst.optimum(), 3),
               "optimal": r["cost"] == inst.optimum(), "trace": r["trace"],
               "select_calls": r["select_calls"], "pricing_calls": r["pricing_calls"], "max_qubits": r["max_qubits"],
               "calls": [{k: v for k, v in c.items() if k not in ("pool", "pool_costs")} for c in r["calls"]]}
        if r["routes"]:
            f = sol_dir / f"{name}.sol"
            f.write_text("".join(f"Route #{i + 1}: {' '.join(map(str, rt))}\n" for i, rt in enumerate(r["routes"]))
                         + f"Cost {r['cost']}\n")
            ok, cost, msg = check(INSTANCES / f"{name}.vrp", f)
            row["check"] = msg
            assert ok and cost == r["cost"], f"{name}: {msg}"
        rows.append(row)
    out = {"mode": a.mode, "backend": calibration_summary(device), "instances": a.instances, "seed": a.seed,
           "shots_per_circuit_per_replicate": a.shots, "replicates": a.replicates,
           "master": asdict(mcfg), "pricing": asdict(pcfg), "rounds": backend.rounds,
           "estimated_qpu_s": round(sum(r["estimated_qpu_s"] for r in backend.rounds), 1),
           "billed_qpu_s": sum((r.get("qpu_seconds") or 0) for r in backend.rounds) if a.mode == "ibm" else None,
           "aborted_by_budget": sched.aborted, "replayed_rounds": len(replay) if replay else 0, "wall_s": round(time.perf_counter() - t0, 1), "results": rows}
    (OUT / f"fullrun_{tag}.json").write_text(json.dumps(out, indent=1, default=float))
    ok = [r for r in rows if r.get("cost") is not None]
    log(f"\n{len(ok)}/{len(rows)} instances with a plan; optimal {sum(r['optimal'] for r in ok)}; "
        f"mean gap {sum(r['gap_pct'] for r in ok) / max(1, len(ok)):.2f}%; rounds {len(backend.rounds)}; "
        f"estimated QPU {out['estimated_qpu_s']} s" + (f", billed {out['billed_qpu_s']} s" if a.mode == "ibm" else ""))
    for r in rows:
        log(f"  {r['instance']}: {r.get('cost')} (opt {r.get('optimum')}, gap {r.get('gap_pct')}%) {r.get('error', '')}")


if __name__ == "__main__":
    main()
