"""Instances, routes (columns) and exact route costs for the QOBLIB XSH CVRP instances.

Every XSH instance is *exact-load*: total demand = K * Q, so in any feasible solution each
of the K vehicles carries exactly Q.  A column (route) is therefore a customer subset S
with d(S) = Q, and its cost is the optimal TSP tour depot -> S -> depot.

* ``tsp_exact``   : Held-Karp on one subset (|S| <= ~12).  Used inside the pipeline to
                    price every *sampled* subset exactly.
* ``all_columns`` : every exact-load column of an instance with its cost.  Ground truth
                    for scoring and the notebooks only; the quantum pipeline never calls it.

Customers are 1..n (node 0 = depot); a subset is a bitmask with bit i-1 = customer i.
Distances are TSPLIB EUC_2D (Euclidean, rounded to the nearest integer), as in QOBLIB's
checker.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from numba import njit

ROOT = Path(__file__).resolve().parents[2]
INSTANCES = ROOT / "external" / "QOBLIB" / "09-routing" / "instances"
EXACT = ROOT / "problems" / "09-routing" / "results" / "exact"     # proven optima (classical track)
NAMES = [f"XSH-n20-k4-{k:02d}" for k in range(1, 56)]


def read_vrp(path: Path):
    """(name, N incl. depot, K, Q, demands, rounded EUC_2D distance matrix)."""
    coords, demand, cap, k, name, section = {}, {}, None, None, None, None
    for raw in Path(path).read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("CAPACITY"):
            cap = int(line.split(":")[1])
        elif line.startswith("NAME"):
            name = line.split(":")[1].strip()
            k = int(name.split("-k")[1].split("-")[0])
        elif line in ("NODE_COORD_SECTION", "DEMAND_SECTION", "DEPOT_SECTION"):
            section = line
        elif line == "EOF":
            break
        elif section == "NODE_COORD_SECTION":
            i, x, y = line.split()
            coords[int(i) - 1] = (float(x), float(y))
        elif section == "DEMAND_SECTION":
            i, d = line.split()
            demand[int(i) - 1] = int(d)
    n = len(coords)
    dist = [[0 if i == j else int(math.floor(math.dist(coords[i], coords[j]) + 0.5))
             for j in range(n)] for i in range(n)]
    return name, n, k, cap, [demand[i] for i in range(n)], dist, [coords[i] for i in range(n)]


@dataclass
class Instance:
    name: str
    n: int                  # customers
    K: int                  # vehicles
    Q: int                  # capacity
    d: np.ndarray           # (n+1,) demands, d[0] = 0
    c: np.ndarray           # (n+1, n+1) rounded EUC_2D distances
    xy: np.ndarray          # (n+1, 2) coordinates (plots only)

    @classmethod
    def load(cls, name_or_path) -> "Instance":
        p = Path(name_or_path)
        if not p.exists():
            p = INSTANCES / f"{name_or_path}.vrp"
        name, N, K, Q, d, dist, xy = read_vrp(p)
        return cls(name, N - 1, K, Q, np.array(d, np.int64), np.array(dist, np.int64),
                   np.array(xy, float))

    @property
    def exact_load(self) -> bool:
        return int(self.d.sum()) == self.K * self.Q

    @property
    def full(self) -> int:
        return (1 << self.n) - 1

    def mask(self, customers) -> int:
        return sum(1 << (i - 1) for i in customers)

    def members(self, mask: int) -> list[int]:
        return [i + 1 for i in range(self.n) if mask >> i & 1]

    def load_of(self, mask: int) -> int:
        return int(sum(self.d[i] for i in self.members(mask)))

    def optimum(self) -> int | None:
        """Proven optimum from the exact set-partitioning run (ground truth only)."""
        f = EXACT / f"{self.name}.json"
        return int(json.loads(f.read_text())["cost"]) if f.exists() else None

    def optimal_routes(self) -> list[list[int]] | None:
        f = EXACT / f"{self.name}.json"
        return json.loads(f.read_text())["routes"] if f.exists() else None


@njit(cache=True)
def _held_karp_subset(c, nodes):
    """Optimal tour depot(0) -> nodes -> depot; returns (cost, order of positions)."""
    s = nodes.size
    full = 1 << s
    INF = 1 << 60
    dp = np.full((full, s), INF, np.int64)
    par = np.full((full, s), -1, np.int64)
    for j in range(s):
        dp[1 << j, j] = c[0, nodes[j]]
    for S in range(1, full):
        for j in range(s):
            if not (S >> j) & 1 or dp[S, j] >= INF:
                continue
            for k in range(s):
                if (S >> k) & 1:
                    continue
                T = S | (1 << k)
                v = dp[S, j] + c[nodes[j], nodes[k]]
                if v < dp[T, k]:
                    dp[T, k] = v
                    par[T, k] = j
    best, end = INF, -1
    for j in range(s):
        v = dp[full - 1, j] + c[nodes[j], 0]
        if v < best:
            best, end = v, j
    order = np.empty(s, np.int64)
    S, j = full - 1, end
    for t in range(s - 1, -1, -1):
        order[t] = j
        pj = par[S, j]
        S ^= 1 << j
        j = pj
    return best, order


_TSP_CACHE: dict[tuple[str, int], tuple[int, list[int]]] = {}


def tsp_exact(inst: Instance, mask: int) -> tuple[int, list[int]]:
    """Exact cost and visiting order of the route serving exactly ``mask`` (memoised)."""
    key = (inst.name, int(mask))
    if key not in _TSP_CACHE:
        nodes = np.array(inst.members(mask), np.int64)
        if nodes.size == 0:
            return 0, []
        cost, order = _held_karp_subset(inst.c, nodes)
        _TSP_CACHE[key] = (int(cost), [int(nodes[k]) for k in order])
    return _TSP_CACHE[key]


@njit(cache=True)
def _held_karp_all(c, d, Q):
    """Optimal route cost for every capacity-feasible customer subset (ground truth)."""
    n = c.shape[0] - 1
    full = 1 << n
    load = np.zeros(full, np.int64)
    for S in range(1, full):
        low = S & -S
        b = 0
        while (1 << b) != low:
            b += 1
        load[S] = load[S ^ low] + d[b + 1]
    INF = 1 << 60
    dp = np.full((full, n), INF, np.int64)
    for j in range(n):
        if d[j + 1] <= Q:
            dp[1 << j, j] = c[0, j + 1]
    route = np.full(full, INF, np.int64)
    for S in range(1, full):
        if load[S] > Q:
            continue
        best = INF
        for j in range(n):
            if not (S >> j) & 1:
                continue
            P = S ^ (1 << j)
            if P:
                v = INF
                for i in range(n):
                    if (P >> i) & 1 and dp[P, i] < INF:
                        w = dp[P, i] + c[i + 1, j + 1]
                        if w < v:
                            v = w
                dp[S, j] = v
            tot = dp[S, j] + c[j + 1, 0]
            if tot < best:
                best = tot
        route[S] = best
    return route, load


def all_columns(inst: Instance):
    """(masks, costs) of every exact-load column.  Ground truth only (2^n Held-Karp)."""
    route, load = _held_karp_all(inst.c, inst.d, inst.Q)
    masks = np.nonzero((load == inst.Q) & (route < (1 << 60)))[0]
    return masks.astype(np.int64), route[masks].astype(np.int64)


def incidence(masks, n: int) -> np.ndarray:
    """(len(masks), n) 0/1 matrix: row r = customers of column r."""
    return ((np.asarray(masks, np.int64)[:, None] >> np.arange(n)) & 1).astype(np.int8)


def feasible_sizes(inst: Instance, customers=None) -> list[int]:
    """Route sizes s for which some s of ``customers`` have total demand exactly Q (DP)."""
    cust = list(range(1, inst.n + 1)) if customers is None else list(customers)
    can = np.zeros((len(cust) + 1, inst.Q + 1), bool)          # can[s, w]
    can[0, 0] = True
    for i in cust:
        w = int(inst.d[i])
        prev = can.copy()
        can[1:, w:] |= prev[:-1, : inst.Q + 1 - w]
    return [s for s in range(1, len(cust) + 1) if can[s, inst.Q]]
