"""Hardware calibration job: one real route-selection circuit of the pipeline on an IBM QPU.

    python -m qvrp.hw_demo prepare XSH-n20-k4-17      # no QPU time: pick circuit, transpile, noisy sim
    python -m qvrp.hw_demo submit  XSH-n20-k4-17      # one SamplerV2 job (DD + twirling), then analyse

The circuit is not a toy: it is a selection call recorded by the staged master in a normal
simulator run of the instance (campaign configuration, seed 0): its route pool, its
CVaR-optimised angles, its penalty.  We compare, for the best plan inside that pool,

    P(best) exact simulation  |  noisy Aer with the device's live noise model  |
    the device, raw  |  the device + Hamming-weight post-selection  |  uniform sampling

Results go to vrp/results/hardware/<instance>_<step>.json (committed).
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
from qiskit.quantum_info import Statevector

from qobench.quantum import WeightSubspace, qaoa_state

from .hardware import (calibration_summary, esp, mitigated_sampler_options, postselect_weight,
                       qaoa_circuit, run_noisy_sim, service)
from .instance import Instance, incidence
from .master import master_energies
from .submit import BUDGET, config
from .pipeline import run

OUT = Path(__file__).resolve().parents[1] / "results" / "hardware"
BACKEND = "ibm_kingston"


def pick_call(name: str, seed: int = 0, max_qubits: int = 10):
    """Run the instance once (simulator, campaign settings) and return the largest recorded
    selection call with at most ``max_qubits`` qubits and more than one feasible plan."""
    pcfg, cgcfg, mcfg = config("qaoa")
    r = run(name, pcfg, cgcfg, mcfg, seed, f"hw_{BUDGET}", log=lambda *a: None)
    calls = [c for c in r["calls"] if c["kind"] == "select" and c["angles"] and 4 <= c["qubits"] <= max_qubits]
    if not calls:
        raise SystemExit(f"{name}: no selection call with <= {max_qubits} qubits in this run")
    call = max(calls, key=lambda c: (c["qubits"], c.get("p_pool_best", 0)))
    return r, call


def build(name: str, call: dict):
    inst = Instance.load(name)
    pm, pc, k = np.array(call["pool"], np.int64), np.array(call["pool_costs"], float), call["k"]
    X = incidence(pm, inst.n).astype(float)
    Q = np.diag(pc) + np.triu(X @ X.T, 1) * call["P"]          # same energy as master_energies
    sub = WeightSubspace(len(pm), k, "ring")
    E, feas = master_energies(sub, X, pc, call["P"])
    g, b = call["angles"]["gammas"], call["angles"]["betas"]
    prob = np.abs(qaoa_state(E, g, b, **sub.kw())) ** 2
    qc = qaoa_circuit(Q, k, g, b, sub.pairs)
    ref = np.abs(Statevector(qaoa_circuit(Q, k, g, b, sub.pairs, measure=False)).data[sub.states]) ** 2
    assert np.allclose(ref, prob, atol=1e-9), "circuit and simulator disagree"
    best = int(np.argmin(np.where(feas, E, np.inf)))
    key = lambda st: format(int(sub.states[st]), f"0{len(pm)}b")       # Qiskit bit order
    return {"inst": inst, "sub": sub, "E": E, "feas": feas, "prob": prob, "qc": qc, "best": best,
            "best_key": key(best), "feas_keys": {key(i) for i in np.nonzero(feas)[0]}, "k": k}


def stats(dist: dict, B) -> dict:
    tot = sum(dist.values())
    if not tot:
        return {"p_best": 0.0, "p_feasible": 0.0}
    return {"p_best": dist.get(B["best_key"], 0) / tot,
            "p_feasible": sum(v for kk, v in dist.items() if kk in B["feas_keys"]) / tot}


def reoptimize(name: str, call: dict, p: int) -> dict:
    """Same pool and penalty, angles re-optimised (exact simulator) at hardware depth p."""
    from qobench.quantum import qaoa_optimize
    B = build(name, call)
    r = qaoa_optimize(B["E"], p, alpha=0.1, restarts=6, **B["sub"].kw())
    return {**call, "angles": {"gammas": list(map(float, r["gammas"])), "betas": list(map(float, r["betas"]))},
            "pipeline_p": len(call["angles"]["gammas"]), "hardware_p": p}


def prepare(name: str, shots: int, p: int | None = None):
    r, call = pick_call(name)
    if p:
        call = reoptimize(name, call, p)
    B = build(name, call)
    svc = service()
    be = svc.backend(BACKEND)
    from qiskit import transpile
    tqc = transpile(B["qc"], be, optimization_level=3, seed_transpiler=7)
    ops = tqc.count_ops()
    counts = run_noisy_sim(tqc, be, shots, seed=1)
    noisy = {k: v / shots for k, v in counts.items()}
    ps, kept = postselect_weight(noisy, B["k"])
    out = {
        "instance": name, "seed": 0, "pipeline_cost": r["cost"], "optimum": r["optimum"],
        "call": {k: call[k] for k in ("depth", "qubits", "k", "dim", "pool", "pool_costs", "angles", "P",
                                       "pipeline_p", "hardware_p") if k in call},
        "pool_best_energy": float(B["E"][B["best"]]), "feasible_states": int(B["feas"].sum()),
        "backend": calibration_summary(be), "transpiled": {"depth": tqc.depth(), "ops": dict(ops),
        "two_qubit_gates": int(sum(v for g_, v in ops.items() if g_ in ("cz", "ecr", "cx"))), "esp": esp(tqc, be),
        "layout": list(tqc.layout.final_index_layout()) if tqc.layout else None},
        "ideal": {"p_best": float(B["prob"][B["best"]]), "p_feasible": float(B["prob"][B["feas"]].sum())},
        "uniform": {"p_best": 1.0 / B["sub"].dim, "p_feasible": float(B["feas"].mean())},
        "noisy_sim": {"shots": shots, **stats(noisy, B), "postselected": stats(ps, B), "kept": kept},
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / f"{name}_prepare.json").write_text(json.dumps(out, indent=1, default=float))
    return out, B, tqc, be


def submit(name: str, shots: int, p: int | None = None):
    out, B, tqc, be = prepare(name, shots, p)
    from qiskit_ibm_runtime import SamplerV2
    sampler = SamplerV2(mode=be, options=mitigated_sampler_options())
    t = time.time()
    job = sampler.run([tqc], shots=shots)
    print("job", job.job_id(), "submitted to", be.name, flush=True)
    res = job.result()
    counts = res[0].data.meas.get_counts()
    hw = {k: v / shots for k, v in counts.items()}
    ps, kept = postselect_weight(hw, B["k"])
    usage = None
    try:
        usage = job.usage()
    except Exception:
        pass
    m = job.metrics()
    out["hardware"] = {"job_id": job.job_id(), "backend": be.name, "shots": shots,
                       "options": mitigated_sampler_options(), "wall_seconds": round(time.time() - t, 1),
                       "quantum_seconds": usage if usage is not None else m.get("usage", {}).get("quantum_seconds"),
                       "metrics": m, **stats(hw, B), "postselected": stats(ps, B), "kept": kept,
                       "counts": counts}
    (OUT / f"{name}_hardware.json").write_text(json.dumps(out, indent=1, default=str))
    return out


def show(o: dict):
    print(f"{o['instance']}: QAOA p={o['call'].get('hardware_p', len(o['call']['angles']['gammas']))}, selection call depth {o['call']['depth']}, {o['call']['qubits']} qubits, k={o['call']['k']}, "
          f"{o['call']['dim']} states ({o['feasible_states']} feasible)")
    t = o["transpiled"]
    print(f"  {o['backend']['backend']}: {t['two_qubit_gates']} two-qubit gates, depth {t['depth']}, ESP {t['esp']:.3f}")
    rows = [("exact simulation", o["ideal"]), ("uniform sampling", o["uniform"]),
            ("noisy sim (live noise model)", o["noisy_sim"]), ("  + weight post-selection", o["noisy_sim"]["postselected"])]
    if "hardware" in o:
        rows += [("ibm hardware, raw", o["hardware"]), ("  + weight post-selection", o["hardware"]["postselected"])]
    for label, s in rows:
        print(f"  {label:32s} P(best) {s['p_best']:.4f}   P(feasible) {s['p_feasible']:.4f}")
    if "hardware" in o:
        print(f"  QPU usage: {o['hardware']['quantum_seconds']} s; wall incl. queue {o['hardware']['wall_seconds']} s")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("step", choices=["prepare", "submit"])
    ap.add_argument("instance")
    ap.add_argument("--shots", type=int, default=2000)
    ap.add_argument("--p", type=int, default=None, help="re-optimise angles at this depth for hardware")
    a = ap.parse_args()
    o = prepare(a.instance, a.shots, a.p)[0] if a.step == "prepare" else submit(a.instance, a.shots, a.p)
    show(o)
