"""Quantum pricing: sample low-reduced-cost exact-load routes with cardinality-sliced QAOA.

Lagrangian relaxation of the covering constraints (multipliers lambda) splits the CVRP
into identical per-vehicle subproblems (the "knapsacks" of arXiv:2604.22194):

    min_S  cost(S) - lambda(S)    s.t.  d(S) = Q   (exact load, see instance.py)

One qubit per customer, independent of the fleet size K.  Compared with the paper:

1. **Slack-free equality penalty.**  Exact load turns the knapsack inequality into an
   equality, so A (d.x - Q)^2 is exact (no slack qubits, no tilted surrogate).
2. **Cardinality slices.**  For each feasible route size s the circuit runs in the
   weight-s subspace (Dicke state + XY mixer): it never leaves routes of size s, the cost
   surrogate is exactly quadratic there, and the feasible fraction is ~10x higher.
3. **Any customer subset.**  The staged master re-prices only the customers that are
   still uncovered, so later calls use fewer qubits (|R| instead of n).

cost(S) is a TSP, not quadratic, so the QUBO uses a per-slice surrogate refit on every
route priced so far; every sample is re-priced exactly (Held-Karp), so surrogate error
costs samples, never correctness.

``sampler="uniform"`` replaces the circuit by uniform sampling over the *same* subspace
with the same shots: the classical stand-in every quantum result is compared against.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from qobench.quantum import WeightSubspace, qaoa_optimize, sample

from .instance import Instance, feasible_sizes, incidence, tsp_exact


@dataclass
class Surrogate:
    """Per-slice quadratic route-cost model c_s(x) = a + b sum c_0i x_i + g sum c_ij x_i x_j."""
    inst: Instance
    params: dict = field(default_factory=dict)              # s -> (a, b, g)

    def features(self, X: np.ndarray, customers=None) -> np.ndarray:
        cust = np.arange(1, self.inst.n + 1) if customers is None else np.asarray(customers)
        D0 = self.inst.c[0, cust].astype(float)
        C = self.inst.c[np.ix_(cust, cust)].astype(float)
        Xf = X.astype(float)
        return np.c_[np.ones(len(X)), Xf @ D0, 0.5 * np.einsum("ki,ij,kj->k", Xf, C, Xf, optimize=True)]

    def fit(self, masks, costs):
        X = incidence(masks, self.inst.n)
        F, y, size = self.features(X), np.asarray(costs, float), X.sum(1)
        wp = np.linalg.lstsq(np.c_[F, size], y, rcond=None)[0] if len(y) >= 4 else None
        for s in range(1, self.inst.n + 1):
            I = size == s
            if I.sum() >= 6:
                self.params[s] = tuple(np.linalg.lstsq(F[I], y[I], rcond=None)[0])
            elif wp is not None:                             # pooled fallback with a size term
                self.params[s] = (wp[0] + wp[3] * s, wp[1], wp[2])
        return self

    def coeffs(self, s: int):
        # cold start: a route visiting s customers costs about (2/s) sum c_0i + pair term
        return self.params.get(s, (0.0, 2.0 / s, 1.0 / max(1, s - 1)))


@dataclass
class PricingConfig:
    p: int = 4                      # QAOA depth
    shots: int = 2000               # mean shots per slice per round (total = shots * #slices)
    penalty: float = 0.1
    penalty_mode: str = "range"     # "range": A = penalty * ptp(obj)  (ground state feasible)
                                    # "std"  : A = penalty * std(obj) / std(dev)^2  (first version)
    alpha: float = 0.05             # CVaR level for the angle optimisation
    restarts: int = 1
    maxfun: int = 200               # L-BFGS-B function-evaluation budget per optimisation
    reoptimize: bool = True         # re-optimise every round (warm start) vs transfer round-0 angles
    mixer: str = "ring"
    sampler: str = "qaoa"           # "qaoa" | "uniform" (classical stand-in, same subspace)


# the two variants compared in the first full run (vrp/README.md)
V1 = dict(p=3, penalty=2.0, penalty_mode="std", alpha=0.2, maxfun=150, reoptimize=False)
V2 = dict(p=4, penalty=0.1, penalty_mode="range", alpha=0.05, maxfun=200, reoptimize=True)


class QuantumPricer:
    """One weight-s subspace per feasible route size over ``customers`` (default: all)."""

    def __init__(self, inst: Instance, cfg: PricingConfig, seed: int = 0, customers=None, executor=None):
        self.inst, self.cfg, self.executor = inst, cfg, executor
        self.customers = np.arange(1, inst.n + 1) if customers is None else np.asarray(sorted(customers))
        m = len(self.customers)
        self.sizes = [s for s in feasible_sizes(inst, self.customers) if s < m]
        self.subs = {s: WeightSubspace(m, s, cfg.mixer) for s in self.sizes}
        self._X = {s: sub.bits() for s, sub in self.subs.items()}
        bitval = (1 << (self.customers - 1)).astype(np.int64)
        self._gmask = {s: X.astype(np.int64) @ bitval for s, X in self._X.items()}   # global masks
        dem = inst.d[self.customers]
        self._dev = {s: (X @ dem - inst.Q).astype(float) for s, X in self._X.items()}
        self._feat = {}
        self.angles: dict[int, np.ndarray] = {}
        self.rng = np.random.default_rng(seed)
        self.stats = {"qaoa_evals": 0, "shots": 0, "qubits": m, "calls": 0}
        # the exactly-full subset of all customers is a route but not a "choice" (s = m)
        self.full_route = int(bitval.sum()) if dem.sum() == inst.Q else None

    def energies(self, s: int, lam: np.ndarray, sur: Surrogate):
        X, dev = self._X[s], self._dev[s]
        if s not in self._feat:
            self._feat[s] = sur.features(X, self.customers)[:, 1:]
        a, b, g = sur.coeffs(s)
        obj = a + self._feat[s] @ np.array([b, g]) - X @ lam[self.customers - 1]
        if self.cfg.penalty_mode == "std":
            A = self.cfg.penalty * obj.std() / max(1.0, dev.std()) ** 2
        else:
            # integer demands: any infeasible state pays >= A = penalty * range(obj), so for
            # penalty >= 1 the ground state is provably feasible.  The default 0.1 is softer
            # (smoother landscape) and can leave a few infeasible states below the best
            # route (notebook 03); they cost samples, never correctness
            A = self.cfg.penalty * float(np.ptp(obj))
        return obj + A * dev ** 2, dev == 0

    def qubo(self, s: int, lam: np.ndarray, sur: Surrogate):
        """(Q, const) on this pricer's qubits with x^T Q x + const == energies(s, ...) on the slice."""
        cust, inst = self.customers, self.inst
        E, _ = self.energies(s, lam, sur)                        # also fills the feature cache
        a, b, g = sur.coeffs(s)
        obj = a + self._feat[s] @ np.array([b, g]) - self._X[s] @ lam[cust - 1]
        A = (self.cfg.penalty * obj.std() / max(1.0, self._dev[s].std()) ** 2 if self.cfg.penalty_mode == "std"
             else self.cfg.penalty * float(np.ptp(obj)))
        D0, C, d = inst.c[0, cust].astype(float), inst.c[np.ix_(cust, cust)].astype(float), inst.d[cust].astype(float)
        m = len(cust)
        Q = np.zeros((m, m))
        Q[np.diag_indices(m)] = b * D0 - lam[cust - 1] + A * (d * d - 2 * inst.Q * d)
        iu = np.triu_indices(m, 1)
        Q[iu] = g * C[iu] + 2 * A * np.outer(d, d)[iu]
        return Q, a + A * inst.Q ** 2

    def _angles(self, s: int, E: np.ndarray):
        """QAOA angles for slice s (optimised on the exact simulator, warm-started)."""
        kw, p = self.subs[s].kw(), self.cfg.p
        if s not in self.angles or self.cfg.reoptimize:
            res = qaoa_optimize(E, p, alpha=self.cfg.alpha, restarts=self.cfg.restarts,
                                seed=int(self.rng.integers(1 << 31)), x0=self.angles.get(s),
                                maxfun=self.cfg.maxfun, **kw)
            self.angles[s] = res["x"]
            self.stats["qaoa_evals"] += res["nfev"]
        x = self.angles[s]                                   # normalised-cost units
        return x[:p] / max(1e-12, E.std()), x[p:]

    def sample_slice(self, s: int, lam: np.ndarray, sur: Surrogate, shots: int):
        """Global masks of the feasible samples of one slice (with repeats) + diagnostics."""
        sub = self.subs[s]
        E, feas = self.energies(s, lam, sur)
        if self.cfg.sampler == "uniform":
            idx = self.rng.integers(sub.dim, size=shots)
        else:
            g, b = self._angles(s, E)
            idx, _ = sample(E, g, b, shots, seed=int(self.rng.integers(1 << 31)), **sub.kw())
        self.stats["shots"] += shots
        self.stats["calls"] += 1
        ok = idx[feas[idx]]
        return self._gmask[s][ok], {"shots": shots, "feasible_frac": float(feas[idx].mean()),
                                    "distinct": int(np.unique(ok).size)}

    def _hardware_round(self, lam: np.ndarray, sur: Surrogate, shots: dict[int, int] | None):
        """All slices of one pricing round as ONE batch of hardware requests."""
        from .executor import Request
        reqs, info = [], []
        for s in self.sizes:
            n_shots = (shots or {}).get(s, self.cfg.shots)
            if n_shots <= 0:
                continue
            E, feas = self.energies(s, lam, sur)
            g, b = self._angles(s, E)
            Q, _ = self.qubo(s, lam, sur)
            reqs.append(Request(Q, s, list(map(float, g)), list(map(float, b)), self.subs[s].pairs, n_shots,
                                tag=f"pricing {len(self.customers)}q"))
            info.append((s, feas, n_shots))
        outs = self.executor.sample_many(reqs)
        res = {}
        for (s, feas, n_shots), idx in zip(info, outs):
            self.stats["shots"] += n_shots
            self.stats["calls"] += 1
            ok = idx[feas[idx]] if len(idx) else idx
            res[s] = (self._gmask[s][ok], {"shots": n_shots, "kept": int(len(idx)),
                                           "feasible_frac": float(feas[idx].mean()) if len(idx) else 0.0,
                                           "distinct": int(np.unique(ok).size)})
        return res

    def price(self, lam: np.ndarray, sur: Surrogate, shots: dict[int, int] | None = None):
        """One pricing round.  Returns ({mask: exact cost}, {mask: slice}, diagnostics)."""
        found, slice_of, diag = {}, {}, {}
        hw = self._hardware_round(lam, sur, shots) if (self.executor and self.cfg.sampler == "qaoa") else None
        for s in self.sizes:
            n_shots = (shots or {}).get(s, self.cfg.shots)
            if n_shots <= 0:
                continue
            masks, diag[s] = hw[s] if hw is not None else self.sample_slice(s, lam, sur, n_shots)
            for m in np.unique(masks):
                m = int(m)
                if m not in found:
                    found[m] = tsp_exact(self.inst, m)[0]
                    slice_of[m] = s
        if self.full_route is not None and self.full_route not in found:
            found[self.full_route] = tsp_exact(self.inst, self.full_route)[0]
            slice_of[self.full_route] = len(self.customers)
        return found, slice_of, diag
