"""Hardware round 3: one Batch of experiments that decides how to run full instances on a QPU.

    python -m qvrp.hw_lab prepare    # no QPU time: build + verify + transpile every circuit, cost estimate
    python -m qvrp.hw_lab submit     # ONE Batch of 4 jobs on ibm_kingston (scheduled together)
    python -m qvrp.hw_lab analyze    # answers Q1-Q7 -> results/hardware/lab_results.json + lab_report.md

Questions (each experiment row carries its question tag):
  Q1  reproducibility   round-2 circuits (p=1, product start, sparsified) rerun hours later
  Q2  depth             the same 4 circuits at p = 2
  Q3  initial state     product start vs Bartschi-Eidenbenz Dicke circuit (2 instances)
  Q4  sparsification    sparsified vs full couplings (2 instances)
  Q5  mitigation        4 jobs in one Batch with identical circuits: none / DD (XY4) / twirling /
                        DD + twirling; M3 and post-selection compared offline
  Q6  stages            16-qubit first-stage selection (k = 4), residual pricing (~10 qubits),
                        full 20-qubit pricing: can each pipeline stage run on hardware?
  Q7  shots             offline resampling of the measured counts (no QPU time)

Every circuit comes from a real pipeline state (seed-0 simulator run, campaign settings):
selection calls recorded by the staged master; pricing slices at the duals of the final
restricted LP (full instance) or of the residual customers of a recorded residual call.
Angles: p-layer optimised on the exact simulator.  Every circuit is checked against the
exact subspace simulator before it is transpiled.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse  # noqa: E402
import json  # noqa: E402
import time  # noqa: E402
from math import comb  # noqa: E402
from pathlib import Path  # noqa: E402

import numpy as np  # noqa: E402
from qiskit import QuantumCircuit, qpy, transpile  # noqa: E402
from qiskit.quantum_info import Statevector  # noqa: E402

from qobench.quantum import WeightSubspace, qaoa_optimize, qaoa_state  # noqa: E402

from .hardware import calibration_summary, esp, qaoa_circuit, service, sparsify_in_subspace  # noqa: E402
from .instance import Instance, incidence, tsp_exact  # noqa: E402
from .master import master_energies, solve_lp  # noqa: E402
from .pipeline import RAW, load_cg, cg_path, run  # noqa: E402
from .pricing import QuantumPricer, Surrogate  # noqa: E402
from .submit import BUDGET, config  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "results" / "hardware"
BACKEND = "ibm_kingston"
SHOTS, CAL_SHOTS = 4000, 2000
SEL_INSTANCES = ["XSH-n20-k4-36", "XSH-n20-k4-32", "XSH-n20-k4-09", "XSH-n20-k4-17"]
PAIR = ["XSH-n20-k4-36", "XSH-n20-k4-09"]
JOBS = {
    "full":  {"dynamical_decoupling": {"enable": True, "sequence_type": "XY4"},
              "twirling": {"enable_gates": True, "enable_measure": True, "num_randomizations": "auto"}},
    "none":  {"dynamical_decoupling": {"enable": False},
              "twirling": {"enable_gates": False, "enable_measure": False}},
    "dd":    {"dynamical_decoupling": {"enable": True, "sequence_type": "XY4"},
              "twirling": {"enable_gates": False, "enable_measure": False}},
    "twirl": {"dynamical_decoupling": {"enable": False},
              "twirling": {"enable_gates": True, "enable_measure": True, "num_randomizations": "auto"}},
}
COST = (1.75, 0.3125e-3)          # QPU seconds per job + per shot, fitted on rounds 1 and 2


# -- pipeline states ---------------------------------------------------------------------
def selection_calls(name: str):
    pcfg, cgcfg, mcfg = config("qaoa")
    r = run(name, pcfg, cgcfg, mcfg, 0, f"hw_{BUDGET}", log=lambda *a: None)
    return [c for c in r["calls"] if c["kind"] == "select" and c["angles"]]


def selection_problem(name: str, call: dict):
    inst = Instance.load(name)
    pm, pc, k = np.array(call["pool"], np.int64), np.array(call["pool_costs"], float), call["k"]
    X = incidence(pm, inst.n).astype(float)
    Q = np.diag(pc) + np.triu(X @ X.T, 1) * call["P"]
    sub = WeightSubspace(len(pm), k, "ring")
    E, feas = master_energies(sub, X, pc, call["P"])
    if feas.any():                                   # target = the best complete plan in the pool
        targets, label = [int(np.argmin(np.where(feas, E, np.inf)))], f"select {len(pm)}q k={k}"
    else:                                            # first-stage pools hold no complete plan: staging
        targets = [int(i) for i in np.argsort(E)[:10]]   # mines partial plans from low-energy samples
        label = f"select {len(pm)}q k={k} (10 lowest-E)"
    return {"Q": Q, "k": k, "sub": sub, "E": E, "feas": feas, "targets": targets, "alpha": 0.1,
            "label": label}


def pricing_problem(name: str, customers=None, prefer_dim: int = 20000, tag: str = f"hw_{BUDGET}", seed: int = 0):
    """One pricing slice at the duals of the final restricted LP (all customers) or of the
    residual customers.  Targets = the 10 feasible routes of lowest true reduced cost."""
    inst = Instance.load(name)
    pcfg, _, _ = config("qaoa")
    cg = load_cg(cg_path(name, seed, tag))
    pool = {int(m): int(c) for m, c in zip(cg["masks"], cg["costs"])}
    if customers is None:
        lam = cg["lam"]
    else:
        cols = [m for m in pool if m & ~inst.mask(customers) == 0]
        lam = solve_lp(cols, [pool[m] for m in cols], inst.n, float(2 * inst.c[0, 1:].sum()), customers)[1]
    sur = Surrogate(inst).fit(list(pool), list(pool.values()))
    pr = QuantumPricer(inst, pcfg, 0, customers=customers)
    # the slice closest to prefer_dim amplitudes that has >= 3 feasible routes
    best_s = None
    for s in pr.sizes:
        E, feas = pr.energies(s, lam, sur)
        if feas.sum() >= 3 and (best_s is None or abs(np.log(pr.subs[s].dim / prefer_dim)) < abs(np.log(pr.subs[best_s].dim / prefer_dim))):
            best_s = s
    if best_s is None:                                   # fall back: any slice with a feasible route
        cand = [s_ for s_ in pr.sizes if pr.energies(s_, lam, sur)[1].any()]
        if not cand:
            raise ValueError(f"{name}: no route of load Q inside these customers")
        best_s = min(cand, key=lambda s_: abs(np.log(pr.subs[s_].dim / prefer_dim)))
    s = best_s
    sub = pr.subs[s]
    E, feas = pr.energies(s, lam, sur)
    # the same energy as a QUBO on the slice's qubits (for the circuit)
    cust = pr.customers
    a, b, g = sur.coeffs(s)
    D0, C, d = inst.c[0, cust].astype(float), inst.c[np.ix_(cust, cust)].astype(float), inst.d[cust].astype(float)
    obj = a + pr._feat[s] @ np.array([b, g]) - pr._X[s] @ lam[cust - 1]
    A = pcfg.penalty * float(np.ptp(obj)) if pcfg.penalty_mode == "range" else \
        pcfg.penalty * obj.std() / max(1.0, pr._dev[s].std()) ** 2
    m = len(cust)
    Q = np.zeros((m, m))
    Q[np.diag_indices(m)] = b * D0 - lam[cust - 1] + A * (d * d - 2 * inst.Q * d)
    iu = np.triu_indices(m, 1)
    Q[iu] = g * C[iu] + 2 * A * np.outer(d, d)[iu]
    e_chk = sub.energies_from_qubo(Q, a + A * inst.Q ** 2)
    assert np.allclose(e_chk, E, rtol=1e-9, atol=1e-6 * np.abs(E).max()), "pricing QUBO != pricer energies"
    # targets: true reduced cost (Held-Karp) of every feasible route in the slice
    fidx = np.nonzero(feas)[0]
    gm = pr._gmask[s][fidx]
    rc = np.array([tsp_exact(inst, int(mm))[0] - lam[np.array(inst.members(int(mm))) - 1].sum() for mm in gm])
    targets = [int(i) for i in fidx[np.argsort(rc)[:10]]]
    return {"Q": Q, "k": s, "sub": sub, "E": E, "feas": feas, "targets": targets, "alpha": 0.05,
            "label": f"pricing {m}q s={s}", "customers": [int(c) for c in cust]}


# -- experiment construction ---------------------------------------------------------------
def make_circuit(P: dict, p: int, init: str, sparse: bool):
    sub, E, k = P["sub"], P["E"], P["k"]
    res = qaoa_optimize(E, p, alpha=P["alpha"], restarts=6, maxfun=2000, **sub.kw())
    g, b = [float(x) for x in res["gammas"]], [float(x) for x in res["betas"]]
    prob = np.abs(qaoa_state(E, g, b, **sub.kw())) ** 2
    Q = sparsify_in_subspace(P["Q"])[0] if sparse else P["Q"]
    qc = qaoa_circuit(Q, k, g, b, sub.pairs, init=init)
    if sub.m <= 16:                                          # exact check against the simulator
        sv = np.abs(Statevector(qaoa_circuit(Q, k, g, b, sub.pairs, measure=False, init=init)).data[sub.states]) ** 2
        assert np.allclose(sv / sv.sum(), prob, atol=1e-7), "circuit != simulator"
    key = lambda i: format(int(sub.states[i]), f"0{sub.m}b")
    acc = comb(sub.m, k) * (k / sub.m) ** k * (1 - k / sub.m) ** (sub.m - k) if init == "product" else 1.0
    return qc, {"gammas": g, "betas": b, "target_keys": [key(i) for i in P["targets"]],
                "feas_keys": [key(i) for i in np.nonzero(P["feas"])[0]], "k": k, "qubits": sub.m,
                "dim": int(sub.dim), "ideal_p_target": float(prob[P["targets"]].sum()),
                "ideal_p_feasible": float(prob[P["feas"]].sum()),
                "uniform_p_target": len(P["targets"]) / sub.dim, "uniform_p_feasible": float(P["feas"].mean()),
                "acceptance_ideal": acc, "label": P["label"]}


def prepare():
    be = service().backend(BACKEND)
    exps = []

    def add(q, name, P, p, init, sparse, jobs):
        qc, meta = make_circuit(P, p, init, sparse)
        tq = max((transpile(qc, be, optimization_level=3, seed_transpiler=s) for s in range(12)),
                 key=lambda t: esp(t, be))
        meta.update(question=q, instance=name, p=p, init=init, sparse=sparse, jobs=jobs,
                    cz=int(tq.count_ops().get("cz", 0)), depth=tq.depth(), esp=esp(tq, be),
                    layout=[int(x) for x in tq.layout.final_index_layout()])
        exps.append((meta, tq))
        print(f"{q:3s} {name[-2:]} {meta['label']:22s} p={p} {init:7s} {'sparse' if sparse else 'full  '} "
              f"CZ {meta['cz']:4d} ESP {meta['esp']:.3f} ideal {meta['ideal_p_target'] / meta['uniform_p_target']:.1f}x "
              f"jobs {jobs}", flush=True)

    sel = {}
    for name in SEL_INSTANCES:
        calls = selection_calls(name)
        small = [c for c in calls if 8 <= c["qubits"] <= 10 and c["k"] == 2]
        sel[name] = {"small": max(small, key=lambda c: c["dim"]) if small else None,
                     "first": next((c for c in calls if c["depth"] == 0), None),
                     "residual": next((c for c in calls if c["depth"] > 0 and c["qubits"] >= 6), None)}
    for name in SEL_INSTANCES:                               # Q1 + Q5 (all four jobs), Q2
        P = selection_problem(name, sel[name]["small"])
        add("Q1", name, P, 1, "product", True, list(JOBS))
        add("Q2", name, P, 2, "product", True, ["full"])
    for name in PAIR:                                        # Q3, Q4
        P = selection_problem(name, sel[name]["small"])
        add("Q3", name, P, 1, "dicke", True, ["full"])
        add("Q4", name, P, 1, "product", False, ["full"])
    for name in PAIR:                                        # Q6: stages
        add("Q6", name, selection_problem(name, sel[name]["first"]), 1, "product", True, ["full"])
        inst = Instance.load(name)
        R = 0
        for m_ in sel[name]["residual"]["pool"]:
            R |= m_
        add("Q6", name, pricing_problem(name, inst.members(R), prefer_dim=200), 1, "product", False, ["full"])
    add("Q6", PAIR[0], pricing_problem(PAIR[0], None, prefer_dim=15000), 1, "product", False, ["full"])

    OUT.mkdir(parents=True, exist_ok=True)
    with open(OUT / "lab_circuits.qpy", "wb") as f:
        qpy.dump([t for _, t in exps], f)
    shots = {j: sum(SHOTS for m, _ in exps if j in m["jobs"]) + 2 * CAL_SHOTS for j in JOBS}
    est = {j: COST[0] + COST[1] * s for j, s in shots.items()}
    meta = {"backend": calibration_summary(be), "jobs": JOBS, "shots": SHOTS, "cal_shots": CAL_SHOTS,
            "experiments": [m for m, _ in exps], "shots_per_job": shots, "estimated_qpu_seconds": est,
            "estimated_total": sum(est.values())}
    (OUT / "lab_prepare.json").write_text(json.dumps(meta, indent=1, default=float))
    print(f"{len(exps)} circuits; shots per job {shots}; estimated QPU s {({j: round(v, 1) for j, v in est.items()})} "
          f"total {meta['estimated_total']:.1f}", flush=True)
    return meta


def submit(max_seconds: float):
    from qiskit_ibm_runtime import Batch, SamplerV2
    from .hw_batch import calibration_circuits
    meta = json.loads((OUT / "lab_prepare.json").read_text())
    if meta["estimated_total"] > max_seconds:
        raise SystemExit(f"estimated {meta['estimated_total']:.1f} s > budget {max_seconds} s; not submitted")
    with open(OUT / "lab_circuits.qpy", "rb") as f:
        circuits = qpy.load(f)
    svc = service()
    be = svc.backend(BACKEND)
    cal_q, cals = calibration_circuits([m["layout"] for m in meta["experiments"]], be.num_qubits)
    cals = [transpile(c, be, optimization_level=0) for c in cals]
    out = {"cal_qubits": cal_q, "jobs": {}}
    jobs = {}
    with Batch(backend=be) as batch:
        for j, opts in JOBS.items():
            idx = [i for i, m in enumerate(meta["experiments"]) if j in m["jobs"]]
            pubs = [(circuits[i], None, SHOTS) for i in idx] + [(c, None, CAL_SHOTS) for c in cals]
            jobs[j] = (SamplerV2(mode=batch, options=opts).run(pubs), idx)
            print(f"job {j}: {jobs[j][0].job_id()} ({len(idx)} circuits + 2 calibration)", flush=True)
    t = time.time()
    for j, (job, idx) in jobs.items():
        res = job.result()
        counts = [res[i].data.meas.get_counts() for i in range(len(idx))]
        cal = []
        for i in range(2):
            d = res[len(idx) + i].data
            cal.append(getattr(d, list(d.keys())[0]).get_counts())
        out["jobs"][j] = {"job_id": job.job_id(), "experiments": idx, "counts": counts, "cal_counts": cal,
                          "metrics": job.metrics()}
        print(f"job {j} done; QPU s {job.metrics().get('usage', {}).get('qpu_charge_time_seconds')}", flush=True)
    out["wall_seconds"] = round(time.time() - t, 1)
    (OUT / "lab_hardware.json").write_text(json.dumps(out, default=str))
    return out


# -- analysis ------------------------------------------------------------------------------
def _score(counts: dict, k: int, target_keys, feas_keys):
    tot = sum(counts.values())
    keep = {b: v for b, v in counts.items() if b.count("1") == k}
    kt = sum(keep.values())
    return {"kept": kt / tot if tot else 0.0,
            "p_target": sum(keep.get(t, 0) for t in target_keys) / kt if kt else 0.0,
            "p_feasible": sum(keep.get(f, 0) for f in feas_keys) / kt if kt else 0.0,
            "raw_p_target": sum(counts.get(t, 0) for t in target_keys) / tot if tot else 0.0,
            "kept_shots": kt, "target_hits": sum(keep.get(t, 0) for t in target_keys)}


def analyze():
    import mthree
    from scipy.stats import binomtest, norm
    from .hw_batch import readout_matrices
    meta = json.loads((OUT / "lab_prepare.json").read_text())
    hw = json.loads((OUT / "lab_hardware.json").read_text())
    exps = meta["experiments"]
    rows = []
    for j, J in hw["jobs"].items():
        mit = mthree.M3Mitigation()
        mit.cals_from_matrices(readout_matrices({"cal_qubits": hw["cal_qubits"], "cal_counts": J["cal_counts"]}, 156))
        for i, counts in zip(J["experiments"], J["counts"]):
            e = exps[i]
            s = _score(counts, e["k"], e["target_keys"], e["feas_keys"])
            q = mit.apply_correction(counts, e["layout"]).nearest_probability_distribution()
            sm = _score({b: v * 1e6 for b, v in q.items()}, e["k"], e["target_keys"], e["feas_keys"])
            p = binomtest(s["target_hits"], s["kept_shots"], e["uniform_p_target"], alternative="greater").pvalue \
                if s["kept_shots"] else 1.0
            rows.append({"job": j, "exp": i, "question": e["question"], "instance": e["instance"], "label": e["label"],
                         "p": e["p"], "init": e["init"], "sparse": e["sparse"], "qubits": e["qubits"], "k": e["k"],
                         "cz": e["cz"], "esp": e["esp"], "acceptance_ideal": e["acceptance_ideal"],
                         "ideal_gain": e["ideal_p_target"] / e["uniform_p_target"],
                         "uniform_p_target": e["uniform_p_target"], **s,
                         "gain": s["p_target"] / e["uniform_p_target"],
                         "gain_m3": sm["p_target"] / e["uniform_p_target"], "binomial_p": p})

    def two_prop(a, b):            # one-sided test that row a has the larger post-selected rate
        p1, n1, p2, n2 = a["p_target"], a["kept_shots"], b["p_target"], b["kept_shots"]
        pp = (p1 * n1 + p2 * n2) / (n1 + n2)
        se = np.sqrt(pp * (1 - pp) * (1 / n1 + 1 / n2)) or 1e-12
        return float(norm.sf((p1 - p2) / se))

    R = {(r["job"], r["exp"]): r for r in rows}
    full = {r["exp"]: r for r in rows if r["job"] == "full"}
    answers = {}
    q1 = [full[i] for i, e in enumerate(exps) if e["question"] == "Q1"]
    answers["Q1"] = [{"instance": r["instance"], "gain": r["gain"], "gain_m3": r["gain_m3"]} for r in q1]
    answers["Q2"] = []
    for r1 in q1:
        r2 = next(full[i] for i, e in enumerate(exps) if e["question"] == "Q2" and e["instance"] == r1["instance"])
        answers["Q2"].append({"instance": r1["instance"], "p1_gain": r1["gain"], "p2_gain": r2["gain"],
                              "p1_cz": r1["cz"], "p2_cz": r2["cz"], "p2_better_p": two_prop(r2, r1),
                              "p1_ideal": r1["ideal_gain"], "p2_ideal": r2["ideal_gain"]})
    for q, field in (("Q3", "init"), ("Q4", "sparse")):
        answers[q] = []
        for i, e in enumerate(exps):
            if e["question"] != q:
                continue
            base = next(full[k] for k, f in enumerate(exps) if f["question"] == "Q1" and f["instance"] == e["instance"])
            alt = full[i]
            answers[q].append({"instance": e["instance"], "baseline_gain": base["gain"], "variant_gain": alt["gain"],
                               "baseline_cz": base["cz"], "variant_cz": alt["cz"], "baseline_kept": base["kept"],
                               "variant_kept": alt["kept"], "variant": f"{field}={e[field]}",
                               "baseline_better_p": two_prop(base, alt)})
    answers["Q5"] = {}
    for j in JOBS:
        rr = [R[(j, i)] for i, e in enumerate(exps) if e["question"] == "Q1" and (j, i) in R]
        hits, kept = sum(r["target_hits"] for r in rr), sum(r["kept_shots"] for r in rr)
        exp_u = sum(r["kept_shots"] * r["uniform_p_target"] for r in rr)
        answers["Q5"][j] = {"mean_gain": float(np.mean([r["gain"] for r in rr])),
                            "mean_gain_m3": float(np.mean([r["gain_m3"] for r in rr])),
                            "mean_kept": float(np.mean([r["kept"] for r in rr])),
                            "pooled_hits": hits, "pooled_expected_uniform": exp_u, "kept_shots": kept}
    answers["Q6"] = [{k: full[i][k] for k in ("instance", "label", "qubits", "k", "cz", "esp", "kept",
                                              "acceptance_ideal", "gain", "gain_m3", "ideal_gain", "binomial_p")}
                     for i, e in enumerate(exps) if e["question"] == "Q6"]
    # Q7: shots needed so that the best plan appears at least once with 95% probability,
    # from the measured per-shot rate of the best plan (raw shots, before post-selection)
    answers["Q7"] = []
    for r in q1 + [full[i] for i, e in enumerate(exps) if e["question"] == "Q6"]:
        rate = r["raw_p_target"]
        need = float(np.log(0.05) / np.log(1 - rate)) if 0 < rate < 1 else None
        answers["Q7"].append({"instance": r["instance"], "label": r["label"], "per_shot_rate": rate,
                              "shots_for_95pct": need})
    usage = {j: J["metrics"].get("usage", {}).get("qpu_charge_time_seconds") for j, J in hw["jobs"].items()}
    res = {"jobs": {j: J["job_id"] for j, J in hw["jobs"].items()}, "qpu_seconds": usage, "rows": rows,
           "answers": answers, "backend": meta["backend"]}
    (OUT / "lab_results.json").write_text(json.dumps(res, indent=1, default=float))
    print(json.dumps({"qpu_seconds": usage, "Q5": answers["Q5"]}, indent=1, default=float))
    return res


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("step", choices=["prepare", "submit", "analyze"])
    ap.add_argument("--max-seconds", type=float, default=52.0)
    a = ap.parse_args()
    {"prepare": prepare, "submit": lambda: submit(a.max_seconds), "analyze": analyze}[a.step]()
