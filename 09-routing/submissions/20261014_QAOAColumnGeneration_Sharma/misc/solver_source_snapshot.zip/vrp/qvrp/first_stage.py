"""Shrink the first route selection below ~200 CZ (simulation only, no QPU time).

    python -m qvrp.first_stage cz       [--instances 12]   # CZ of every selection call per design
    python -m qvrp.first_stage quality  [--seeds 0 1 2]     # end-to-end plans, QAOA vs uniform
    python -m qvrp.first_stage report

Every design runs the staged master in *hardware shape*: every quantum call at QAOA depth
p = 1 (residual pricing included), 300 shots, on the cached stage-1 pools of the submission
campaign.  The CZ count is that of the hardware circuit of each recorded call: product-state
start, subspace-sparsified couplings, best of 8 transpiler seeds on FakeKingston (the offline
snapshot of ibm_kingston).  A Dicke-state QAOA in the simulator equals the product-start
circuit after post-selection, so the simulated plans are those the hardware recipe targets.
"""
from __future__ import annotations

import os

os.environ.setdefault("OMP_NUM_THREADS", "1")

import argparse  # noqa: E402
import json  # noqa: E402
from concurrent.futures import ProcessPoolExecutor  # noqa: E402
from dataclasses import replace  # noqa: E402
from pathlib import Path  # noqa: E402

import numpy as np  # noqa: E402

from .instance import NAMES, Instance, incidence  # noqa: E402
from .master import MasterConfig, StagedMaster  # noqa: E402
from .pipeline import cg_path, load_cg  # noqa: E402
from .pricing import V1, PricingConfig  # noqa: E402

OUT = Path(__file__).resolve().parents[1] / "results" / "first_stage"
SHOTS = 300
BASE = dict(sampler="qaoa", shots=SHOTS, residual_shots=SHOTS, p=1)
DESIGNS = {
    "campaign (B16 k4, p=4)":  dict(sampler="qaoa", shots=SHOTS, residual_shots=SHOTS),
    "B16 k4":                  dict(BASE, B=16),
    "B12 k4, fix>=2":          dict(BASE, B=12, B_residual=10, min_fix=2),
    "B10 k4, fix>=2":          dict(BASE, B=10, B_residual=10, min_fix=2),
    "B12 pair-first":          dict(BASE, B=12, B_residual=10, k_first=2, min_fix=2),
    "B10 pair-first":          dict(BASE, B=10, B_residual=10, k_first=2, min_fix=2),
    "B8 pair-first":           dict(BASE, B=8, B_residual=10, k_first=2, min_fix=2),
    "B10 pair-first, residual<=11": dict(BASE, B=10, B_residual=10, k_first=2, min_fix=2, max_residual=11),
    "B10 k4, fix>=2, residual<=11": dict(BASE, B=10, B_residual=10, min_fix=2, max_residual=11),
    "B10 pair-first, residual<=10": dict(BASE, B=10, B_residual=10, k_first=2, min_fix=2, max_residual=10),
}


def master(name: str, seed: int, sampler: str, design: str):
    inst = Instance.load(name)
    cg = load_cg(cg_path(name, seed, f"submit_{sampler}_b300"))
    kw = dict(DESIGNS[design], sampler=sampler)
    pcfg = PricingConfig(**V1, shots=SHOTS, sampler=sampler)
    if design != "campaign (B16 k4, p=4)":
        pcfg = replace(pcfg, p=1)                          # residual pricing at hardware depth too
    return inst, StagedMaster(inst, cg, MasterConfig(**kw), pcfg, seed=seed).run()


# -- CZ ---------------------------------------------------------------------------------
def cz_job(name: str, design: str):
    from qiskit import transpile
    from qiskit_ibm_runtime.fake_provider import FakeKingston

    from qobench.quantum import WeightSubspace
    from .hardware import esp, qaoa_circuit, sparsify_in_subspace
    be = FakeKingston()
    inst, r = master(name, 0, "qaoa", design)
    rows = []
    for c in r["calls"]:
        if c["kind"] == "pricing":
            from qobench.quantum import qaoa_optimize
            from .hw_lab import pricing_problem
            try:
                P = pricing_problem(name, c["customers"], prefer_dim=200, tag="submit_qaoa_b300")
            except ValueError:
                continue
            res = qaoa_optimize(P["E"], 1, alpha=0.05, restarts=2, **P["sub"].kw())
            qc = qaoa_circuit(P["Q"], P["k"], res["gammas"], res["betas"], P["sub"].pairs, init="product")
            tq = max((transpile(qc, be, optimization_level=3, seed_transpiler=s) for s in range(8)),
                     key=lambda t: esp(t, be))
            rows.append({"instance": name, "design": design, "kind": "pricing", "depth": None, "qubits": c["qubits"],
                         "k": P["k"], "cz": int(tq.count_ops().get("cz", 0)), "esp": esp(tq, be)})
            continue
        if not c.get("angles"):
            continue
        X = incidence(c["pool"], inst.n).astype(float)
        Q = np.diag(np.array(c["pool_costs"], float)) + np.triu(X @ X.T, 1) * c["P"]
        sub = WeightSubspace(c["qubits"], c["k"], "ring")
        g = c["angles"]["gammas"][:1] if len(c["angles"]["gammas"]) > 1 else c["angles"]["gammas"]
        b = c["angles"]["betas"][:1] if len(c["angles"]["betas"]) > 1 else c["angles"]["betas"]
        qc = qaoa_circuit(sparsify_in_subspace(Q)[0], c["k"], g, b, sub.pairs, init="product")
        tq = max((transpile(qc, be, optimization_level=3, seed_transpiler=s) for s in range(8)),
                 key=lambda t: esp(t, be))
        rows.append({"instance": name, "design": design, "kind": "select", "depth": c["depth"], "qubits": c["qubits"],
                     "k": c["k"], "cz": int(tq.count_ops().get("cz", 0)), "esp": esp(tq, be),
                     "p1_cz_of_pipeline_call": len(c["angles"]["gammas"]) == 1})
    return rows


def cmd_cz(n: int, workers: int, designs=None):
    designs = designs or [d for d in DESIGNS if d != "campaign (B16 k4, p=4)"]
    names = NAMES[:: max(1, len(NAMES) // n)][:n]
    f = OUT / "cz.json"
    old = [r for r in json.loads(f.read_text()) if r["design"] not in designs] if f.exists() else []
    jobs = [(nm, d) for d in designs for nm in names]
    OUT.mkdir(parents=True, exist_ok=True)
    with ProcessPoolExecutor(workers) as ex:
        rows = old + [r for rs in ex.map(cz_job, *zip(*jobs)) for r in rs]
    f.write_text(json.dumps(rows, indent=1, default=float))
    print(f"{len(rows)} calls")


# -- quality --------------------------------------------------------------------------------
def q_job(name: str, seed: int, sampler: str, design: str):
    inst, r = master(name, seed, sampler, design)
    sel = [c for c in r["calls"] if c["kind"] == "select"]
    pri = [c for c in r["calls"] if c["kind"] == "pricing"]
    opt = inst.optimum()
    return {"instance": name, "seed": seed, "sampler": sampler, "design": design, "cost": r["cost"],
            "optimal": r["cost"] == opt, "gap_pct": None if r["cost"] is None else 100 * (r["cost"] - opt) / opt,
            "select_calls": len(sel), "pricing_calls": len(pri),
            "first_qubits": sel[0]["qubits"] if sel else None,
            "max_select_qubits": max([c["qubits"] for c in sel], default=0),
            "max_pricing_qubits": max([c["qubits"] for c in pri], default=0),
            "shots": r["shots"]}


def cmd_quality(seeds, workers: int, designs=None):
    designs = designs or list(DESIGNS)
    f = OUT / "quality.json"
    old = [r for r in json.loads(f.read_text()) if r["design"] not in designs] if f.exists() else []
    jobs = [(n, s, smp, d) for d in designs for s in seeds for smp in ("qaoa", "uniform") for n in NAMES]
    OUT.mkdir(parents=True, exist_ok=True)
    with ProcessPoolExecutor(workers) as ex:
        rows = old + list(ex.map(q_job, *zip(*jobs), chunksize=4))
    f.write_text(json.dumps(rows, indent=1, default=float))
    print(f"{len(rows)} runs")


def cmd_report():
    import pandas as pd
    from scipy.stats import wilcoxon
    cz = pd.DataFrame(json.loads((OUT / "cz.json").read_text()))
    q = pd.DataFrame(json.loads((OUT / "quality.json").read_text()))
    q["feasible"] = q.cost.notna()
    lines = ["| design | first call: qubits / k | first call CZ (median, max) | later selection CZ (max) | "
             "residual pricing qubits, CZ (max) | QAOA runs feasible | QAOA optimal | QAOA mean gap | "
             "uniform optimal | uniform mean gap | paired QAOA : uniform | Wilcoxon p |",
             "|---|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    summary = []
    for d in DESIGNS:
        c = cz[(cz.design == d) & (cz.kind == "select")]
        first, later = c[c.depth == 0], c[c.depth != 0]
        pr = cz[(cz.design == d) & (cz.kind == "pricing")]
        qq, uu = q[(q.design == d) & (q.sampler == "qaoa")], q[(q.design == d) & (q.sampler == "uniform")]
        p = qq.merge(uu, on=["instance", "seed"], suffixes=("_q", "_u")).dropna(subset=["cost_q", "cost_u"])
        diff = (p.cost_u - p.cost_q).values
        pv = wilcoxon(diff[diff != 0], alternative="greater").pvalue if (diff != 0).sum() > 5 else float("nan")
        row = {"design": d,
               "first": f"{int(first.qubits.median())} / {int(first.k.median())}" if len(first) else "–",
               "first_cz_med": int(first.cz.median()) if len(first) else None,
               "first_cz_max": int(first.cz.max()) if len(first) else None,
               "later_cz_max": int(later.cz.max()) if len(later) else None,
               "pricing_q_max": int(pr.qubits.max()) if len(pr) else None,
               "pricing_cz_max": int(pr.cz.max()) if len(pr) and "cz" in pr and pr.cz.notna().any() else None,
               "q_feasible": qq.feasible.mean(), "q_opt": qq.optimal.mean(), "q_gap": qq.gap_pct.mean(),
               "u_opt": uu.optimal.mean(), "u_gap": uu.gap_pct.mean(),
               "q_better": int((diff > 0).sum()), "u_better": int((diff < 0).sum()), "p": pv}
        summary.append(row)
        cz_txt = "n/a (p = 4, not a hardware circuit)" if row["first_cz_med"] is None else f"{row['first_cz_med']}, {row['first_cz_max']}"
        lines.append(f"| {d} | {row['first']} | {cz_txt} | {row['later_cz_max'] or '–'} | {row['pricing_q_max'] or '–'}, {row['pricing_cz_max'] or '–'} | "
                     f"{100 * row['q_feasible']:.0f}% | {100 * row['q_opt']:.1f}% | {row['q_gap']:.2f}% | "
                     f"{100 * row['u_opt']:.1f}% | {row['u_gap']:.2f}% | {row['q_better']} : {row['u_better']} | {pv:.1g} |")
    (OUT / "summary.json").write_text(json.dumps(summary, indent=1, default=float))
    (OUT / "table.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["cz", "quality", "report"])
    ap.add_argument("--instances", type=int, default=12)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--workers", type=int, default=14)
    ap.add_argument("--designs", nargs="+", default=None)
    a = ap.parse_args()
    if a.cmd == "cz":
        cmd_cz(a.instances, a.workers, a.designs)
    elif a.cmd == "quality":
        cmd_quality(a.seeds, a.workers, a.designs)
    else:
        cmd_report()
