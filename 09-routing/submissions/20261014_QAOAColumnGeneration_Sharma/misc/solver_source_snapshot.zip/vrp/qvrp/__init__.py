"""Qubit-scalable quantum CVRP for the QOBLIB 09-routing (XSH) instances."""
