"""Hardware mode: run many staged searches in lock-step and execute their circuits in rounds.

Every quantum call of the staged master (route selection) and of residual pricing becomes a
``Request`` (QUBO, k, angles).  Worker threads (one per instance, plus one per search branch)
block in ``RoundScheduler.sample_many``; as soon as *every* live worker is waiting, the
coordinator executes all pending requests as ONE round:

    request -> hardware circuit (p = 1, product-state start, subspace-sparsified couplings)
            -> transpile (best ESP of a few layouts; replicates use different layouts)
            -> backend: "aer"  = AerSimulator with a device noise model (dress rehearsal, no QPU)
                        "ibm"  = SamplerV2 in an IBM Batch (one job per round, DD XY4, no twirling)
            -> in-round readout calibration (all-0 / all-1), M3 correction per replicate
            -> Hamming-weight post-selection, replicates pooled
            -> draws = subspace indices, as many as kept shots

so the searches see exactly the interface of the simulator path (sampled subspace indices).
A budget guard refuses any IBM round whose estimated QPU seconds would exceed the budget.
"""
from __future__ import annotations

import threading
import time
from pathlib import Path
from dataclasses import dataclass, field

import numpy as np

from qobench.quantum import WeightSubspace

from .hardware import (best_practice_options, esp, estimate_qpu_seconds, qaoa_circuit,
                       sparsify_in_subspace)


@dataclass
class Request:
    Q: np.ndarray                  # QUBO on m qubits (upper triangular)
    k: int                         # Hamming weight of the subspace
    gammas: list
    betas: list
    pairs: list                    # XY-mixer gate order (WeightSubspace.pairs)
    shots: int                     # per replicate
    tag: str = ""
    meta: dict = field(default_factory=dict)


class BudgetExceeded(RuntimeError):
    pass


class RoundScheduler:
    """Collects requests from worker threads and executes them in synchronous rounds."""

    def __init__(self, backend, log=print):
        self.backend = backend
        self.cv = threading.Condition()
        self.active = 0
        self.waiting: list[tuple[list, dict]] = []
        self.log = log
        self.aborted = False

    # worker bookkeeping ------------------------------------------------------------------
    def enter(self):
        with self.cv:
            self.active += 1

    def leave(self):
        with self.cv:
            self.active -= 1
            self.cv.notify_all()

    def spawn(self, fn, *args):
        """Start a worker thread that counts as active until fn returns."""
        box = {}
        self.enter()

        def run():
            try:
                box["out"] = fn(*args)
            except BaseException as e:        # noqa: BLE001 - surfaced by the caller
                box["err"] = e
            finally:
                self.leave()
        t = threading.Thread(target=run, daemon=True)
        t.start()
        return t, box

    def join_all(self, threads):
        """Wait for child workers without blocking the round (the waiter is not active)."""
        self.leave()
        for t, _ in threads:
            t.join()
        self.enter()

    def sample_many(self, reqs: list[Request]) -> list[np.ndarray]:
        if not reqs:
            return []
        box: dict = {}
        with self.cv:
            self.waiting.append((reqs, box))
            self.cv.notify_all()
            while "out" not in box:
                self.cv.wait()
        return box["out"]

    # coordinator ---------------------------------------------------------------------------
    def loop(self):
        while True:
            with self.cv:
                while not (self.active == 0 or (self.waiting and len(self.waiting) == self.active)):
                    self.cv.wait()
                if self.active == 0 and not self.waiting:
                    return
                batch, self.waiting = self.waiting, []
            flat = [r for reqs, _ in batch for r in reqs]
            try:
                outs = self.backend.run_round(flat) if not self.aborted else [np.array([], int)] * len(flat)
            except BudgetExceeded as e:
                self.log(f"budget guard: {e}; remaining requests get no samples")
                self.aborted = True
                outs = [np.array([], int)] * len(flat)
            i = 0
            with self.cv:
                for reqs, box in batch:
                    box["out"] = outs[i:i + len(reqs)]
                    i += len(reqs)
                self.cv.notify_all()


class CircuitBackend:
    """Turns requests into transpiled circuits, executes them, and returns post-selected draws."""

    def __init__(self, device, mode: str, replicates: int = 2, layout_seeds: int = 6,
                 budget_s: float | None = None, seed: int = 0, log=print, max_circuits: int | None = None):
        self.device, self.mode, self.replicates = device, mode, replicates
        cfg_max = getattr(device.configuration(), "max_experiments", None) if hasattr(device, "configuration") else None
        self.max_circuits = (max_circuits or cfg_max or 300) - 2      # room for the 2 calibration circuits
        self.layout_seeds, self.budget_s, self.log = layout_seeds, budget_s, log
        self.rng = np.random.default_rng(seed)
        self.rounds: list[dict] = []
        self.spent_est = 0.0
        self.batch = None                       # IBM Batch context (mode "ibm")
        self.dump = None                        # path: pickle every live round's requests (debugging)
        if mode == "aer":
            from qiskit_aer import AerSimulator
            self.sim = AerSimulator.from_backend(device, seed_simulator=seed)

    # circuits --------------------------------------------------------------------------------
    def _transpile(self, req: Request):
        from qiskit import transpile
        qc = qaoa_circuit(sparsify_in_subspace(req.Q)[0], req.k, req.gammas, req.betas, req.pairs, init="product")
        cands = [transpile(qc, self.device, optimization_level=3, seed_transpiler=s) for s in range(self.layout_seeds)]
        cands.sort(key=lambda t: -esp(t, self.device))
        return cands[: self.replicates] if len(cands) >= self.replicates else cands * self.replicates

    def _transpile_all(self, reqs: list[Request]):
        """Batched version of _transpile: one parallel transpile call per layout seed.  In mode
        "ibm" it runs in a fresh process (qvrp.transpile_worker): the long-lived run process
        deadlocked twice inside qiskit's compiled passes."""
        if self.mode == "ibm":
            return self._transpile_subprocess(reqs)
        from qiskit import transpile
        qcs = [qaoa_circuit(sparsify_in_subspace(r.Q)[0], r.k, r.gammas, r.betas, r.pairs, init="product") for r in reqs]
        per_seed = [transpile(qcs, self.device, optimization_level=3, seed_transpiler=s) for s in range(self.layout_seeds)]
        out = []
        for i in range(len(reqs)):
            cands = sorted((t[i] for t in per_seed), key=lambda t: -esp(t, self.device))
            out.append(cands[: self.replicates] if len(cands) >= self.replicates else cands * self.replicates)
        return out

    def _transpile_subprocess(self, reqs: list[Request]):
        import pickle
        import subprocess
        import sys
        import tempfile

        from qiskit import qpy
        with tempfile.TemporaryDirectory() as d:
            src, dst = Path(d) / "requests.pkl", Path(d) / "circuits.qpy"
            src.write_bytes(pickle.dumps(reqs))
            subprocess.run([sys.executable, "-m", "qvrp.transpile_worker", str(src), str(dst), self.device.name,
                            str(self.layout_seeds), str(self.replicates)], check=True, timeout=1800,
                           cwd=Path(__file__).resolve().parents[1], stdout=subprocess.DEVNULL)
            with open(dst, "rb") as f:
                flat = qpy.load(f)
        R = self.replicates
        return [flat[R * i: R * i + R] for i in range(len(reqs))]

    def _readout_from_properties(self):
        """Per-qubit assignment matrices A[meas, prep] from the device calibration (the values
        AerSimulator.from_backend uses for its readout errors)."""
        props = self.device.properties()
        mats = []
        for q in range(self.device.num_qubits):
            try:
                p10 = props.qubit_property(q, "prob_meas1_prep0")[0]
                p01 = props.qubit_property(q, "prob_meas0_prep1")[0]
            except Exception:                        # property missing: symmetric readout error
                e = props.readout_error(q)
                p10 = p01 = e
            mats.append(np.array([[1 - p10, p01], [p10, 1 - p01]]))
        return mats

    def _calibration(self, layouts):
        from qiskit import transpile

        from .hw_batch import calibration_circuits
        qubits, cals = calibration_circuits(layouts, self.device.num_qubits)
        return qubits, [transpile(c, self.device, optimization_level=0) for c in cals]

    # execution --------------------------------------------------------------------------------
    def _submit(self, circuits, shots, cals, cal_shots):
        from qiskit_ibm_runtime import SamplerV2
        from qiskit_ibm_runtime import Batch
        from qiskit_ibm_runtime.exceptions import IBMRuntimeError
        pubs = [(c, None, shots) for c in circuits] + [(c, None, cal_shots) for c in cals]
        for attempt in range(2):
            if self.batch is None:                    # opened when the first job is ready
                self.batch = Batch(backend=self.device)
            try:
                job = SamplerV2(mode=self.batch, options=best_practice_options()).run(pubs)
                break
            except IBMRuntimeError as e:              # IBM closed the batch (code 1217): open a new one
                if attempt or "closed" not in str(e).lower():
                    raise
                self.log("  batch closed by IBM; opening a new batch")
                self.batch = None
        self.log(f"  round {len(self.rounds) + 1}: job {job.job_id()} submitted ({len(circuits)} circuits)")
        return job

    def close(self):
        if self.batch is not None:
            self.batch.close()

    def _collect(self, job, n):
        res = job.result()
        counts = [res[i].data.meas.get_counts() for i in range(n)]
        cal_counts = []
        for i in range(n, len(res)):
            d = res[i].data
            cal_counts.append(getattr(d, list(d.keys())[0]).get_counts())
        usage = job.metrics().get("usage", {}).get("qpu_charge_time_seconds")
        return counts, cal_counts, {"job_id": job.job_id(), "qpu_seconds": usage, "circuits": n}

    def _execute(self, circuits, shots, cals, cal_shots):
        if self.mode == "aer":
            res = self.sim.run(circuits + cals, shots=shots).result()
            counts = [res.get_counts(i) for i in range(len(circuits))]
            cal_counts = [res.get_counts(len(circuits) + i) for i in range(len(cals))]
            return counts, cal_counts, {"mode": "aer"}
        from qiskit_ibm_runtime import SamplerV2
        pubs = [(c, None, shots) for c in circuits] + [(c, None, cal_shots) for c in cals]
        job = SamplerV2(mode=self.batch, options=best_practice_options()).run(pubs)
        self.log(f"  round {len(self.rounds) + 1}: job {job.job_id()} submitted ({len(circuits)} circuits)")
        res = job.result()
        counts = [res[i].data.meas.get_counts() for i in range(len(circuits))]
        cal_counts = []
        for i in range(len(cals)):
            d = res[len(circuits) + i].data
            cal_counts.append(getattr(d, list(d.keys())[0]).get_counts())
        usage = job.metrics().get("usage", {}).get("qpu_charge_time_seconds")
        return counts, cal_counts, {"mode": "ibm", "job_id": job.job_id(), "qpu_seconds": usage}

    def _run_round_exact(self, reqs: list[Request]) -> list[np.ndarray]:
        """Mode "exact": noiseless subspace simulation, ideal acceptance.  Fast; used to count
        rounds, circuits and shots (and so the QPU cost) before a hardware run."""
        from math import comb

        from qobench.quantum import qaoa_state
        outs, n_circ = [], 0
        for r in reqs:
            sub = WeightSubspace(r.Q.shape[0], r.k, "ring")
            E = sub.energies_from_qubo(r.Q)
            pr = np.abs(qaoa_state(E, r.gammas, r.betas, **sub.kw())) ** 2
            m = r.Q.shape[0]
            acc = comb(m, r.k) * (r.k / m) ** r.k * (1 - r.k / m) ** (m - r.k)
            kept = int(self.rng.binomial(r.shots * self.replicates, acc))
            outs.append(self.rng.choice(sub.dim, size=kept, p=pr / pr.sum()))
            n_circ += self.replicates
        shots = max(r.shots for r in reqs)
        est = estimate_qpu_seconds([n_circ * shots + 2 * 2000])
        self.rounds.append({"mode": "exact", "requests": len(reqs), "circuits": n_circ, "shots": shots,
                            "estimated_qpu_s": round(est, 2), "tags": sorted({r.tag for r in reqs})})
        self.log(f"  round {len(self.rounds)}: {len(reqs)} requests, {n_circ} circuits, est {est:.1f} s")
        return outs

    def run_round(self, reqs: list[Request]) -> list[np.ndarray]:
        if self.mode == "exact":
            return self._run_round_exact(reqs)
        import mthree

        from .hw_batch import readout_matrices
        t0 = time.time()
        shots = max(r.shots for r in reqs)
        cal_shots = 2000
        # a device takes at most max_circuits per job (ibm_kingston: 300); each chunk carries
        # its own 2 readout-calibration circuits, and all chunk jobs are submitted together
        idx = list(range(len(reqs) * self.replicates))
        chunks = [idx[i:i + self.max_circuits] for i in range(0, len(idx), self.max_circuits)] \
            if self.mode == "ibm" else [idx]
        est = estimate_qpu_seconds([len(c) * shots + 2 * cal_shots for c in chunks])
        if self.dump is not None:
            import pickle
            Path(self.dump).write_bytes(pickle.dumps(reqs))
        if self.mode == "ibm" and self.budget_s is not None and self.spent_est + est > self.budget_s:
            raise BudgetExceeded(f"round needs ~{est:.1f} s, {self.budget_s - self.spent_est:.1f} s left")
        bad = [r.tag for r in reqs if not (np.all(np.isfinite(r.gammas)) and np.all(np.isfinite(r.betas))
                                           and np.all(np.isfinite(r.Q)))]
        if bad:
            raise ValueError(f"non-finite angles or QUBO in {len(bad)} request(s): {bad[:5]}")
        self.log(f"  round {len(self.rounds) + 1}: transpiling {len(reqs)} requests x {self.layout_seeds} layout seeds")
        tq = self._transpile_all(reqs)                                   # replicates per request
        flat = [c for group in tq for c in group]
        layouts = [list(c.layout.final_index_layout()) for c in flat]
        counts, mits, info = [None] * len(flat), [None] * len(flat), {"mode": self.mode, "jobs": []}
        if self.mode == "ibm":
            pending = []
            for ch in chunks:
                cal_q, cals = self._calibration([layouts[i] for i in ch])
                job = self._submit([flat[i] for i in ch], shots, cals, cal_shots)
                pending.append((ch, cal_q, job))
            for ch, cal_q, job in pending:
                c_counts, cal_counts, jinfo = self._collect(job, len(ch))
                mit = mthree.M3Mitigation()
                mit.cals_from_matrices(readout_matrices({"cal_qubits": cal_q, "cal_counts": cal_counts},
                                                        self.device.num_qubits))
                for i, c in zip(ch, c_counts):
                    counts[i], mits[i] = c, mit
                info["jobs"].append(jinfo)
            info["job_id"] = ",".join(j["job_id"] for j in info["jobs"])
            info["qpu_seconds"] = sum((j["qpu_seconds"] or 0) for j in info["jobs"])
        else:
            c_counts, _, _ = self._execute(flat, shots, [], cal_shots)
            mit = mthree.M3Mitigation()
            mit.cals_from_matrices(self._readout_from_properties())
            for i, c in enumerate(c_counts):
                counts[i], mits[i] = c, mit
        self.spent_est += est
        outs, kept_tot = self._postselect(reqs, counts, mits, layouts)
        cz = [c.count_ops().get("cz", 0) for c in flat]
        self.rounds.append({**info, "requests": len(reqs), "circuits": len(flat), "shots": shots, "chunks": len(chunks),
                            "estimated_qpu_s": round(est, 2), "kept_fraction": kept_tot / (len(flat) * shots),
                            "cz_max": int(max(cz)), "cz_median": float(np.median(cz)),
                            "tags": sorted({r.tag for r in reqs}), "wall_s": round(time.time() - t0, 1)})
        self.log(f"  round {len(self.rounds)}: {len(reqs)} requests, {len(flat)} circuits, CZ <= {max(cz)}, "
                 f"kept {100 * self.rounds[-1]['kept_fraction']:.1f}%, est {est:.1f} s"
                 + (f", billed {info.get('qpu_seconds')} s" if self.mode == "ibm" else ""))
        return outs

    def _postselect(self, reqs, counts, mits, layouts):
        """Readout-mitigate (M3) each replicate, keep weight-k outcomes, pool the replicates and
        draw as many subspace indices as shots were kept.  Uses self.rng in request order."""
        outs, kept_tot = [], 0
        for i, r in enumerate(reqs):
            m = r.Q.shape[0]
            sub = WeightSubspace(m, r.k, "ring")
            probs, kept = np.zeros(sub.dim), 0
            for j in range(self.replicates):
                c = counts[i * self.replicates + j]
                raw_kept = sum(v for b, v in c.items() if b.count("1") == r.k)
                kept += raw_kept
                q = mits[i * self.replicates + j].apply_correction(c, layouts[i * self.replicates + j]).nearest_probability_distribution()
                w = {int(b, 2): v for b, v in q.items() if b.count("1") == r.k}
                tot = sum(w.values())
                if tot > 0:
                    idx = sub.index(list(w))
                    probs[idx] += raw_kept * np.array(list(w.values())) / tot
            if kept and probs.sum() > 0:
                outs.append(self.rng.choice(sub.dim, size=kept, p=probs / probs.sum()))
            else:
                outs.append(np.array([], int))
            kept_tot += kept
        return outs, kept_tot


def ideal_distribution(circ) -> np.ndarray:
    """Noiseless outcome probabilities of a transpiled circuit over its classical bits (index =
    int(bitstring, 2), clbit 0 least significant).  Only the qubits the circuit touches are simulated."""
    from qiskit import QuantumCircuit
    from qiskit.quantum_info import Statevector
    meas = {circ.find_bit(i.clbits[0]).index: circ.find_bit(i.qubits[0]).index
            for i in circ.data if i.operation.name == "measure"}
    skip = ("barrier", "measure", "delay")
    active = sorted({circ.find_bit(q).index for i in circ.data if i.operation.name not in skip for q in i.qubits}
                    | set(meas.values()))
    pos = {q: j for j, q in enumerate(active)}
    red = QuantumCircuit(len(active))
    for i in circ.data:
        if i.operation.name not in skip:
            red.append(i.operation, [pos[circ.find_bit(q).index] for q in i.qubits])
    return Statevector(red).probabilities(qargs=[pos[meas[c]] for c in range(len(meas))])


class ReplayBackend(CircuitBackend):
    """Resumes a hardware run whose process died after some rounds.  The rounds listed in
    ``replay`` (job IDs per round, in submission order) are NOT executed again: their measured
    counts, transpiled circuits (layouts) and in-job readout calibrations are fetched from IBM.
    Every new request is matched to the stored circuit with the same noiseless output distribution
    (optimal assignment on total-variation distance among circuits with the same qubit count and
    Hamming weight), and the draws are made in the stored circuit order, so the shared random
    stream is consumed exactly as in the original process.  Later rounds run live."""

    def __init__(self, *a, replay: list[list[str]], service=None, cache=None, **kw):
        super().__init__(*a, **kw)
        self.replay, self.service, self.cache = list(replay), service, cache

    def _fetch(self, jid):
        """Stored circuits, counts, calibration counts and usage of one job (cached on disk)."""
        import pickle
        f = Path(self.cache) / f"{jid}.pkl" if self.cache else None
        if f is not None and f.exists():
            return pickle.loads(f.read_bytes())
        job = self.service.job(jid)
        pubs = job.inputs["pubs"]
        n = len(pubs) - 2                                  # last two: readout calibration
        out = ([p[0] for p in pubs[:n]], *self._collect(job, n))
        if f is not None:
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_bytes(pickle.dumps(out))
        return out

    def run_round(self, reqs: list[Request]) -> list[np.ndarray]:
        if not self.replay:
            return super().run_round(reqs)
        import mthree
        from scipy.optimize import linear_sum_assignment

        from qobench.quantum import qaoa_state

        from .hw_batch import calibration_circuits, readout_matrices
        t0 = time.time()
        circs, counts, layouts, mits, jobs = [], [], [], [], []
        for jid in self.replay.pop(0):
            cc, c_counts, cal_counts, jinfo = self._fetch(jid)
            n = len(cc)
            lay = [list(c.layout.final_index_layout()) for c in cc]
            cal_q, _ = calibration_circuits(lay, self.device.num_qubits)
            mit = mthree.M3Mitigation()
            mit.cals_from_matrices(readout_matrices({"cal_qubits": cal_q, "cal_counts": cal_counts},
                                                    self.device.num_qubits))
            circs += cc
            counts += c_counts
            layouts += lay
            mits += [mit] * n
            jobs.append(jinfo)
        R = self.replicates
        if len(circs) != R * len(reqs):
            raise RuntimeError(f"replay: {len(circs)} stored circuits for {len(reqs)} requests x {R} replicates")
        # stored request o = circuits R*o .. R*o+R-1; its shape (m, k): k = mean Hamming weight
        # (the RY start has mean weight k and the XY mixer preserves weight)
        ideal, groups = [], {}
        for o in range(len(reqs)):
            pr = ideal_distribution(circs[R * o])
            m = int(np.log2(len(pr)))
            w = np.array([bin(b).count("1") for b in range(len(pr))])
            k = int(round(float(pr @ w)))
            ideal.append((pr, w))
            groups.setdefault((m, k), [[], []])[1].append(o)
        want = []
        for i, r in enumerate(reqs):
            sub = WeightSubspace(r.Q.shape[0], r.k, "ring")
            pr = np.abs(qaoa_state(sub.energies_from_qubo(r.Q), r.gammas, r.betas, **sub.kw())) ** 2
            want.append((sub, pr / pr.sum()))
            groups.setdefault((r.Q.shape[0], r.k), [[], []])[0].append(i)
        order, tvd, ambiguous, loose = [None] * len(reqs), np.zeros(len(reqs)), 0, []
        for (m, k), (new, old) in groups.items():
            if len(new) != len(old):
                raise RuntimeError(f"replay: shape (m={m}, k={k}): {len(new)} requests vs {len(old)} stored circuits")
            D = np.zeros((len(new), len(old)))
            for b, o in enumerate(old):
                pr, w = ideal[o]
                states = np.flatnonzero(w == k)
                for a, i in enumerate(new):
                    sub, target = want[i]
                    v = np.zeros(sub.dim)
                    v[sub.index(list(states))] = pr[states]
                    D[a, b] = 0.5 * np.abs(v / v.sum() - target).sum()
            ra, cb = linear_sum_assignment(D)
            for a, b in zip(ra, cb):
                order[old[b]] = new[a]
                tvd[new[a]] = D[a, b]
                second = float(np.sort(D[a])[1]) if len(old) > 1 else None
                if second is not None and second - D[a, b] < 1e-6:
                    ambiguous += 1
                if D[a, b] > 1e-6:                    # not bit-identical (e.g. angles from a re-seeded optimiser)
                    loose.append({"tag": reqs[new[a]].tag, "m": m, "k": k, "tvd": round(float(D[a, b]), 4),
                                  "second_best_tvd": None if second is None else round(second, 4)})
        outs_o, kept_tot = self._postselect([reqs[i] for i in order], counts, mits, layouts)
        outs = [None] * len(reqs)
        for o, i in enumerate(order):
            outs[i] = outs_o[o]
        shots = max(r.shots for r in reqs)
        cz = [c.count_ops().get("cz", 0) for c in circs]
        info = {"mode": "ibm", "replayed": True, "jobs": jobs, "job_id": ",".join(j["job_id"] for j in jobs),
                "qpu_seconds": sum((j["qpu_seconds"] or 0) for j in jobs)}
        est = estimate_qpu_seconds([j["circuits"] * shots + 2 * 2000 for j in jobs])
        self.rounds.append({**info, "requests": len(reqs), "circuits": len(circs), "shots": shots, "chunks": len(jobs),
                            "estimated_qpu_s": round(est, 2), "kept_fraction": kept_tot / (len(circs) * shots),
                            "cz_max": int(max(cz)), "cz_median": float(np.median(cz)),
                            "match_tvd_max": float(tvd.max()), "match_tvd_median": float(np.median(tvd)),
                            "match_ambiguous": ambiguous, "match_inexact": loose,
                            "tags": sorted({r.tag for r in reqs}), "wall_s": round(time.time() - t0, 1)})
        self.log(f"  round {len(self.rounds)} (replayed from {len(jobs)} stored jobs): {len(reqs)} requests, "
                 f"match TVD max {tvd.max():.4f}, median {np.median(tvd):.4f}, inexact {len(loose)}, ambiguous {ambiguous}, "
                 f"kept {100 * self.rounds[-1]['kept_fraction']:.1f}%, billed earlier {info['qpu_seconds']} s")
        return outs
